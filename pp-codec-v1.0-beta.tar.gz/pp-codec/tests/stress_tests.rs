//! # Sprint S37-S38 — Stress Tests
//! Large data, many concurrent operations, memory bounds.
//! Ref: planDEV S37-S38, J4, J9

#[cfg(test)]
mod stress {
    use pp_codec::encoder::{encode_video, decode_video, PpvFile};
    use pp_codec::decoder::PpvDecoder;
    use pp_codec::quantize::{quantize_rgb, compute_psnr};
    use pp_codec::stv_uri::StvUri;
    use pp_codec::ppsp::*;
    use std::time::Instant;

    fn make_video(w: u32, h: u32, r: usize, m: u32, act: f64) -> Vec<Vec<u32>> {
        (0..r).map(|t| {
            (0..(w * h) as usize).map(|p| {
                let hh = ((p.wrapping_mul(2654435761)) ^ (t.wrapping_mul(2246822519))) & 0xFFFFFFFF;
                if (hh % 10000) < (act * 10000.0) as usize { (hh % m as usize) as u32 } else { 0 }
            }).collect()
        }).collect()
    }

    // ═══════════════════════════════════════════════
    // STRESS-01: Large video encode/decode
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_large_video_encode_decode() {
        let w = 256u32; let h = 192; let r = 128;
        let frames = make_video(w, h, r, 8, 0.05);

        let t0 = Instant::now();
        let ppv = encode_video(&frames, w, h, 16, 8);
        let enc_ms = t0.elapsed().as_secs_f64() * 1000.0;

        let bytes = ppv.serialize();

        let t1 = Instant::now();
        let decoded = decode_video(&ppv);
        let dec_ms = t1.elapsed().as_secs_f64() * 1000.0;

        // Lossless
        for (t, (o, d)) in frames.iter().zip(decoded.iter()).enumerate() {
            assert_eq!(o, d, "lossless fail frame {}", t);
        }

        let pixels = w as f64 * h as f64 * r as f64;
        eprintln!("  STRESS-01: {}×{}×{} = {:.0} Kpx", w, h, r, pixels / 1000.0);
        eprintln!("  Encode: {:.0} ms ({:.1} MPx/s)", enc_ms, pixels / enc_ms / 1000.0);
        eprintln!("  Decode: {:.0} ms ({:.1} MPx/s)", dec_ms, pixels / dec_ms / 1000.0);
        eprintln!("  File: {} bytes, Blocks: {}", bytes.len(), ppv.block_data.len());
    }

    // ═══════════════════════════════════════════════
    // STRESS-02: Many sequential decode operations
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_1000_random_access() {
        let frames = make_video(64, 64, 64, 4, 0.1);
        let ppv = encode_video(&frames, 64, 64, 16, 4);
        let bytes = ppv.serialize();
        let decoder = PpvDecoder::from_bytes(&bytes).unwrap();

        let t0 = Instant::now();
        for i in 0..1000 {
            let t = (i * 7) % 64;
            let frame = decoder.decode_frame(t as u32);
            assert!(frame.is_some(), "decode frame {} failed", t);
        }
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;
        let avg_us = elapsed_ms * 1000.0 / 1000.0;
        eprintln!("  STRESS-02: 1000 random frame decodes in {:.0} ms ({:.0} µs/frame)", elapsed_ms, avg_us);
    }

    // ═══════════════════════════════════════════════
    // STRESS-03: Many pixel trace decodes
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_500_pixel_traces() {
        let frames = make_video(32, 32, 64, 4, 0.08);
        let ppv = encode_video(&frames, 32, 32, 16, 4);
        let bytes = ppv.serialize();
        let decoder = PpvDecoder::from_bytes(&bytes).unwrap();

        let t0 = Instant::now();
        for i in 0..500 {
            let x = (i * 13) % 32;
            let y = (i * 7) % 32;
            let trace = decoder.decode_pixel(x as u32, y as u32);
            assert!(trace.is_some());
            assert_eq!(trace.unwrap().len(), 64);
        }
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;
        eprintln!("  STRESS-03: 500 pixel traces in {:.0} ms", elapsed_ms);
    }

    // ═══════════════════════════════════════════════
    // STRESS-04: Rapid serialize/deserialize cycles
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_serialize_roundtrip_100x() {
        let frames = make_video(32, 32, 32, 4, 0.05);
        let ppv = encode_video(&frames, 32, 32, 16, 4);

        let t0 = Instant::now();
        for _ in 0..100 {
            let bytes = ppv.serialize();
            let ppv2 = PpvFile::deserialize(&bytes).unwrap();
            assert_eq!(ppv2.frames, 32);
        }
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;
        eprintln!("  STRESS-04: 100 serialize/deserialize in {:.0} ms", elapsed_ms);
    }

    // ═══════════════════════════════════════════════
    // STRESS-05: Many PPSP messages
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_10000_ppsp_roundtrips() {
        let t0 = Instant::now();
        for i in 0u64..10_000 {
            let msg = match i % 4 {
                0 => PpspMessage::Open(OpenMsg {
                    uri: format!("ppv://cam/feed{}.ppv", i),
                    access: AccessLevel::Read,
                }),
                1 => PpspMessage::Seek(SeekMsg {
                    session_id: i, fragment: format!("t={}:{}", i, i + 100),
                }),
                2 => PpspMessage::Data(DataMsg {
                    block_id: (i % 1000) as u32, lod: (i % 4) as u8,
                    frame_start: 0, frame_end: 127,
                    data: vec![(i % 256) as u8; 50],
                }),
                _ => PpspMessage::Close(CloseMsg { session_id: i }),
            };
            let wire = msg.serialize();
            let parsed = PpspMessage::deserialize(&wire);
            assert!(parsed.is_some(), "roundtrip failed at i={}", i);
        }
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;
        eprintln!("  STRESS-05: 10000 PPSP roundtrips in {:.0} ms ({:.0} µs/msg)",
            elapsed_ms, elapsed_ms * 1000.0 / 10000.0);
    }

    // ═══════════════════════════════════════════════
    // STRESS-06: Many URI parses
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_5000_uri_parses() {
        let uris = vec![
            "ppv://cam.local/feed.ppv#t=0:128&b=5,3&lod=N2&act=0.1",
            "ppl://live.server/stream#t=-30&lod=auto",
            "ppv+https://cdn.example.com/video.ppv#t=100:200&fam=bspline&color=#FF0000",
            "ppv://x/y#t=0:0",
            "ppv://cam/feed.ppv",
        ];

        let t0 = Instant::now();
        for i in 0..5000 {
            let uri_str = uris[i % uris.len()];
            let parsed = StvUri::parse(uri_str).unwrap();
            let _ = parsed.to_string();
        }
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;
        eprintln!("  STRESS-06: 5000 URI parse+compose in {:.0} ms ({:.0} µs/op)",
            elapsed_ms, elapsed_ms * 1000.0 / 5000.0);
    }

    // ═══════════════════════════════════════════════
    // STRESS-07: Large RGB quantization
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_rgb_quantize_large() {
        let w = 128u32; let h = 96;
        let rgb_frames: Vec<Vec<u8>> = (0..16).map(|t| {
            let mut f = vec![0u8; (w * h * 3) as usize];
            for p in 0..(w * h) as usize {
                let hh = (p.wrapping_mul(2654435761)) ^ (t * 2246822519);
                if hh % 20 == 0 {
                    f[p * 3] = ((hh >> 8) & 0xFF) as u8;
                    f[p * 3 + 1] = ((hh >> 16) & 0xFF) as u8;
                    f[p * 3 + 2] = ((hh >> 24) & 0xFF) as u8;
                }
            }
            f
        }).collect();

        let t0 = Instant::now();
        let (pal, indexed) = quantize_rgb(&rgb_frames, w, h, 16);
        let elapsed_ms = t0.elapsed().as_secs_f64() * 1000.0;

        assert!(pal.len() <= 16);
        assert_eq!(indexed.len(), 16);
        for frame in &indexed {
            for &v in frame { assert!(v < pal.len() as u32); }
        }
        eprintln!("  STRESS-07: RGB quantize {}×{}×16 in {:.0} ms, palette={}", w, h, elapsed_ms, pal.len());
    }

    // ═══════════════════════════════════════════════
    // STRESS-08: Dense video (worst case for codec)
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_worst_case_100pct_activity() {
        let frames = make_video(64, 48, 32, 16, 1.0);
        let ppv = encode_video(&frames, 64, 48, 16, 16);
        let decoded = decode_video(&ppv);

        // Even worst case must be lossless
        for (t, (o, d)) in frames.iter().zip(decoded.iter()).enumerate() {
            assert_eq!(o, d, "worst case lossless fail at {}", t);
        }
        let bits: usize = ppv.block_bits.iter().sum();
        eprintln!("  STRESS-08: 100% activity 64×48×32 = {} bits ({} bytes ppv)",
            bits, ppv.serialize().len());
    }

    // ═══════════════════════════════════════════════
    // STRESS-09: Block decode + recompose = frame decode
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_block_recompose_consistency() {
        let w = 32u32; let h = 32; let r = 16;
        let frames = make_video(w, h, r, 4, 0.1);
        let ppv = encode_video(&frames, w, h, 16, 4);
        let bytes = ppv.serialize();
        let decoder = PpvDecoder::from_bytes(&bytes).unwrap();

        // Decode each frame via frame decoder
        let all = decode_video(&ppv);

        // Decode each block and recompose
        let bx_count = decoder.blocks_x() as usize;
        let by_count = decoder.blocks_y() as usize;

        for bid in 0..(bx_count * by_count) {
            let bx = (bid % bx_count) as u32;
            let by = (bid / bx_count) as u32;
            let traces = decoder.decode_block(bx, by).unwrap();
            // Each trace has r values
            for trace in &traces {
                assert_eq!(trace.len(), r, "trace len mismatch block ({},{})", bx, by);
            }
        }
    }

    // ═══════════════════════════════════════════════
    // STRESS-10: Memory: encode then drop, no leak
    // ═══════════════════════════════════════════════

    #[test]
    fn stress_memory_no_leak() {
        // Encode 10 videos, dropping each before the next
        for i in 0..10 {
            let frames = make_video(64, 64, 32, 8, 0.05 * (i + 1) as f64);
            let ppv = encode_video(&frames, 64, 64, 16, 8);
            let bytes = ppv.serialize();
            let _ = PpvFile::deserialize(&bytes).unwrap();
            // ppv and bytes drop here — Rust guarantees no leak
        }
        // If we got here without OOM, the test passes
    }
}
