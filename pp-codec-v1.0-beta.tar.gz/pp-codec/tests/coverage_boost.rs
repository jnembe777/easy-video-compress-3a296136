//! # Sprint S33-S34 addendum — Coverage boost tests
//! Target uncovered branches in arithmetic, heuristics, multiscale, encoder
#[cfg(test)]
mod coverage_boost {
    use pp_codec::encoder::*;
    use pp_codec::decoder::PpvDecoder;
    use pp_codec::quantize::*;

    // ═══ ENCODER EDGE PATHS ═══

    #[test]
    fn cov_encode_palette_2() {
        // Minimum palette: binary video
        let frames: Vec<Vec<u32>> = (0..8).map(|t|
            (0..16).map(|p| ((p + t) % 2) as u32).collect()
        ).collect();
        let ppv = encode_video(&frames, 4, 4, 4, 2);
        assert_eq!(decode_video(&ppv), frames);
    }

    #[test]
    fn cov_encode_large_palette() {
        let frames: Vec<Vec<u32>> = (0..4).map(|t|
            (0..16).map(|p| ((p * 7 + t * 3) % 100) as u32).collect()
        ).collect();
        let ppv = encode_video(&frames, 4, 4, 4, 1024);
        assert_eq!(decode_video(&ppv), frames);
    }

    #[test]
    fn cov_encode_non_power_of_2_block() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 25]; 4]; // 5×5
        let ppv = encode_video(&frames, 5, 5, 4, 2);
        let dec = decode_video(&ppv);
        // Blocks may pad, but decoded should match original pixels
        assert_eq!(dec.len(), 4);
    }

    #[test]
    fn cov_encode_v2_all_static() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 64]; 32];
        let (ppv, stats) = encode_video_v2(&frames, 8, 8, 8, 4);
        assert_eq!(decode_video(&ppv), frames);
    }

    #[test]
    fn cov_encode_v2_all_different() {
        let frames: Vec<Vec<u32>> = (0..8).map(|t|
            (0..16).map(|p| ((p * 37 + t * 71) % 4) as u32).collect()
        ).collect();
        let (ppv, _) = encode_video_v2(&frames, 4, 4, 4, 4);
        assert_eq!(decode_video(&ppv), frames);
    }

    // ═══ DECODER EDGE PATHS ═══

    #[test]
    fn cov_decoder_first_last_frame() {
        let frames: Vec<Vec<u32>> = (0..16).map(|t|
            (0..64).map(|p| if p == t { 1 } else { 0 }).collect()
        ).collect();
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();

        assert_eq!(dec.decode_frame(0).unwrap(), frames[0]);
        assert_eq!(dec.decode_frame(15).unwrap(), frames[15]);
        assert!(dec.decode_frame(16).is_none()); // out of range
    }

    #[test]
    fn cov_decoder_corner_pixels() {
        let frames: Vec<Vec<u32>> = (0..8).map(|t|
            (0..64).map(|p| if (p + t) % 8 == 0 { 1 } else { 0 }).collect()
        ).collect();
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();

        // Four corners
        assert!(dec.decode_pixel(0, 0).is_some());
        assert!(dec.decode_pixel(7, 0).is_some());
        assert!(dec.decode_pixel(0, 7).is_some());
        assert!(dec.decode_pixel(7, 7).is_some());
        assert!(dec.decode_pixel(8, 8).is_none()); // out of range
    }

    #[test]
    fn cov_decoder_block_boundaries() {
        // 16×16 with block_size=8 → 2×2 blocks
        let frames: Vec<Vec<u32>> = (0..4).map(|t|
            (0..256).map(|p| if (p + t) % 20 == 0 { 1 } else { 0 }).collect()
        ).collect();
        let ppv = encode_video(&frames, 16, 16, 8, 4);
        let bytes = ppv.serialize();
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();

        // All 4 blocks
        for bx in 0..2 { for by in 0..2 {
            assert!(dec.decode_block(bx, by).is_some(), "block ({},{}) failed", bx, by);
        }}
        assert!(dec.decode_block(2, 0).is_none()); // out of range
    }

    // ═══ QUANTIZER EDGE PATHS ═══

    #[test]
    fn cov_quantize_gradient() {
        // Smooth gradient: 256 unique colors → reduced to 8
        let mut frame = Vec::new();
        for y in 0..8u8 {
            for x in 0..8u8 {
                frame.push(x * 32);   // R: 0-224
                frame.push(y * 32);   // G: 0-224
                frame.push(128);      // B: constant
            }
        }
        let (pal, idx) = quantize_rgb(&[frame.clone()], 8, 8, 8);
        assert!(pal.len() <= 8);
        // PSNR should be reasonable for a gradient
        let recon = dequantize_rgb(&idx, &pal, 8, 8);
        let psnr = compute_psnr(&[frame], &recon);
        assert!(psnr > 10.0);
    }

    #[test]
    fn cov_quantize_max_colors() {
        // Request 256 colors from a diverse image
        let frame: Vec<u8> = (0..768).map(|i| (i % 256) as u8).collect(); // 256 pixels, 3 channels
        let (pal, idx) = quantize_rgb(&[frame], 16, 16, 256);
        for &i in &idx[0] { assert!(i < pal.len() as u32); }
    }

    #[test]
    fn cov_psnr_zero_length() {
        // Empty frames
        let a: Vec<Vec<u8>> = vec![vec![]];
        let b: Vec<Vec<u8>> = vec![vec![]];
        let p = compute_psnr(&a, &b);
        assert_eq!(p, f64::INFINITY); // no data → considered identical
    }

    // ═══ PPV FILE EDGE PATHS ═══

    #[test]
    fn cov_ppv_serialize_empty_blocks() {
        let ppv = PpvFile {
            width: 4, height: 4, frames: 2,
            block_size: 4, palette_size: 2,
            block_data: vec![vec![]],  // empty block data
            block_bits: vec![0],
        };
        let bytes = ppv.serialize();
        let ppv2 = PpvFile::deserialize(&bytes).unwrap();
        assert_eq!(ppv2.block_data.len(), 1);
        assert!(ppv2.block_data[0].is_empty());
    }

    #[test]
    fn cov_ppv_large_seek_table() {
        // Many small blocks
        let frames: Vec<Vec<u32>> = vec![vec![0; 1024]; 4]; // 32×32
        let ppv = encode_video(&frames, 32, 32, 4, 2); // block_size=4 → 8×8=64 blocks
        let bytes = ppv.serialize();
        let ppv2 = PpvFile::deserialize(&bytes).unwrap();
        assert_eq!(ppv2.block_data.len(), 64);
    }

    // ═══ STV-URI COVERAGE ═══

    #[test]
    fn cov_uri_all_fragments() {
        use pp_codec::stv_uri::*;
        let uri = StvUri::parse(
            "ppv://cam/f.ppv#t=10:20&b=1,2:5,6&p=100,200&lod=N3&tag=person&color=#00FF00&act=0.5&fam=trigo&fmt=raw"
        ).unwrap();
        assert!(uri.fragment.t.is_some());
        assert!(uri.fragment.b.is_some());
        assert!(uri.fragment.p.is_some());
        assert!(uri.fragment.lod.is_some());
        assert!(uri.fragment.tag.is_some());
        assert!(uri.fragment.color.is_some());
        assert!(uri.fragment.act.is_some());
        assert!(uri.fragment.fam.is_some());
        assert!(uri.fragment.fmt.is_some());
    }

    #[test]
    fn cov_uri_with_fragment_merge() {
        use pp_codec::stv_uri::*;
        let base = StvUri::parse("ppv://cam/f.ppv#t=10&lod=N1").unwrap();
        let mut extra = StvFragment::default();
        extra.t = Some(FrameRange::Single(99));
        extra.fam = Some("trigo".into());
        let merged = base.with_fragment(&extra);
        // t should be overridden
        assert_eq!(merged.fragment.t, Some(FrameRange::Single(99)));
        // fam should be added
        assert_eq!(merged.fragment.fam, Some("trigo".into()));
        // lod should be preserved from base
        assert_eq!(merged.fragment.lod, Some(LodLevel::N(1)));
    }

    // ═══ PPSP COVERAGE ═══

    #[test]
    fn cov_ppsp_all_select_types() {
        use pp_codec::ppsp::*;
        for st in [SelectType::Blocks, SelectType::Frames, SelectType::Pixels, SelectType::Events] {
            let msg = PpspMessage::Query(QueryMsg {
                session_id: 1, select: st, expression: "test".into(),
            });
            let bytes = msg.serialize();
            let parsed = PpspMessage::deserialize(&bytes).unwrap();
            if let PpspMessage::Query(q) = parsed {
                assert_eq!(q.select, st);
            }
        }
    }

    #[test]
    fn cov_ppsp_all_access_levels() {
        use pp_codec::ppsp::*;
        for al in [AccessLevel::Read, AccessLevel::Query, AccessLevel::Write] {
            let msg = PpspMessage::Open(OpenMsg { uri: "ppv://x/y".into(), access: al });
            let bytes = msg.serialize();
            let parsed = PpspMessage::deserialize(&bytes).unwrap();
            if let PpspMessage::Open(o) = parsed {
                assert_eq!(o.access, al);
            }
        }
    }

    #[test]
    fn cov_ppsp_empty_result() {
        use pp_codec::ppsp::*;
        let msg = PpspMessage::Result(ResultMsg {
            request_id: 0, total_count: 0, matches: vec![],
        });
        let bytes = msg.serialize();
        let parsed = PpspMessage::deserialize(&bytes).unwrap();
        if let PpspMessage::Result(r) = parsed {
            assert_eq!(r.total_count, 0);
            assert!(r.matches.is_empty());
        }
    }
}
