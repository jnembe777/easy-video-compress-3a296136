//! # Sprint S35-S36 — End-to-End Integration Tests
//! Validates the full pipeline across all 7 crates:
//! Codec → Streamer → Player → Browser → Admin
//!
//! Ref: planDEV S35-S36, UC-C01 to UC-S06

#[cfg(test)]
mod e2e {
    use pp_codec::encoder::{encode_video, encode_video_v2, decode_video, PpvFile};
    use pp_codec::decoder::PpvDecoder;
    use pp_codec::multiscale::encode_video_pyramid;
    use pp_codec::quantize::{quantize_rgb, dequantize_rgb, compute_psnr};
    use pp_codec::stv_uri::StvUri;
    use pp_codec::ppsp::*;

    // ═══════════════════════════════════════════════
    // FIXTURE: Generate test video data
    // ═══════════════════════════════════════════════

    fn make_surveillance_video(w: u32, h: u32, r: usize, act: f64) -> Vec<Vec<u32>> {
        (0..r).map(|t| {
            (0..(w * h) as usize).map(|p| {
                let h = ((p.wrapping_mul(2654435761)) ^ (t.wrapping_mul(2246822519))) & 0xFFFFFFFF;
                if (h % 10000) < (act * 10000.0) as usize { (h % 4) as u32 } else { 0 }
            }).collect()
        }).collect()
    }

    fn make_rgb_video(w: u32, h: u32, r: usize) -> Vec<Vec<u8>> {
        (0..r).map(|t| {
            let mut f = vec![0u8; (w * h * 3) as usize];
            for p in 0..(w * h) as usize {
                let h = ((p.wrapping_mul(2654435761)) ^ (t.wrapping_mul(2246822519))) & 0xFFFFFFFF;
                if h % 20 == 0 {
                    f[p * 3] = ((h >> 8) & 0xFF) as u8;
                    f[p * 3 + 1] = ((h >> 16) & 0xFF) as u8;
                    f[p * 3 + 2] = ((h >> 24) & 0xFF) as u8;
                }
            }
            f
        }).collect()
    }

    // ═══════════════════════════════════════════════
    // E2E-01: Full codec pipeline (encode → serialize → deserialize → decode)
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_codec_roundtrip_multiple_configs() {
        let configs = vec![
            (8, 8, 8, 4, 8),      // tiny
            (32, 32, 16, 4, 8),    // small
            (64, 48, 32, 8, 16),   // medium
            (128, 96, 64, 16, 16), // large
        ];
        for (w, h, r, m, bs) in configs {
            let frames = make_surveillance_video(w, h, r, 0.05);
            let ppv = encode_video(&frames, w, h, bs, m);
            let bytes = ppv.serialize();
            let ppv2 = PpvFile::deserialize(&bytes)
                .unwrap_or_else(|| panic!("deserialize failed for {}×{}×{}", w, h, r));
            let decoded = decode_video(&ppv2);
            for (t, (orig, dec)) in frames.iter().zip(decoded.iter()).enumerate() {
                assert_eq!(orig, dec, "lossless fail {}×{}×{} frame {}", w, h, r, t);
            }
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-02: Codec v2 (heuristics) matches v1
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_v2_lossless_matches_v1() {
        let frames = make_surveillance_video(32, 32, 32, 0.08);
        let ppv1 = encode_video(&frames, 32, 32, 16, 8);
        let (ppv2, _stats) = encode_video_v2(&frames, 32, 32, 16, 8);
        let dec1 = decode_video(&ppv1);
        let dec2 = decode_video(&ppv2);
        // Both must be lossless
        for t in 0..frames.len() {
            assert_eq!(dec1[t], frames[t], "v1 not lossless at {}", t);
            assert_eq!(dec2[t], frames[t], "v2 not lossless at {}", t);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-03: RGB pipeline (quantize → encode → decode → dequantize)
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_rgb_pipeline_multiple_sizes() {
        for (w, h) in [(8, 8), (16, 16), (32, 24)] {
            let rgb = make_rgb_video(w, h, 16);
            let (pal, indexed) = quantize_rgb(&rgb, w, h, 8);
            // Indexed must be in range
            for frame in &indexed {
                for &v in frame { assert!(v < pal.len() as u32); }
            }
            let ppv = encode_video(&indexed, w, h, 16, pal.len() as u32);
            let decoded_idx = decode_video(&ppv);
            // Lossless at indexed level
            for (t, (o, d)) in indexed.iter().zip(decoded_idx.iter()).enumerate() {
                assert_eq!(o, d, "indexed mismatch at frame {} for {}×{}", t, w, h);
            }
            // Dequantize and check PSNR
            let recon = dequantize_rgb(&decoded_idx, &pal, w, h);
            let psnr = compute_psnr(&rgb, &recon);
            assert!(psnr > 5.0 || psnr == f64::INFINITY, "PSNR too low: {}", psnr);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-04: Random access modes
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_random_access_consistency() {
        let w = 32u32; let h = 32; let r = 32;
        let frames = make_surveillance_video(w, h, r, 0.1);
        let ppv = encode_video(&frames, w, h, 16, 8);
        let bytes = ppv.serialize();
        let decoder = PpvDecoder::from_bytes(&bytes).unwrap();

        // decode_frame must match decode_all
        let all = decode_video(&ppv);
        for t in [0, 5, 15, r - 1] {
            let single = decoder.decode_frame(t as u32).unwrap();
            assert_eq!(single, all[t], "frame {} mismatch", t);
        }

        // decode_pixel must match column of frames
        let x = 5u32; let y = 3;
        let trace = decoder.decode_pixel(x, y).unwrap();
        for t in 0..r {
            let idx = (y * w + x) as usize;
            assert_eq!(trace[t], all[t][idx], "pixel ({},{}) mismatch at t={}", x, y, t);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-05: STV-URI → resolve → decode
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_uri_to_extraction() {
        let uri = StvUri::parse("ppv://cam/feed.ppv#t=5:10&b=1,1&lod=N2").unwrap();
        let plan = pp_codec::stv_uri::resolve(&uri.fragment, 64, 64, 32, 16);

        assert_eq!(plan.frame_range, (5, 10));
        assert_eq!(plan.lod, 2);
        assert!(plan.block_ids.len() >= 1);

        // URI roundtrip
        let uri_str = uri.to_string();
        let uri2 = StvUri::parse(&uri_str).unwrap();
        assert_eq!(uri2.scheme, uri.scheme);
        assert_eq!(uri2.fragment.t, uri.fragment.t);
    }

    // ═══════════════════════════════════════════════
    // E2E-06: PPSP message lifecycle
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_ppsp_full_message_cycle() {
        // Open
        let open = PpspMessage::Open(OpenMsg {
            uri: "ppv://cam/feed.ppv#t=0:64".into(),
            access: AccessLevel::Query,
        });
        let bytes = open.serialize();
        let parsed = PpspMessage::deserialize(&bytes).unwrap();
        assert!(matches!(parsed, PpspMessage::Open(_)));

        // Header response
        let header = PpspMessage::Header(HeaderMsg {
            session_id: 42, width: 640, height: 480, frames: 128,
            block_size: 16, palette_size: 8, num_blocks: 1200,
        });
        let hdr_bytes = header.serialize();
        let hdr_parsed = PpspMessage::deserialize(&hdr_bytes).unwrap();
        if let PpspMessage::Header(h) = hdr_parsed {
            assert_eq!(h.session_id, 42);
            assert_eq!(h.width, 640);
        } else { panic!("expected Header"); }

        // Data with real block
        let frames = make_surveillance_video(16, 16, 8, 0.05);
        let ppv = encode_video(&frames, 16, 16, 16, 4);
        let data_msg = PpspMessage::Data(DataMsg {
            block_id: 0, lod: 0, frame_start: 0, frame_end: 7,
            data: ppv.block_data[0].clone(),
        });
        let data_bytes = data_msg.serialize();
        let data_parsed = PpspMessage::deserialize(&data_bytes).unwrap();
        if let PpspMessage::Data(d) = data_parsed {
            assert_eq!(d.data, ppv.block_data[0]);
        } else { panic!("expected Data"); }

        // Query
        let query = PpspMessage::Query(QueryMsg {
            session_id: 42, select: SelectType::Blocks,
            expression: "activity > 0.1 AND fam = bspline".into(),
        });
        let qb = query.serialize();
        assert!(PpspMessage::deserialize(&qb).is_some());

        // Close
        let close = PpspMessage::Close(CloseMsg { session_id: 42 });
        let cb = close.serialize();
        let cp = PpspMessage::deserialize(&cb).unwrap();
        assert!(matches!(cp, PpspMessage::Close(_)));
    }

    // ═══════════════════════════════════════════════
    // E2E-07: Codec → PPSP Data → Decode (streaming simulation)
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_streaming_simulation() {
        let w = 32u32; let h = 32; let r = 16;
        let frames = make_surveillance_video(w, h, r, 0.05);
        let ppv = encode_video(&frames, w, h, 16, 4);
        let ppv_bytes = ppv.serialize();

        // Simulate: server sends each block as a PPSP DATA message
        for (block_id, block_data) in ppv.block_data.iter().enumerate() {
            let msg = PpspMessage::Data(DataMsg {
                block_id: block_id as u32,
                lod: 0,
                frame_start: 0,
                frame_end: r as u32 - 1,
                data: block_data.clone(),
            });
            let wire = msg.serialize();
            // Simulate network transfer
            let received = PpspMessage::deserialize(&wire).unwrap();
            if let PpspMessage::Data(d) = received {
                assert_eq!(d.data, *block_data);
                assert_eq!(d.block_id, block_id as u32);
            }
        }

        // Client reassembles and decodes
        let decoder = PpvDecoder::from_bytes(&ppv_bytes).unwrap();
        let all = decoder.decode_all();
        for (t, (orig, dec)) in frames.iter().zip(all.frames.iter()).enumerate() {
            assert_eq!(orig, dec, "stream decode mismatch at frame {}", t);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-08: Pyramid encode → verify progressive quality
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_pyramid_produces_compact_output() {
        let frames = make_surveillance_video(64, 64, 32, 0.05);
        let ppv_flat = encode_video(&frames, 64, 64, 16, 4);
        let (pyr_data, _) = encode_video_pyramid(&frames, 64, 64, 16, 4);

        let flat_bytes: usize = ppv_flat.block_data.iter().map(|b| b.len()).sum();
        // Pyramid packs multiple LODs but for sparse content should be compact
        assert!(pyr_data.len() > 0);

        // Flat decode must still be lossless
        let decoded = decode_video(&ppv_flat);
        for (t, (o, d)) in frames.iter().zip(decoded.iter()).enumerate() {
            assert_eq!(o, d, "pyramid lossless fail at {}", t);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-09: Cross-crate: STV-URI → PPSP → Codec
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_uri_ppsp_codec_chain() {
        // 1. Parse URI
        let uri = StvUri::parse("ppv://cam.local/nord.ppv#t=0:15&lod=N0").unwrap();

        // 2. Create PPSP OPEN from URI
        let open = PpspMessage::Open(OpenMsg {
            uri: uri.to_string(),
            access: AccessLevel::Read,
        });
        let wire = open.serialize();
        let parsed = PpspMessage::deserialize(&wire).unwrap();
        if let PpspMessage::Open(m) = parsed {
            // 3. Server parses the URI from the OPEN message
            let server_uri = StvUri::parse(&m.uri).unwrap();
            assert_eq!(server_uri.path, "/nord.ppv");

            // 4. Resolve the fragment
            let plan = pp_codec::stv_uri::resolve(
                &server_uri.fragment, 32, 32, 16, 16);
            assert_eq!(plan.frame_range, (0, 15));
            assert_eq!(plan.lod, 0);
        }
    }

    // ═══════════════════════════════════════════════
    // E2E-10: Multiple activity levels produce different ratios
    // ═══════════════════════════════════════════════

    #[test]
    fn e2e_activity_affects_ratio() {
        let w = 32u32; let h = 32;
        let mut ratios = Vec::new();
        for act in [0.01, 0.1, 0.5, 1.0] {
            let frames = make_surveillance_video(w, h, 32, act);
            let ppv = encode_video(&frames, w, h, 16, 4);
            let raw_bits = w as usize * h as usize * 32 * 2; // 2 bits per pixel (4 colors)
            let comp_bits: usize = ppv.block_bits.iter().sum();
            let ratio = raw_bits as f64 / comp_bits.max(1) as f64;
            ratios.push(ratio);
        }
        // Lower activity should yield better ratios
        for i in 1..ratios.len() {
            assert!(ratios[i] <= ratios[i - 1] * 1.2,
                "act {} ratio {:.2} should be ≤ act {} ratio {:.2}",
                [0.01, 0.1, 0.5, 1.0][i], ratios[i],
                [0.01, 0.1, 0.5, 1.0][i-1], ratios[i-1]);
        }
    }
}
