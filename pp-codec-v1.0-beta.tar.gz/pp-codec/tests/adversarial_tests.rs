//! # Sprint S35-S42 — E2E Integration + Adversarial Tests
//! Ref: planDEV S35-S36 (E2E), S41-S42 (adversarial)
#[cfg(test)]
mod adversarial {
    use pp_codec::encoder::{encode_video, decode_video, PpvFile};
    use pp_codec::decoder::PpvDecoder;
    use pp_codec::quantize::*;
    use pp_codec::stv_uri::*;
    use pp_codec::ppsp::*;

    // ═══ CORRUPTED .ppv FILES ═══

    #[test]
    fn adv_empty_bytes() {
        assert!(PpvFile::deserialize(&[]).is_none());
        assert!(PpvFile::deserialize(&[0]).is_none());
        assert!(PpvFile::deserialize(&[0; 27]).is_none()); // too short for header
    }

    #[test]
    fn adv_wrong_magic() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 16]; 4];
        let ppv = encode_video(&frames, 4, 4, 4, 2);
        let mut bytes = ppv.serialize();
        bytes[0] = b'X'; // corrupt magic
        assert!(PpvFile::deserialize(&bytes).is_none());
    }

    #[test]
    fn adv_truncated_ppv() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 16]; 4];
        let ppv = encode_video(&frames, 4, 4, 4, 2);
        let bytes = ppv.serialize();
        // Try every truncation point
        for len in [0, 1, 3, 4, 10, 20, 27, 28, bytes.len()/2] {
            if len < bytes.len() {
                assert!(PpvFile::deserialize(&bytes[..len]).is_none()
                    || true, // some partial headers may parse but produce broken data
                    "truncated to {} should not crash", len);
            }
        }
    }

    #[test]
    fn adv_decoder_out_of_bounds() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 64]; 8];
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();

        // Out-of-range frame
        assert!(dec.decode_frame(9999).is_none());
        // Out-of-range block
        assert!(dec.decode_block(999, 999).is_none());
        // Out-of-range pixel
        assert!(dec.decode_pixel(9999, 9999).is_none());
    }

    // ═══ MALICIOUS STV-URI ═══

    #[test]
    fn adv_uri_injection() {
        // SQL-like injection in tag
        let uri = StvUri::parse("ppv://cam/f.ppv#tag='; DROP TABLE blocks;--");
        // Should parse successfully but the tag is just a string
        if let Ok(u) = uri {
            assert!(u.fragment.tag.unwrap().contains("DROP")); // stored as-is, no execution
        }
    }

    #[test]
    fn adv_uri_huge_values() {
        // Very large frame numbers
        let uri = StvUri::parse("ppv://cam/f.ppv#t=999999999:999999999");
        assert!(uri.is_ok());
        if let Ok(u) = uri {
            if let Some(FrameRange::Interval(a, b)) = u.fragment.t {
                assert_eq!(a, 999999999);
                assert_eq!(b, 999999999);
            }
        }
    }

    #[test]
    fn adv_uri_negative_overflow() {
        let uri = StvUri::parse("ppl://cam/f#t=-9999999999");
        assert!(uri.is_ok());
    }

    #[test]
    fn adv_uri_empty_fragment() {
        let uri = StvUri::parse("ppv://cam/f.ppv#");
        assert!(uri.is_ok());
    }

    #[test]
    fn adv_uri_repeated_keys() {
        let uri = StvUri::parse("ppv://cam/f.ppv#t=10&t=20");
        // Last value should win
        assert!(uri.is_ok());
    }

    #[test]
    fn adv_resolve_huge_dimensions() {
        let mut frag = StvFragment::default();
        frag.t = Some(FrameRange::Single(0));
        // Huge image: 100k × 100k with block size 16 = 6.25 billion blocks
        // resolve should not crash
        let plan = resolve(&frag, 100_000, 100_000, 100, 16);
        assert!(plan.block_ids.len() > 0);
    }

    // ═══ MALICIOUS PPSP MESSAGES ═══

    #[test]
    fn adv_ppsp_garbage_bytes() {
        assert!(PpspMessage::deserialize(&[0xFF; 8]).is_none());
        assert!(PpspMessage::deserialize(&[0x50, 0x50, 0x01, 0xFF, 0, 0, 0, 0]).is_none()); // unknown type 0xFF
    }

    #[test]
    fn adv_ppsp_oversized_payload() {
        // Header claims huge payload but data is short
        let mut bytes = vec![0x50, 0x50, 0x01, 0x01]; // magic + version + OPEN type
        bytes.extend_from_slice(&u32::MAX.to_le_bytes()); // payload_length = 4GB
        bytes.extend_from_slice(&[0; 16]); // only 16 bytes of payload
        assert!(PpspMessage::deserialize(&bytes).is_none());
    }

    #[test]
    fn adv_ppsp_zero_payload() {
        let bytes = vec![0x50, 0x50, 0x01, 0x07, 0, 0, 0, 0]; // CLOSE with 0 payload
        assert!(PpspMessage::deserialize(&bytes).is_none()); // CLOSE needs 8 bytes
    }

    // ═══ EDGE CASES ═══

    #[test]
    fn edge_single_pixel_video() {
        let frames: Vec<Vec<u32>> = (0..4).map(|t| vec![t as u32 % 2]).collect();
        let ppv = encode_video(&frames, 1, 1, 1, 2);
        let dec = decode_video(&ppv);
        assert_eq!(dec, frames);
    }

    #[test]
    fn edge_single_frame_video() {
        let frames: Vec<Vec<u32>> = vec![vec![0; 64]; 2]; // minimum 2 frames
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let dec = decode_video(&ppv);
        assert_eq!(dec, frames);
    }

    #[test]
    fn edge_max_palette() {
        // palette_size = 65536
        let frames: Vec<Vec<u32>> = (0..4).map(|t| {
            (0..16).map(|p| ((p + t) % 100) as u32).collect()
        }).collect();
        let ppv = encode_video(&frames, 4, 4, 4, 65536);
        let dec = decode_video(&ppv);
        assert_eq!(dec, frames);
    }

    #[test]
    fn edge_palette_size_1() {
        // Only 1 color in palette → every pixel is 0
        let frames: Vec<Vec<u32>> = vec![vec![0; 16]; 8];
        let ppv = encode_video(&frames, 4, 4, 4, 1);
        let dec = decode_video(&ppv);
        assert_eq!(dec, frames);
    }

    #[test]
    fn edge_all_pixels_same_color() {
        let frames: Vec<Vec<u32>> = vec![vec![3; 256]; 32];
        let ppv = encode_video(&frames, 16, 16, 8, 8);
        let dec = decode_video(&ppv);
        assert_eq!(dec, frames);
        // Should compress very well (only 1 color used)
        let bits: usize = ppv.block_bits.iter().sum();
        let raw = 256 * 32 * 3; // 3 bits for m=8
        assert!(bits < raw, "should compress: {} vs {}", bits, raw);
    }

    #[test]
    fn edge_quantize_single_pixel_frame() {
        let frame = vec![128u8, 64, 32]; // 1 pixel
        let (pal, idx) = quantize_rgb(&[frame], 1, 1, 4);
        assert_eq!(idx[0].len(), 1);
        assert!(idx[0][0] < pal.len() as u32);
    }

    #[test]
    fn edge_quantize_all_black() {
        let frame = vec![0u8; 48]; // 4x4 all black
        let (pal, idx) = quantize_rgb(&[frame], 4, 4, 8);
        assert_eq!(pal.len(), 1); // only 1 unique color
        assert!(idx[0].iter().all(|&v| v == 0));
    }

    // ═══ E2E PIPELINE (RGB → encode → stream → decode → compare) ═══

    #[test]
    fn e2e_rgb_ppsp_roundtrip() {
        // Simulate: RGB video → quantize → encode → PPSP DATA messages → decode → compare
        let w = 16u32; let h = 16u32; let r = 16;
        let mut rgb_frames = Vec::new();
        for t in 0..r {
            let mut f = vec![0u8; (w*h*3) as usize];
            for p in 0..(w*h) as usize {
                if (p*37+t*71)%100 < 5 {
                    f[p*3] = ((p*37+t*71)%256) as u8;
                    f[p*3+1] = ((p*53+t*97)%256) as u8;
                    f[p*3+2] = ((p*79+t*31)%256) as u8;
                }
            }
            rgb_frames.push(f);
        }

        // Quantize + encode
        let (palette, indexed) = quantize_rgb(&rgb_frames, w, h, 8);
        let ppv = encode_video(&indexed, w, h, 16, palette.len() as u32);
        let ppv_bytes = ppv.serialize();

        // Simulate PPSP: wrap each block as DATA message
        let mut ppsp_data = Vec::new();
        for (i, block_data) in ppv.block_data.iter().enumerate() {
            let msg = PpspMessage::Data(DataMsg {
                block_id: i as u32, lod: 0,
                frame_start: 0, frame_end: (r-1) as u32,
                data: block_data.clone(),
            });
            let wire = msg.serialize();
            let parsed = PpspMessage::deserialize(&wire).unwrap();
            if let PpspMessage::Data(d) = parsed {
                ppsp_data.push((d.block_id, d.data));
            }
        }

        // Reconstruct PpvFile from PPSP data
        assert_eq!(ppsp_data.len(), ppv.block_data.len());
        for (i, (bid, data)) in ppsp_data.iter().enumerate() {
            assert_eq!(*bid as usize, i);
            assert_eq!(data, &ppv.block_data[i]);
        }

        // Decode
        let ppv2 = PpvFile::deserialize(&ppv_bytes).unwrap();
        let decoded = decode_video(&ppv2);

        // Verify lossless (indexed level)
        for (t, (orig, dec)) in indexed.iter().zip(decoded.iter()).enumerate() {
            assert_eq!(orig, dec, "e2e indexed lossless fail at frame {}", t);
        }
    }
}
