//! Integration test: Full RGB → PP-CODEC → RGB pipeline
//! Ref: planDEV S01-S02, UC-C01, UC-A07

#[cfg(test)]
mod integration {
    use pp_codec::quantize::*;
    use pp_codec::encoder::{encode_video, decode_video, PpvFile};

    /// Generate a synthetic surveillance-like RGB video:
    /// mostly black (static) with a few pixels changing color occasionally.
    fn generate_surveillance_rgb(w: u32, h: u32, r: usize, activity_pct: f64) -> Vec<Vec<u8>> {
        let npx = (w * h) as usize;
        let mut frames = Vec::with_capacity(r);
        let active_pixels = ((npx as f64) * activity_pct) as usize;

        for t in 0..r {
            let mut frame = vec![0u8; npx * 3]; // all black
            // A few pixels change color (simulating movement)
            for i in 0..active_pixels {
                let px = (i * 7 + t * 13) % npx;
                frame[px * 3]     = ((t * 37 + i * 71) % 256) as u8;
                frame[px * 3 + 1] = ((t * 53 + i * 97) % 256) as u8;
                frame[px * 3 + 2] = ((t * 79 + i * 31) % 256) as u8;
            }
            frames.push(frame);
        }
        frames
    }

    #[test]
    fn test_e2e_rgb_to_ppv_roundtrip() {
        let w = 32u32;
        let h = 32u32;
        let r = 64;
        let m = 16;

        // 1. Generate synthetic RGB video
        let rgb_frames = generate_surveillance_rgb(w, h, r, 0.05);
        assert_eq!(rgb_frames.len(), r);

        // 2. Quantize RGB → palette indices
        let (palette, indexed_frames) = quantize_rgb(&rgb_frames, w, h, m);
        assert!(palette.len() <= m);
        assert_eq!(indexed_frames.len(), r);
        for frame in &indexed_frames {
            assert_eq!(frame.len(), (w * h) as usize);
            for &v in frame {
                assert!(v < palette.len() as u32);
            }
        }

        // 3. Encode with PP-CODEC
        let ppv = encode_video(&indexed_frames, w, h, 16, palette.len() as u32);
        assert_eq!(ppv.width, w);
        assert_eq!(ppv.height, h);
        assert_eq!(ppv.frames, r as u32);

        // 4. Serialize to .ppv binary
        let ppv_bytes = ppv.serialize();
        assert!(ppv_bytes.len() > 28); // at least header

        // 5. Measure compression ratio
        let raw_bits = (w * h * r as u32) as usize * (palette.len() as f64).log2().ceil() as usize;
        let compressed_bits: usize = ppv.block_bits.iter().sum();
        let ratio = if compressed_bits > 0 { raw_bits as f64 / compressed_bits as f64 } else { f64::INFINITY };
        eprintln!("  Palette: {} colors", palette.len());
        eprintln!("  Raw: {} bits, Compressed: {} bits", raw_bits, compressed_bits);
        eprintln!("  Ratio: {:.1}:1", ratio);
        assert!(ratio > 1.0, "compression should reduce size");

        // 6. Deserialize
        let ppv2 = PpvFile::deserialize(&ppv_bytes).expect("deserialize");
        assert_eq!(ppv2.width, w);
        assert_eq!(ppv2.frames, r as u32);

        // 7. Decode
        let decoded_frames = decode_video(&ppv2);
        assert_eq!(decoded_frames.len(), r);

        // 8. Verify lossless (indexed → indexed)
        for (t, (orig, dec)) in indexed_frames.iter().zip(decoded_frames.iter()).enumerate() {
            assert_eq!(orig, dec, "frame {} mismatch: indexed lossless invariant violated", t);
        }

        // 9. Dequantize back to RGB
        let recon_rgb = dequantize_rgb(&decoded_frames, &palette, w, h);
        assert_eq!(recon_rgb.len(), r);

        // 10. PSNR (quantization is lossy, but decode is lossless)
        let psnr = compute_psnr(&rgb_frames, &recon_rgb);
        eprintln!("  PSNR: {:.1} dB", psnr);
        // Quantization of random RGB to 16 colors is inherently lossy (~13 dB).
        // The key invariant is that the codec itself is lossless (verified step 8).
        // On real surveillance video with fewer distinct colors, PSNR is much higher.
        assert!(psnr > 10.0 || psnr == f64::INFINITY,
            "PSNR too low: {:.1} dB", psnr);
    }

    #[test]
    fn test_e2e_lossless_when_few_colors() {
        // If the video has ≤ m colors, quantization is lossless → PSNR = ∞
        let w = 16u32;
        let h = 16u32;
        let r = 32;

        // Generate with only 4 distinct colors
        let colors = [
            (0u8, 0u8, 0u8),       // black
            (255, 0, 0),            // red
            (0, 255, 0),            // green
            (0, 0, 255),            // blue
        ];
        let npx = (w * h) as usize;
        let mut rgb_frames = Vec::new();
        for t in 0..r {
            let mut frame = vec![0u8; npx * 3];
            for p in 0..npx {
                let ci = (p + t) % 4;
                let (cr, cg, cb) = colors[ci];
                frame[p * 3] = cr;
                frame[p * 3 + 1] = cg;
                frame[p * 3 + 2] = cb;
            }
            rgb_frames.push(frame);
        }

        // Quantize to 8 colors (more than the 4 present)
        let (palette, indexed) = quantize_rgb(&rgb_frames, w, h, 8);
        assert_eq!(palette.len(), 4, "should use exactly 4 colors");

        // Encode → decode
        let ppv = encode_video(&indexed, w, h, 16, palette.len() as u32);
        let decoded = decode_video(&ppv);

        // Indexed lossless
        for (t, (orig, dec)) in indexed.iter().zip(decoded.iter()).enumerate() {
            assert_eq!(orig, dec, "frame {} lossless mismatch", t);
        }

        // Dequantize → PSNR should be infinite (lossless end-to-end)
        let recon = dequantize_rgb(&decoded, &palette, w, h);
        let psnr = compute_psnr(&rgb_frames, &recon);
        assert_eq!(psnr, f64::INFINITY, "should be lossless with ≤ m colors");
    }

    #[test]
    fn test_stv_uri_resolve_on_real_dimensions() {
        use pp_codec::stv_uri::*;

        let uri = StvUri::parse("ppv://cam.local/feed.ppv#t=10:50&b=2,1:4,3&lod=N2&act=0.1").unwrap();
        let plan = resolve(&uri.fragment, 32, 32, 64, 16);

        // b=2,1:4,3 → blocks (2,1), (3,1), (4,1), (2,2), (3,2), (4,2), (2,3), (3,3), (4,3)
        assert_eq!(plan.frame_range, (10, 50));
        assert_eq!(plan.lod, 2);
        assert!(plan.block_ids.len() <= 9);
        assert_eq!(plan.filters.len(), 1); // act>0.1
    }

    #[test]
    fn test_ppsp_data_with_real_block() {
        use pp_codec::ppsp::*;
        use pp_codec::encoder::encode_video;
        use pp_codec::quantize::*;

        // Create a tiny video, encode, extract one block
        let w = 16u32; let h = 16u32; let r = 8;
        let frame = vec![128u8; (w * h * 3) as usize];
        let rgb_frames: Vec<Vec<u8>> = (0..r).map(|_| frame.clone()).collect();
        let (palette, indexed) = quantize_rgb(&rgb_frames, w, h, 4);
        let ppv = encode_video(&indexed, w, h, 16, palette.len() as u32);

        // Wrap first block in a PPSP DATA message
        let msg = PpspMessage::Data(DataMsg {
            block_id: 0,
            lod: 0,
            frame_start: 0,
            frame_end: r as u32 - 1,
            data: ppv.block_data[0].clone(),
        });

        // Serialize → deserialize roundtrip
        let bytes = msg.serialize();
        let msg2 = PpspMessage::deserialize(&bytes).expect("roundtrip");
        if let PpspMessage::Data(d) = msg2 {
            assert_eq!(d.block_id, 0);
            assert_eq!(d.data, ppv.block_data[0]);
        } else {
            panic!("wrong message type");
        }
    }
}
