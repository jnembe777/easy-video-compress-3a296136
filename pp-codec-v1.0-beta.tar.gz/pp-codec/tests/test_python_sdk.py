#!/usr/bin/env python3
"""
PP-CODEC Python SDK — Test Suite (Sprint S05-S06)
Tests all 15 exported functions.
"""

import pp_codec_python as pp
import sys
import time

PASS = 0
FAIL = 0

def test(name, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        print(f"  ❌ {name} — {detail}")

print("╔═══════════════════════════════════════════════════════╗")
print("║   PP-CODEC Python SDK — Test Suite S05-S06           ║")
print("╚═══════════════════════════════════════════════════════╝")
print()

# ═══ 1. VERSION ═══
print("── 1. Version ──")
v = pp.version()
test("version()", "pp-codec-python" in v, v)

# ═══ 2. ENCODE / DECODE ROUNDTRIP ═══
print("\n── 2. Encode / Decode roundtrip ──")
W, H, R, M = 16, 16, 32, 4
# Generate synthetic frames (mostly zeros with some activity)
frames = []
for t in range(R):
    frame = [0] * (W * H)
    for p in range(W * H):
        if ((p * 2654435761) ^ (t * 2246822519)) % 100 < 5:
            frame[p] = ((p * 37 + t * 71) % M)
    frames.append(frame)

t0 = time.time()
ppv_bytes = pp.encode(frames, width=W, height=H, block_size=8, palette_size=M)
enc_ms = (time.time() - t0) * 1000
test("encode() returns bytes", isinstance(ppv_bytes, bytes), f"got {type(ppv_bytes)}")
test("encode() non-empty", len(ppv_bytes) > 28, f"got {len(ppv_bytes)} bytes")

t0 = time.time()
decoded = pp.decode(ppv_bytes)
dec_ms = (time.time() - t0) * 1000
test("decode() returns list", isinstance(decoded, list))
test("decode() frame count", len(decoded) == R, f"got {len(decoded)}")
test("decode() frame size", len(decoded[0]) == W * H, f"got {len(decoded[0])}")

# Lossless check
lossless = all(decoded[t] == frames[t] for t in range(R))
test("LOSSLESS roundtrip", lossless, "frames differ!")
print(f"     Encode: {enc_ms:.1f} ms, Decode: {dec_ms:.1f} ms, Size: {len(ppv_bytes)} bytes")

# ═══ 3. ENCODE_V2 (heuristics) ═══
print("\n── 3. Encode v2 (heuristics) ──")
ppv_v2 = pp.encode_v2(frames, width=W, height=H, block_size=8, palette_size=M)
test("encode_v2() returns bytes", isinstance(ppv_v2, bytes))
decoded_v2 = pp.decode(ppv_v2)
lossless_v2 = all(decoded_v2[t] == frames[t] for t in range(R))
test("encode_v2 LOSSLESS", lossless_v2)

# ═══ 4. ENCODE_PYRAMID ═══
print("\n── 4. Encode pyramid ──")
pyr_bytes = pp.encode_pyramid(frames, width=W, height=H, block_size=16, palette_size=M)
test("encode_pyramid() returns bytes", isinstance(pyr_bytes, bytes))
test("pyramid smaller overhead", len(pyr_bytes) > 0, f"{len(pyr_bytes)} bytes")
print(f"     Flat: {len(ppv_bytes)} bytes, Pyramid: {len(pyr_bytes)} bytes")

# ═══ 5. ENCODE_RGB ═══
print("\n── 5. Encode RGB ──")
rgb_frames = []
for t in range(R):
    frame_bytes = bytearray(W * H * 3)
    for p in range(W * H):
        if ((p * 2654435761) ^ (t * 2246822519)) % 100 < 5:
            frame_bytes[p*3] = (p * 37 + t * 71) % 256
            frame_bytes[p*3+1] = (p * 53 + t * 97) % 256
            frame_bytes[p*3+2] = (p * 79 + t * 31) % 256
    rgb_frames.append(bytes(frame_bytes))

ppv_rgb, palette = pp.encode_rgb(rgb_frames, width=W, height=H, palette_size=8)
test("encode_rgb() returns tuple", isinstance(ppv_rgb, bytes))
test("palette is list", isinstance(palette, list))
test("palette entries are tuples", len(palette) > 0 and isinstance(palette[0], tuple))
test("palette has 3 channels", len(palette[0]) == 3)
print(f"     Palette: {len(palette)} colors, Size: {len(ppv_rgb)} bytes")

# Decode the RGB-encoded file
decoded_rgb = pp.decode(ppv_rgb)
test("decode(encode_rgb()) works", len(decoded_rgb) == R)

# ═══ 6. RANDOM ACCESS ═══
print("\n── 6. Random access ──")

# decode_block
block_traces = pp.decode_block(ppv_bytes, block_id=0)
test("decode_block() returns list", isinstance(block_traces, list))
test("decode_block() has traces", len(block_traces) > 0)
test("decode_block() trace length = R", len(block_traces[0]) == R)

# decode_frame
frame_42 = pp.decode_frame(ppv_bytes, t=0)
test("decode_frame(0) returns list", isinstance(frame_42, list))
test("decode_frame(0) size = W*H", len(frame_42) == W * H)
test("decode_frame(0) matches", frame_42 == frames[0])

# decode_pixel
trace = pp.decode_pixel(ppv_bytes, x=0, y=0)
test("decode_pixel() returns list", isinstance(trace, list))
test("decode_pixel() length = R", len(trace) == R)
# Verify pixel (0,0) trace matches
expected = [frames[t][0] for t in range(R)]
test("decode_pixel() matches", trace == expected)

# decode_frame_range
# decode_frame_range — Rust uses [start, end) semi-open interval
range_frames = pp.decode_frame_range(ppv_bytes, start=5, end=10)
test("decode_frame_range() count", len(range_frames) == 5, f"got {len(range_frames)}")
test("decode_frame_range() matches", range_frames[0] == frames[5])

# ═══ 7. INFO ═══
print("\n── 7. Info (no decoding) ──")
info = pp.info(ppv_bytes)
test("info() returns dict", isinstance(info, dict))
test("info.width", info["width"] == W)
test("info.height", info["height"] == H)
test("info.frames", info["frames"] == R)
test("info.block_size", info["block_size"] == 8)
test("info.palette_size", info["palette_size"] == M)
test("info.num_blocks > 0", info["num_blocks"] > 0)
print(f"     Info: {info}")

# ═══ 8. QUERY ACTIVITY ═══
print("\n── 8. Query activity ──")
active = pp.query_activity(ppv_bytes, threshold=0.5)
test("query_activity() returns list", isinstance(active, list))
if len(active) > 0:
    test("query result has block_id", "block_id" in active[0])
    test("query result has bits", "bits" in active[0])
print(f"     Active blocks (threshold=0.5): {len(active)}")

# ═══ 9. STV-URI ═══
print("\n── 9. STV-URI ──")
uri_str = "ppv://cam.local/feed.ppv#t=10:50&b=2,1&lod=N2&act=0.1&fam=bspline"
parsed = pp.parse_uri(uri_str)
test("parse_uri() returns dict", isinstance(parsed, dict))
test("scheme = ppv", parsed["scheme"] == "ppv")
test("authority = cam.local", parsed["authority"] == "cam.local")
test("path = /feed.ppv", parsed["path"] == "/feed.ppv")
test("fragment has t", "t" in parsed["fragment"])
test("fragment has lod", "lod" in parsed["fragment"])
test("fragment has act", "act" in parsed["fragment"])
test("fragment has fam", "fam" in parsed["fragment"])
print(f"     Parsed: {parsed}")

# resolve_uri
plan = pp.resolve_uri(uri_str, width=640, height=480, frames=1024, block_size=16)
test("resolve_uri() returns dict", isinstance(plan, dict))
test("plan has block_ids", "block_ids" in plan)
test("plan has lod", plan["lod"] == 2)
test("plan frame_start", plan["frame_start"] == 10)
test("plan frame_end", plan["frame_end"] == 50)
test("plan has filters", len(plan["filters"]) >= 2)
print(f"     Plan: {plan['num_blocks']} blocks, lod={plan['lod']}, frames={plan['frame_start']}:{plan['frame_end']}")

# ═══ 10. PSNR ═══
print("\n── 10. PSNR ──")
psnr_identical = pp.psnr([b'\x80' * 30], [b'\x80' * 30])
test("psnr identical = inf", psnr_identical == float('inf'))
psnr_diff = pp.psnr([b'\x64' * 30], [b'\x6e' * 30])
test("psnr different > 0", psnr_diff > 0 and psnr_diff < 100, f"got {psnr_diff:.1f}")

# ═══ 11. ERROR HANDLING ═══
print("\n── 11. Error handling ──")
try:
    pp.decode(b"not a ppv file")
    test("decode(invalid) raises", False, "no exception")
except ValueError as e:
    test("decode(invalid) raises ValueError", "invalid" in str(e).lower())

try:
    pp.encode([], width=10, height=10)
    test("encode([]) raises", False, "no exception")
except ValueError:
    test("encode([]) raises ValueError", True)

try:
    pp.parse_uri("http://not-ppv")
    test("parse_uri(invalid) raises", False, "no exception")
except ValueError:
    test("parse_uri(invalid) raises ValueError", True)

# ═══ SUMMARY ═══
print()
print("╔═══════════════════════════════════════════════════════╗")
total = PASS + FAIL
print(f"║   RÉSULTAT : {PASS}/{total} tests passés" + " " * (38 - len(f"{PASS}/{total}")) + "║")
if FAIL == 0:
    print("║   ✅ ALL TESTS PASSED                                ║")
else:
    print(f"║   ❌ {FAIL} TESTS FAILED                              ║")
print("╚═══════════════════════════════════════════════════════╝")
sys.exit(0 if FAIL == 0 else 1)
