//! # Sprint S33-S34 — Exhaustive Property-Based Tests
//! Ref: planDEV S33-S34, J14 (coverage > 80%)
#[cfg(test)]
mod property_tests {
    use pp_codec::encoder::{encode_video, encode_video_v2, decode_video, encode_pixel_trace, decode_pixel_trace, PpvFile};
    use pp_codec::decoder::PpvDecoder;
    use pp_codec::quantize::*;
    use pp_codec::stv_uri::*;
    use pp_codec::ppsp::*;
    use pp_codec::multiscale::encode_video_pyramid;

    fn make_trace(r: usize, m: u32, seed: u64) -> Vec<u32> {
        (0..r).map(|t| {
            let h = seed.wrapping_mul(2654435761).wrapping_add(t as u64 * 2246822519) & 0xFFFFFFFF;
            (h % m as u64) as u32
        }).collect()
    }

    fn make_video(w: u32, h: u32, r: usize, m: u32, act: f64, seed: u64) -> Vec<Vec<u32>> {
        let npx = (w * h) as usize;
        (0..r).map(|t| (0..npx).map(|p| {
            let hh = (p as u64).wrapping_mul(2654435761)^(t as u64).wrapping_mul(2246822519)^seed.wrapping_mul(1442695040888963407);
            if (hh%10000) < (act*10000.0) as u64 { (hh%m as u64) as u32 } else { 0 }
        }).collect()).collect()
    }

    // ═══ PIXEL ROUNDTRIP ═══

    #[test]
    fn prop_pixel_roundtrip_300_configs() {
        let configs: Vec<(usize, u32)> = vec![
            (2,2),(2,4),(3,2),(4,8),(8,4),(16,16),(32,8),(64,4),(128,2),(128,16),(256,8),(512,4),(100,3),(50,7),(200,5),
        ];
        for (r,m) in &configs {
            for seed in 0..20u64 {
                let trace = make_trace(*r, *m, seed);
                let enc = encode_pixel_trace(&trace, *m);
                let dec = decode_pixel_trace(&enc);
                assert_eq!(dec, trace, "pixel rt: r={},m={},seed={}", r, m, seed);
            }
        }
    }

    #[test]
    fn prop_pixel_all_same() {
        for m in [2,4,8,16,256] { for c in 0..m.min(4) {
            let t = vec![c; 64];
            assert_eq!(decode_pixel_trace(&encode_pixel_trace(&t, m)), t);
        }}
    }

    #[test]
    fn prop_pixel_alternating() {
        for r in [4,8,16,32,64,128] {
            let t: Vec<u32> = (0..r).map(|i| (i%2) as u32).collect();
            assert_eq!(decode_pixel_trace(&encode_pixel_trace(&t, 4)), t);
        }
    }

    #[test]
    fn prop_pixel_single_event() {
        for r in [4,16,64,256] { for pos in [0,r/2,r-1] {
            let mut t = vec![0u32; r]; t[pos] = 1;
            assert_eq!(decode_pixel_trace(&encode_pixel_trace(&t, 4)), t);
        }}
    }

    // ═══ VIDEO ROUNDTRIP ═══

    #[test]
    fn prop_video_roundtrip_configs() {
        let cfgs: Vec<(u32,u32,usize,u32,u32,f64)> = vec![
            (4,4,4,2,4,0.0),(4,4,4,2,4,1.0),(8,8,8,4,8,0.05),(16,16,16,8,8,0.1),
            (16,8,32,4,8,0.5),(32,32,8,16,16,0.02),(12,12,10,4,8,0.2),(5,7,4,3,4,0.3),
        ];
        for (i,&(w,h,r,m,bs,act)) in cfgs.iter().enumerate() {
            let frames = make_video(w,h,r,m,act,i as u64*7);
            let ppv = encode_video(&frames, w, h, bs, m);
            let dec = decode_video(&ppv);
            for (t,(o,d)) in frames.iter().zip(dec.iter()).enumerate() {
                assert_eq!(o, d, "video rt: cfg={},frame={}", i, t);
            }
        }
    }

    #[test]
    fn prop_video_v2_lossless() {
        for seed in 0..5u64 {
            let frames = make_video(16,16,16,8,0.1,seed);
            let (ppv,_) = encode_video_v2(&frames, 16, 16, 8, 8);
            let dec = decode_video(&ppv);
            for (t,(o,d)) in frames.iter().zip(dec.iter()).enumerate() {
                assert_eq!(o, d, "v2 rt: seed={},frame={}", seed, t);
            }
        }
    }

    #[test]
    fn prop_serialize_deserialize() {
        for seed in 0..5u64 {
            let frames = make_video(8,8,16,4,0.1,seed);
            let ppv = encode_video(&frames, 8, 8, 8, 4);
            let bytes = ppv.serialize();
            let ppv2 = PpvFile::deserialize(&bytes).expect("deser");
            assert_eq!(ppv.width, ppv2.width);
            assert_eq!(ppv.block_data, ppv2.block_data);
        }
    }

    // ═══ DECODER CONSISTENCY ═══

    #[test]
    fn prop_decoder_frame_vs_full() {
        let frames = make_video(16,16,32,8,0.1,42);
        let ppv = encode_video(&frames, 16, 16, 8, 8);
        let bytes = ppv.serialize();
        let full = decode_video(&ppv);
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();
        for t in 0..32u32 {
            assert_eq!(dec.decode_frame(t).unwrap(), full[t as usize], "frame {}", t);
        }
    }

    #[test]
    fn prop_decoder_pixel_vs_frame() {
        let frames = make_video(8,8,16,4,0.2,99);
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let dec = PpvDecoder::from_bytes(&bytes).unwrap();
        for x in 0..8u32 { for y in 0..8u32 {
            let trace = dec.decode_pixel(x,y).unwrap();
            for t in 0..16 {
                assert_eq!(trace[t], frames[t][(y*8+x) as usize], "px({},{})@{}", x, y, t);
            }
        }}
    }

    // ═══ STV-URI ═══

    #[test]
    fn prop_uri_roundtrip() {
        let uris = vec![
            "ppv://cam/feed.ppv", "ppv://cam/f.ppv#t=42", "ppv://cam/f.ppv#t=10:200",
            "ppl://live/s#t=-30", "ppv+https://cdn.ex.com/v.ppv#t=0:100&lod=N3",
            "ppv://c/f.ppv#b=5,3&lod=N2", "ppv://c/f.ppv#b=2,1:8,6", "ppv://c/f.ppv#p=120,80",
            "ppv://c/f.ppv#t=100:200&b=5,3&lod=N3&act=0.100&fam=bspline",
            "ppv://c/f.ppv#color=#FF0000&tag=vehicle", "ppv://c/f.ppv#fmt=json",
        ];
        for u in &uris {
            let p = StvUri::parse(u).unwrap();
            let s = p.to_string();
            let p2 = StvUri::parse(&s).unwrap();
            assert_eq!(p.scheme, p2.scheme, "{}", u);
            assert_eq!(p.fragment.t, p2.fragment.t, "{}", u);
            assert_eq!(p.fragment.b, p2.fragment.b, "{}", u);
            assert_eq!(p.fragment.lod, p2.fragment.lod, "{}", u);
        }
    }

    #[test]
    fn prop_uri_invalid() {
        for u in &["", "not-a-uri", "http://x", "ppv://", "ppv:///", "ppv://c/f#t=abc", "ppv://c/f#lod=Z9"] {
            assert!(StvUri::parse(u).is_err(), "should reject: '{}'", u);
        }
    }

    // ═══ PPSP ═══

    #[test]
    fn prop_ppsp_all_types_roundtrip() {
        let msgs = vec![
            PpspMessage::Open(OpenMsg { uri: "ppv://c/f#t=42".into(), access: AccessLevel::Query }),
            PpspMessage::Header(HeaderMsg { session_id: u64::MAX, width: 3840, height: 2160, frames: 65535, block_size: 32, palette_size: 65536, num_blocks: 8100 }),
            PpspMessage::Seek(SeekMsg { session_id: 42, fragment: "t=100:200&lod=N4".into() }),
            PpspMessage::Data(DataMsg { block_id: u32::MAX-1, lod: 4, frame_start: 0, frame_end: u32::MAX, data: vec![0xFF; 1024] }),
            PpspMessage::Data(DataMsg { block_id: 0, lod: 0, frame_start: 0, frame_end: 0, data: vec![] }),
            PpspMessage::Query(QueryMsg { session_id: 1, select: SelectType::Pixels, expression: "activity > 0.001".into() }),
            PpspMessage::Result(ResultMsg { request_id: 99, total_count: 2, matches: vec![
                BlockMatch { block_id: 0, bx: 0, by: 0, n_total: 42, family: 2, activity: 0.85 },
                BlockMatch { block_id: 100, bx: 10, by: 5, n_total: 999, family: 3, activity: 0.01 },
            ]}),
            PpspMessage::Close(CloseMsg { session_id: 0 }),
            PpspMessage::Error(ErrorMsg { code: 404, message: "not found".into() }),
        ];
        for (i,msg) in msgs.iter().enumerate() {
            let bytes = msg.serialize();
            let parsed = PpspMessage::deserialize(&bytes).unwrap_or_else(|| panic!("msg {} deser", i));
            assert_eq!(msg.msg_type(), parsed.msg_type(), "msg {}", i);
            assert_eq!(bytes, parsed.serialize(), "msg {} double-serialize", i);
        }
    }

    #[test]
    fn prop_ppsp_truncated_rejected() {
        let msg = PpspMessage::Header(HeaderMsg { session_id: 1, width: 640, height: 480, frames: 128, block_size: 16, palette_size: 8, num_blocks: 1200 });
        let bytes = msg.serialize();
        for len in 0..bytes.len() {
            assert!(PpspMessage::deserialize(&bytes[..len]).is_none(), "trunc {} should fail", len);
        }
    }

    // ═══ QUANTIZER ═══

    #[test]
    fn prop_quantize_invariants() {
        for m in [2,4,8,16,32,256] {
            let frame = vec![0u8; 48];
            let (pal,idx) = quantize_rgb(&[frame], 4, 4, m);
            assert!(pal.len() <= m);
            for &i in &idx[0] { assert!(i < pal.len() as u32); }
        }
    }

    #[test]
    fn prop_quantize_lossless_few_colors() {
        let colors = [(255u8,0,0),(0,255,0),(0,0,255)];
        let mut frame = Vec::new();
        for i in 0..16 { let (r,g,b) = colors[i%3]; frame.extend_from_slice(&[r,g,b]); }
        let (pal,idx) = quantize_rgb(&[frame.clone()], 4, 4, 8);
        assert_eq!(pal.len(), 3);
        let recon = dequantize_rgb(&idx, &pal, 4, 4);
        assert_eq!(compute_psnr(&[frame], &recon), f64::INFINITY);
    }

    #[test]
    fn prop_psnr_properties() {
        let a = vec![vec![100u8; 30]];
        assert_eq!(compute_psnr(&a, &a), f64::INFINITY);
        let b = vec![vec![110u8; 30]];
        let c = vec![vec![0u8; 30]];
        let d = vec![vec![99u8; 30]];
        assert!(compute_psnr(&a, &b) > 0.0);
        assert!(compute_psnr(&a, &c) < compute_psnr(&a, &d));
    }

    // ═══ FULL PIPELINE 100 RANDOM ═══

    #[test]
    fn prop_full_pipeline_100_random() {
        for seed in 0..100u64 {
            let w = 4 + (seed%5) as u32 * 4;
            let h = 4 + (seed/5%5) as u32 * 4;
            let r = 4 + (seed%7) as usize * 4;
            let m = [2,4,8,16][(seed%4) as usize];
            let bs = [4,8,16][(seed%3) as usize];
            let act = (seed%10) as f64 * 0.1;
            let frames = make_video(w, h, r, m, act, seed);
            let ppv = encode_video(&frames, w, h, bs, m);
            let bytes = ppv.serialize();
            let ppv2 = PpvFile::deserialize(&bytes).expect(&format!("deser seed={}", seed));
            let dec = decode_video(&ppv2);
            for (t,(o,d)) in frames.iter().zip(dec.iter()).enumerate() {
                assert_eq!(o, d, "pipeline: seed={},frame={}", seed, t);
            }
        }
    }

    // ═══ PYRAMID ═══

    #[test]
    fn prop_pyramid_sparse_smaller() {
        let sparse = make_video(32,32,32,4,0.02,1);
        let dense = make_video(32,32,32,4,0.80,2);
        let (ps,_) = encode_video_pyramid(&sparse, 32, 32, 16, 4);
        let (pd,_) = encode_video_pyramid(&dense, 32, 32, 16, 4);
        assert!(ps.len() < pd.len(), "sparse {} < dense {}", ps.len(), pd.len());
    }
}
