# Changelog

All notable changes to PP-CODEC are documented here.

## [1.0.0-beta] — 2026-03-20

### 🎯 Milestone: Beta — Full ecosystem functional

### Added — Core Codec
- Lossless temporal compression via marked point processes (Algorithm 1)
- 30-bit arithmetic encoder/decoder with CDF table
- Threshold-based optimal code selection (L₁/L₃/L₄) in O(1)
- Multi-scale spatial pyramid (residual sparsity 98.2%, gain 6.2×)
- Heuristic framework/family selection calibrated on 50,000 processes
- RGB→palette quantization (Median Cut) with PSNR measurement
- .ppv container format v2 with seek table (O(1) random access)

### Added — Protocols
- STV-URI 1.0: 3 schemes (ppv/ppl/ppv+https), 11 fragment keys, resolver
- PPSP 1.0: 8 binary message types, session management, delta viewport

### Added — Applications
- **PP-Streamer**: Tokio WebSocket server, VOD + Live (circular buffer, time-shifting), 8 compressed-domain operations, subscriber model with push notifications
- **PP-Player**: Full MVC architecture (22 Intents, 18 ViewUpdates, 8 Controllers, 7 Data Adapters), software renderer for testing
- **PP-Browser**: PPML engine (8 Custom Elements registry), viewport manager with block cache and progressive loading, PPSP client state machine, JSON bridge for WASM interop
- **PP-Admin**: File catalog, dashboard KPIs, access control with wildcard rules, REST API backend

### Added — SDK & Tooling
- Python SDK via PyO3 (15 functions): encode/decode/query/info/uri/psnr
- CI/CD: GitHub Actions (6 jobs), release pipeline (crates.io + PyPI)
- Docker: multi-stage Dockerfiles, docker-compose with PostgreSQL + Prometheus + Grafana
- Local audit script (7 safety checks)
- 10-profile benchmark suite with JSON reports

### Added — Testing
- 344 tests total (288 Rust + 56 Python), 0 failures
- Property-based tests: 300+ pixel configs, 100 random video configs
- Adversarial tests: corrupted files, malicious URIs, PPSP fuzzing, edge cases
- Integration E2E: RGB → quantize → encode → PPSP → decode → compare

### Fixed
- `PpvFile::deserialize` panic on truncated data (bounds-checked `read_u32`)

### Performance
- Surveillance 5%: 62:1 (pyramid, lossless)
- Satellite 2%: 108:1 (pyramid, lossless)
- Medical 3%: 60:1 (pyramid, lossless)
- Dense 80%: 4.7:1 (pyramid, lossless)
- Encode throughput: 12 MPx/s (single-thread)
- Decode throughput: 48 MPx/s

### Specifications — 105 pages
- PPML 1.0 + STV-URI 1.0 + PPSP 1.0
- Merise: MCD (24 entities) → MPD → MCT (16 treatments) → MLD → MOT
- UML: 37 classes, 5 diagrams
- Use Cases: 52 UC, 8 actors
- SFD: 14 interfaces, 3 applications
- MVC: 22 Intents, 18 ViewUpdates, 8 Controllers, 8 Adapters
- Development plan: 12 months, 52 sprints, 4 phases
- Patent drafts: 4 families, 19 claims

## [0.1.0-alpha] — 2026-03-20

### Added
- Initial codec core (Algorithm 1, arithmetic coder, encoder/decoder)
- Spatial pyramid with Rayon parallelization
- Heuristic integration from FORGE-SIM
