//! # Codes Universels d'Entiers — Elias δ et γ
//!
//! δ(j) = γ(|β(j)|) · β̂(j) — code delta, asymptotiquement optimal
//! γ(j) = 0^{j-1} · 1 · β̂(j) — code gamma
//!
//! Utilisé pour encoder N (nombre de sauts) et les indices de palette.
//! Invariant : length(δ(j)) = ⌊log₂j⌋ + 2·⌊log₂(1+⌊log₂j⌋)⌋ + 1

#![forbid(unsafe_code)]

use crate::bits::{BitWriter, BitReader};

/// Write Elias gamma code for j ≥ 1.
pub fn write_gamma(writer: &mut BitWriter, j: u64) {
    assert!(j >= 1, "gamma code requires j ≥ 1, got {}", j);
    let n = 64 - j.leading_zeros() as u32; // ⌊log₂(j)⌋ + 1
    // Write (n-1) zeros then the binary representation of j in n bits
    for _ in 0..n - 1 {
        writer.write_bit(0);
    }
    writer.write_bits(j, n);
}

/// Read Elias gamma code, returns j ≥ 1.
pub fn read_gamma(reader: &mut BitReader) -> u64 {
    let mut n = 0u32;
    while reader.read_bit() == 0 {
        n += 1;
    }
    // We already read the leading 1-bit
    let mut value = 1u64;
    for _ in 0..n {
        value = (value << 1) | reader.read_bit() as u64;
    }
    value
}

/// Write Elias delta code for j ≥ 1.
pub fn write_delta(writer: &mut BitWriter, j: u64) {
    assert!(j >= 1, "delta code requires j ≥ 1, got {}", j);
    let n = 64 - j.leading_zeros() as u32; // ⌊log₂(j)⌋ + 1 = number of bits
    write_gamma(writer, n as u64);
    // Write the last (n-1) bits of j (the leading 1 is implicit)
    if n > 1 {
        writer.write_bits(j, n - 1);
    }
}

/// Read Elias delta code, returns j ≥ 1.
pub fn read_delta(reader: &mut BitReader) -> u64 {
    let n = read_gamma(reader) as u32;
    if n == 1 {
        return 1;
    }
    let mut value = 1u64; // implicit leading 1
    for _ in 0..n - 1 {
        value = (value << 1) | reader.read_bit() as u64;
    }
    value
}

/// Write a fixed-width integer in `bits` bits.
pub fn write_fixed(writer: &mut BitWriter, value: u64, bits: u32) {
    writer.write_bits(value, bits);
}

/// Read a fixed-width integer in `bits` bits.
pub fn read_fixed(reader: &mut BitReader, bits: u32) -> u64 {
    reader.read_bits(bits)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gamma_roundtrip() {
        for j in 1..=1000 {
            let mut w = BitWriter::new();
            write_gamma(&mut w, j);
            let data = w.finish();
            let mut r = BitReader::new(&data);
            let decoded = read_gamma(&mut r);
            assert_eq!(j, decoded, "gamma roundtrip failed for j={}", j);
        }
    }

    #[test]
    fn delta_roundtrip() {
        for j in 1..=1000 {
            let mut w = BitWriter::new();
            write_delta(&mut w, j);
            let data = w.finish();
            let mut r = BitReader::new(&data);
            let decoded = read_delta(&mut r);
            assert_eq!(j, decoded, "delta roundtrip failed for j={}", j);
        }
    }

    #[test]
    fn gamma_known_values() {
        // γ(1) = 1 (1 bit), γ(2) = 010 (3 bits), γ(3) = 011, γ(4) = 00100
        let mut w = BitWriter::new();
        write_gamma(&mut w, 1);
        assert_eq!(w.bit_len(), 1);
    }

    #[test]
    fn delta_sequence_roundtrip() {
        let values: Vec<u64> = vec![1, 5, 42, 256, 1000, 65535, 1, 3];
        let mut w = BitWriter::new();
        for &v in &values {
            write_delta(&mut w, v);
        }
        let bits = w.bit_len();
        let data = w.finish();
        let mut r = BitReader::with_bit_len(&data, bits);
        for &expected in &values {
            let got = read_delta(&mut r);
            assert_eq!(expected, got);
        }
    }
}
