//! Bit-level I/O — MSB-first packing into Vec<u8>.

/// Writes bits MSB-first into a growable byte buffer.
#[derive(Debug, Clone)]
pub struct BitWriter {
    buf: Vec<u8>,
    current: u8,
    bits_in_current: u32,
}

impl BitWriter {
    pub fn new() -> Self {
        Self { buf: Vec::new(), current: 0, bits_in_current: 0 }
    }

    pub fn with_capacity(bytes: usize) -> Self {
        Self { buf: Vec::with_capacity(bytes), current: 0, bits_in_current: 0 }
    }

    /// Write a single bit (0 or 1).
    #[inline]
    pub fn write_bit(&mut self, bit: u8) {
        self.current = (self.current << 1) | (bit & 1);
        self.bits_in_current += 1;
        if self.bits_in_current == 8 {
            self.buf.push(self.current);
            self.current = 0;
            self.bits_in_current = 0;
        }
    }

    /// Write `count` bits from `value` (MSB-first, top bits of value).
    pub fn write_bits(&mut self, value: u64, count: u32) {
        assert!(count <= 64);
        for i in (0..count).rev() {
            self.write_bit(((value >> i) & 1) as u8);
        }
    }

    /// Total bits written.
    pub fn bit_len(&self) -> usize {
        self.buf.len() * 8 + self.bits_in_current as usize
    }

    /// Flush remaining bits (pad with zeros) and return the buffer.
    pub fn finish(mut self) -> Vec<u8> {
        if self.bits_in_current > 0 {
            self.current <<= 8 - self.bits_in_current;
            self.buf.push(self.current);
        }
        self.buf
    }

    /// Get reference to the underlying buffer (without flushing).
    pub fn as_bytes(&self) -> &[u8] {
        &self.buf
    }
}

impl Default for BitWriter {
    fn default() -> Self { Self::new() }
}

/// Reads bits MSB-first from a byte slice.
#[derive(Debug, Clone)]
pub struct BitReader<'a> {
    data: &'a [u8],
    byte_pos: usize,
    bit_pos: u32, // 0..8 within current byte
    total_bits: usize,
}

impl<'a> BitReader<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        Self { data, byte_pos: 0, bit_pos: 0, total_bits: data.len() * 8 }
    }

    pub fn with_bit_len(data: &'a [u8], total_bits: usize) -> Self {
        Self { data, byte_pos: 0, bit_pos: 0, total_bits }
    }

    /// Read a single bit. Returns 0 if past end (safe padding).
    #[inline]
    pub fn read_bit(&mut self) -> u8 {
        let abs_pos = self.byte_pos * 8 + self.bit_pos as usize;
        if abs_pos >= self.total_bits || self.byte_pos >= self.data.len() {
            return 0; // safe padding for arithmetic decoder
        }
        let bit = (self.data[self.byte_pos] >> (7 - self.bit_pos)) & 1;
        self.bit_pos += 1;
        if self.bit_pos == 8 {
            self.bit_pos = 0;
            self.byte_pos += 1;
        }
        bit
    }

    /// Read `count` bits as a u64 (MSB-first).
    pub fn read_bits(&mut self, count: u32) -> u64 {
        let mut val = 0u64;
        for _ in 0..count {
            val = (val << 1) | self.read_bit() as u64;
        }
        val
    }

    /// Bits remaining.
    pub fn remaining(&self) -> usize {
        let consumed = self.byte_pos * 8 + self.bit_pos as usize;
        self.total_bits.saturating_sub(consumed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_single_bits() {
        let mut w = BitWriter::new();
        let pattern = [1u8, 0, 1, 1, 0, 0, 1, 0, 1];
        for &b in &pattern {
            w.write_bit(b);
        }
        let bits_written = w.bit_len();
        let data = w.finish();
        let mut r = BitReader::with_bit_len(&data, bits_written);
        for &expected in &pattern {
            assert_eq!(r.read_bit(), expected);
        }
    }

    #[test]
    fn roundtrip_multi_bits() {
        let mut w = BitWriter::new();
        w.write_bits(0b11010, 5);
        w.write_bits(0b110, 3);
        w.write_bits(42, 8);
        let data = w.finish();
        let mut r = BitReader::new(&data);
        assert_eq!(r.read_bits(5), 0b11010);
        assert_eq!(r.read_bits(3), 0b110);
        assert_eq!(r.read_bits(8), 42);
    }

    #[test]
    fn reader_safe_padding() {
        let data = vec![0xFF]; // 8 bits
        let mut r = BitReader::new(&data);
        for _ in 0..8 { r.read_bit(); }
        // Past end → returns 0
        assert_eq!(r.read_bit(), 0);
        assert_eq!(r.read_bit(), 0);
    }

    #[test]
    fn large_write() {
        let mut w = BitWriter::with_capacity(1024);
        for i in 0..10000u64 {
            w.write_bits(i & 0xFF, 8);
        }
        assert_eq!(w.bit_len(), 80000);
        let data = w.finish();
        assert_eq!(data.len(), 10000);
    }
}
