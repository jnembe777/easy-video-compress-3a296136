//! # Combinatoire exacte — log₂(C(r,N)) via log-gamma
//!
//! Pour r ≤ 900, C(r, r/2) ≈ 10^270 → dépasse u128.
//! On travaille en log₂ via la relation :
//!   log₂(C(r,N)) = [ln_gamma(r+1) - ln_gamma(N+1) - ln_gamma(r-N+1)] / ln(2)
//!
//! Référence : docB Section 5, utilisé dans L₄(r,m,N) = log₂(N) + log₂(C(r,N)) + N·log₂(m)

#![forbid(unsafe_code)]

use std::f64::consts::LN_2;

/// Lanczos approximation of ln(Γ(z)) for z > 0.
/// Accuracy: ~15 significant digits.
fn ln_gamma(z: f64) -> f64 {
    // For integer arguments, this gives ln((z-1)!)
    if z < 0.5 {
        // Reflection formula
        let pi = std::f64::consts::PI;
        return (pi / (pi * z).sin()).ln() - ln_gamma(1.0 - z);
    }
    
    // Lanczos coefficients (g=7, n=9)
    const COEFFS: [f64; 9] = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.13857109526572012,
        9.9843695780195716e-6,
        1.5056327351493116e-7,
    ];
    
    let z = z - 1.0;
    let mut x = COEFFS[0];
    for i in 1..9 {
        x += COEFFS[i] / (z + i as f64);
    }
    let t = z + 7.5; // g + 0.5
    0.5 * (2.0 * std::f64::consts::PI).ln() + (z + 0.5) * t.ln() - t + x.ln()
}

/// Compute log₂(C(r, n)) = log₂(r! / (n! · (r-n)!))
///
/// Uses log-gamma for numerical stability.
/// Returns 0.0 for n=0 or n=r, -∞ is not possible since all values ≥ 0.
///
/// # Panics
/// Panics if n > r.
pub fn log2_binom(r: u64, n: u64) -> f64 {
    assert!(n <= r, "n ({}) must be <= r ({})", n, r);
    if n == 0 || n == r {
        return 0.0;
    }
    if n == 1 || n == r - 1 {
        return (r as f64).log2();
    }
    
    let lr = ln_gamma(r as f64 + 1.0);
    let ln = ln_gamma(n as f64 + 1.0);
    let lrn = ln_gamma((r - n) as f64 + 1.0);
    
    (lr - ln - lrn) / LN_2
}

/// Compute log₂(n) for n > 0. Returns f64::NEG_INFINITY for n=0.
#[inline]
pub fn log2(n: u64) -> f64 {
    if n == 0 {
        f64::NEG_INFINITY
    } else {
        (n as f64).log2()
    }
}

/// Compute the code length L₁(r, m) = r · log₂(m)
#[inline]
pub fn l1(r: u64, m: u64) -> f64 {
    r as f64 * log2(m)
}

/// Compute the code length L₃(r, m, N) = r + N · log₂(m)
#[inline]
pub fn l3(r: u64, m: u64, n: u64) -> f64 {
    r as f64 + n as f64 * log2(m)
}

/// Compute the code length L₄(r, m, N) = log₂(N) + log₂(C(r,N)) + N · log₂(m)
#[inline]
pub fn l4(r: u64, m: u64, n: u64) -> f64 {
    if n == 0 {
        return 0.0; // No jumps → no bits needed
    }
    log2(n) + log2_binom(r, n) + n as f64 * log2(m)
}

/// Compute the optimized code C_K (docB Eq 56):
/// C_K = min(log₂(N), log₂(r−N)) + log₂(C(r,N)) + N·log₂(m)
///
/// Saves 1 bit when N > r/2 by encoding (r−N) instead of N.
#[inline]
pub fn code_ck(r: u64, m: u64, n: u64) -> f64 {
    if n == 0 {
        return 0.0;
    }
    if n == r {
        return 0.0; // All positions occupied → 0 bits for positions
    }
    let count_bits = log2(n).min(log2(r - n));
    count_bits + log2_binom(r, n) + n as f64 * log2(m)
}

/// Compute log₂(g(N)) = log₂(N · C(r,N)) = log₂(N) + log₂(C(r,N))
/// Used for L₃ vs L₄ comparison: L₄ < L₃ ⟺ g(N) < 2^r
#[inline]
pub fn log2_g(r: u64, n: u64) -> f64 {
    if n == 0 || n == r {
        return f64::NEG_INFINITY;
    }
    log2(n) + log2_binom(r, n)
}

/// Compute log₂(h(N)) = log₂(N · C(r,N) · m^N) = log₂(N) + log₂(C(r,N)) + N·log₂(m)
/// Used for L₁ vs L₄ comparison: L₄ < L₁ ⟺ h(N) < m^r
#[inline]
pub fn log2_h(r: u64, m: u64, n: u64) -> f64 {
    if n == 0 {
        return f64::NEG_INFINITY;
    }
    log2(n) + log2_binom(r, n) + n as f64 * log2(m)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn binom_known_values() {
        // C(10, 0) = 1 → log₂ = 0
        assert!((log2_binom(10, 0) - 0.0).abs() < 1e-10);
        // C(10, 1) = 10 → log₂ ≈ 3.3219
        assert!((log2_binom(10, 1) - 10f64.log2()).abs() < 1e-10);
        // C(10, 5) = 252 → log₂ ≈ 7.977
        assert!((log2_binom(10, 5) - 252f64.log2()).abs() < 1e-6);
        // C(20, 10) = 184756 → log₂ ≈ 17.495
        assert!((log2_binom(20, 10) - 184756f64.log2()).abs() < 1e-4);
    }

    #[test]
    fn binom_symmetry() {
        for r in [10, 50, 100, 500, 900] {
            for n in [0, 1, r / 4, r / 2, 3 * r / 4, r - 1, r] {
                let a = log2_binom(r, n);
                let b = log2_binom(r, r - n);
                assert!((a - b).abs() < 1e-6, "symmetry failed for r={}, n={}: {} vs {}", r, n, a, b);
            }
        }
    }

    #[test]
    fn binom_large_r900() {
        // C(900, 450) ≈ 10^270, log₂ ≈ 897.8
        let val = log2_binom(900, 450);
        assert!(val > 890.0 && val < 900.0, "log2_binom(900,450) = {} out of range", val);
    }

    #[test]
    fn code_lengths_l4_lt_l2() {
        // Proposition 2.1: L₄ < L₂ almost surely
        // L₂ = log(N) + N·log(r·m), L₄ = log(N) + log(C(r,N)) + N·log(m)
        // L₄ < L₂ ⟺ log(C(r,N)) < N·log(r) ⟺ C(r,N) < r^N — true for all N
        for r in [16, 64, 256] {
            for m in [2, 8, 32] {
                for n in 1..r.min(50) {
                    let len4 = l4(r, m, n);
                    let len2 = log2(n) + n as f64 * log2(r * m);
                    assert!(len4 <= len2 + 1e-6, 
                        "L4 ({:.2}) > L2 ({:.2}) for r={}, m={}, N={}", len4, len2, r, m, n);
                }
            }
        }
    }

    #[test]
    fn delta_threshold_basic() {
        // δ_{r,m} = ⌈r·(1 − 1/log₂(m))⌉
        // For r=100, m=256: δ = ⌈100·(1-1/8)⌉ = ⌈87.5⌉ = 88
        let r = 100u64;
        let m = 256u64;
        let delta = (r as f64 * (1.0 - 1.0 / log2(m))).ceil() as u64;
        assert_eq!(delta, 88);
    }

    #[test]
    fn code_ck_saves_bits() {
        // C_K should be ≤ L₄ for all N, and strictly less when N >> r/2
        let r = 100u64;
        let m = 16u64;
        for n in 1..r {
            let ck = code_ck(r, m, n);
            let len4 = l4(r, m, n);
            assert!(ck <= len4 + 1e-10,
                "C_K ({:.2}) > L4 ({:.2}) for N={}", ck, len4, n);
        }
        // For N well above r/2 (e.g., N > 3r/4), savings should be substantial
        for n in (3 * r / 4)..r {
            let ck = code_ck(r, m, n);
            let len4 = l4(r, m, n);
            assert!(ck < len4 - 0.1,
                "C_K should save bits for N={} >> r/2: C_K={:.2}, L4={:.2}", n, ck, len4);
        }
    }

    #[test]
    fn g_function_unimodal() {
        // g(N) = N·C(r,N) has a single maximum near r/2
        let r = 100u64;
        let mut prev = f64::NEG_INFINITY;
        let mut found_peak = false;
        for n in 1..r {
            let val = log2_g(r, n);
            if val < prev && !found_peak {
                found_peak = true;
                // Peak should be near r/2
                assert!((n as f64 - r as f64 / 2.0).abs() < 5.0,
                    "g peak at N={}, expected near {}", n - 1, r / 2);
            }
            if found_peak {
                assert!(val <= prev + 1e-6, "g not unimodal after peak at N={}", n);
            }
            prev = val;
        }
        assert!(found_peak, "g should have a peak");
    }
}
