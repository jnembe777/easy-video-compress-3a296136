//! # PPSP Handler — Message processing
//! Ref: modMOT T13-T16, PPSP 1.0 §3.2-3.5
#![forbid(unsafe_code)]

use std::collections::HashMap;
use pp_codec::encoder::PpvFile;
use pp_codec::ppsp::*;
use pp_codec::stv_uri::{StvUri, StvFragment, resolve};
use crate::session::{SessionManager, AccessLevel, ViewportState, BlockLod};

/// File catalog: path → loaded PpvFile.
pub struct FileCatalog {
    files: HashMap<String, PpvFile>,
}

impl FileCatalog {
    pub fn new() -> Self { Self { files: HashMap::new() } }

    pub fn load_file(&mut self, path: &str, data: &[u8]) -> Result<(), String> {
        let ppv = PpvFile::deserialize(data)
            .ok_or_else(|| format!("invalid .ppv: {}", path))?;
        self.files.insert(path.to_string(), ppv);
        Ok(())
    }

    pub fn get(&self, path: &str) -> Option<&PpvFile> { self.files.get(path) }
    pub fn list(&self) -> Vec<&str> { self.files.keys().map(|s| s.as_str()).collect() }
}

/// PPSP request handler.
pub struct PpspHandler {
    pub sessions: SessionManager,
    pub catalog: FileCatalog,
}

impl PpspHandler {
    pub fn new() -> Self {
        Self { sessions: SessionManager::new(), catalog: FileCatalog::new() }
    }

    pub fn handle(&mut self, msg: &PpspMessage) -> Vec<PpspMessage> {
        match msg {
            PpspMessage::Open(m) => self.handle_open(m),
            PpspMessage::Seek(m) => self.handle_seek(m),
            PpspMessage::Query(m) => self.handle_query(m),
            PpspMessage::Close(m) => self.handle_close(m),
            _ => vec![PpspMessage::Error(ErrorMsg {
                code: 400, message: "unexpected message type".into(),
            })],
        }
    }

    /// T13: Open session.
    fn handle_open(&mut self, msg: &OpenMsg) -> Vec<PpspMessage> {
        let uri = match StvUri::parse(&msg.uri) {
            Ok(u) => u,
            Err(e) => return vec![PpspMessage::Error(ErrorMsg {
                code: 400, message: format!("invalid URI: {}", e),
            })],
        };
        let file_path = uri.path.clone();
        let ppv = match self.catalog.get(&file_path) {
            Some(p) => p,
            None => return vec![PpspMessage::Error(ErrorMsg {
                code: 404, message: format!("not found: {}", file_path),
            })],
        };
        let access = match msg.access {
            pp_codec::ppsp::AccessLevel::Read => AccessLevel::Read,
            pp_codec::ppsp::AccessLevel::Query => AccessLevel::Query,
            pp_codec::ppsp::AccessLevel::Write => AccessLevel::Write,
        };
        let bs = ppv.block_size;
        let bx = (ppv.width + bs - 1) / bs;
        let by = (ppv.height + bs - 1) / bs;
        let sid = self.sessions.open(file_path, access);

        vec![PpspMessage::Header(HeaderMsg {
            session_id: sid,
            width: ppv.width, height: ppv.height, frames: ppv.frames,
            block_size: bs, palette_size: ppv.palette_size, num_blocks: bx * by,
        })]
    }

    /// T14: SEEK — compute delta and return DATA.
    fn handle_seek(&mut self, msg: &SeekMsg) -> Vec<PpspMessage> {
        let sid = msg.session_id;
        let session = match self.sessions.get(&sid) {
            Some(s) => s,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 410, message: "expired".into() })],
        };
        let ppv = match self.catalog.get(&session.file_path) {
            Some(p) => p,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 500, message: "file gone".into() })],
        };

        let frag = match parse_fragment_string(&msg.fragment) {
            Some(f) => f,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 400, message: "bad fragment".into() })],
        };

        let plan = resolve(&frag, ppv.width, ppv.height, ppv.frames, ppv.block_size);
        let new_vp = ViewportState {
            visible_blocks: plan.block_ids.clone(),
            lod_map: plan.block_ids.iter().map(|&id| (id, plan.lod)).collect(),
            frame_start: plan.frame_range.0,
            frame_end: plan.frame_range.1,
            filters: plan.filters,
        };

        // Need to reborrow — compute delta first
        let delta = self.sessions.get(&sid).unwrap().compute_delta(&new_vp);

        let mut responses: Vec<PpspMessage> = Vec::new();
        let mut total_bytes = 0u64;

        for bl in &delta {
            if bl.block_id < ppv.block_data.len() {
                let data = ppv.block_data[bl.block_id].clone();
                total_bytes += data.len() as u64;
                responses.push(PpspMessage::Data(DataMsg {
                    block_id: bl.block_id as u32, lod: bl.lod,
                    frame_start: plan.frame_range.0, frame_end: plan.frame_range.1,
                    data,
                }));
            }
        }

        if let Some(s) = self.sessions.get_mut(&sid) {
            s.apply_seek(new_vp, &delta);
            s.record_tx(delta.len() as u64, total_bytes);
        }

        if responses.is_empty() {
            // Delta is zero — everything already sent
            responses.push(PpspMessage::Data(DataMsg {
                block_id: u32::MAX, lod: 0,
                frame_start: plan.frame_range.0, frame_end: plan.frame_range.1,
                data: Vec::new(),
            }));
        }
        responses
    }

    /// T15: QUERY — evaluate on block metadata without decompression.
    fn handle_query(&mut self, msg: &QueryMsg) -> Vec<PpspMessage> {
        let sid = msg.session_id;
        let session = match self.sessions.get(&sid) {
            Some(s) => s,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 410, message: "expired".into() })],
        };
        if session.access == AccessLevel::Read {
            return vec![PpspMessage::Error(ErrorMsg { code: 403, message: "query needs Query access".into() })];
        }
        let ppv = match self.catalog.get(&session.file_path) {
            Some(p) => p,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 500, message: "file gone".into() })],
        };

        let bs = ppv.block_size;
        let blocks_x = ((ppv.width + bs - 1) / bs) as usize;
        let avg_bits: f64 = ppv.block_bits.iter().sum::<usize>() as f64 / ppv.block_bits.len().max(1) as f64;
        let expr = msg.expression.to_lowercase();

        let mut matches = Vec::new();
        for (i, &bits) in ppv.block_bits.iter().enumerate() {
            let activity = bits as f64 / avg_bits.max(1.0);
            let bx = (i % blocks_x) as u32;
            let by = (i / blocks_x) as u32;

            let mut ok = true;
            if let Some(thr) = extract_threshold(&expr, "activity") {
                if activity < thr { ok = false; }
            }
            if ok {
                matches.push(BlockMatch {
                    block_id: i as u32, bx, by,
                    n_total: bits as u32, family: 2, activity: activity as f32,
                });
            }
        }

        if let Some(s) = self.sessions.get_mut(&sid) { s.stats.queries_count += 1; }

        vec![PpspMessage::Result(ResultMsg {
            request_id: sid, total_count: matches.len() as u32, matches,
        })]
    }

    /// T16: Close session.
    fn handle_close(&mut self, msg: &CloseMsg) -> Vec<PpspMessage> {
        let sid = msg.session_id;
        match self.sessions.close(&sid) {
            Some(stats) => vec![PpspMessage::Error(ErrorMsg {
                code: 200,
                message: format!("closed: {} blk, {} B, {} seeks, {} queries",
                    stats.blocks_sent, stats.bytes_sent, stats.seeks_count, stats.queries_count),
            })],
            None => vec![PpspMessage::Error(ErrorMsg { code: 410, message: "not found".into() })],
        }
    }
}

fn parse_fragment_string(s: &str) -> Option<StvFragment> {
    let full = format!("ppv://x/f.ppv#{}", s);
    StvUri::parse(&full).ok().map(|u| u.fragment)
}

fn extract_threshold(expr: &str, field: &str) -> Option<f64> {
    if let Some(pos) = expr.find(field) {
        let after = &expr[pos + field.len()..];
        let after = after.trim_start_matches(|c: char| c == ' ' || c == '>' || c == '=');
        let num: String = after.chars().take_while(|c| c.is_ascii_digit() || *c == '.').collect();
        num.parse().ok()
    } else { None }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_handler() -> PpspHandler {
        let mut h = PpspHandler::new();
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        let ppv = pp_codec::encoder::encode_video(&frames, 8, 8, 8, 4);
        h.catalog.load_file("/cam.ppv", &ppv.serialize()).unwrap();
        h
    }

    #[test]
    fn test_open_ok() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(),
            access: pp_codec::ppsp::AccessLevel::Query,
        }));
        assert!(matches!(r[0], PpspMessage::Header(_)));
        if let PpspMessage::Header(hdr) = &r[0] {
            assert_eq!(hdr.width, 8);
            assert_eq!(hdr.frames, 16);
        }
    }

    #[test]
    fn test_open_404() {
        let mut h = PpspHandler::new();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/missing.ppv".into(), access: pp_codec::ppsp::AccessLevel::Read,
        }));
        if let PpspMessage::Error(e) = &r[0] { assert_eq!(e.code, 404); }
        else { panic!("expected 404"); }
    }

    #[test]
    fn test_seek_data() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        let r = h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:15".into() }));
        let data_count = r.iter().filter(|m| matches!(m, PpspMessage::Data(d) if !d.data.is_empty())).count();
        assert!(data_count >= 1);
    }

    #[test]
    fn test_seek_delta_zero() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        let r1 = h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:15".into() }));
        let c1 = r1.iter().filter(|m| matches!(m, PpspMessage::Data(d) if !d.data.is_empty())).count();

        let r2 = h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:15".into() }));
        let c2 = r2.iter().filter(|m| matches!(m, PpspMessage::Data(d) if !d.data.is_empty())).count();
        assert!(c2 < c1, "delta should be zero: {} vs {}", c2, c1);
    }

    #[test]
    fn test_query_ok() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Query,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        let r = h.handle(&PpspMessage::Query(QueryMsg {
            session_id: sid, select: SelectType::Blocks, expression: "activity > 0.5".into(),
        }));
        assert!(matches!(r[0], PpspMessage::Result(_)));
    }

    #[test]
    fn test_query_403() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        let r = h.handle(&PpspMessage::Query(QueryMsg {
            session_id: sid, select: SelectType::Blocks, expression: "activity > 0".into(),
        }));
        if let PpspMessage::Error(e) = &r[0] { assert_eq!(e.code, 403); }
        else { panic!("expected 403"); }
    }

    #[test]
    fn test_close() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        let r = h.handle(&PpspMessage::Close(CloseMsg { session_id: sid }));
        if let PpspMessage::Error(e) = &r[0] { assert_eq!(e.code, 200); }
        else { panic!("expected 200"); }
        assert_eq!(h.sessions.count(), 0);
    }

    #[test]
    fn test_full_lifecycle() {
        let mut h = make_handler();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/cam.ppv".into(), access: pp_codec::ppsp::AccessLevel::Query,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:8".into() }));
        let r = h.handle(&PpspMessage::Query(QueryMsg {
            session_id: sid, select: SelectType::Blocks, expression: "activity > 0.0".into(),
        }));
        assert!(matches!(r[0], PpspMessage::Result(_)));

        let r = h.handle(&PpspMessage::Close(CloseMsg { session_id: sid }));
        assert!(matches!(r[0], PpspMessage::Error(ErrorMsg { code: 200, .. })));
    }
}
