//! # Live Streaming — Circular buffer + time-shifting
//!
//! Manages live video ingest from encoders via ppl:// scheme.
//! - Circular buffer of micro-GOPs (configurable depth)
//! - Time-shifting: clients can seek backward within buffer window
//! - Frame counter: monotonic, maps to buffer positions
//! - Writer/reader separation: one writer (encoder), many readers (clients)
//!
//! Ref: planDEV S25-S28, specS ppl://, STV-URI t=-N

#![forbid(unsafe_code)]

use std::collections::VecDeque;

/// A micro-GOP: a group of compressed blocks for a range of frames.
/// In live mode, data arrives as micro-GOPs rather than full files.
#[derive(Debug, Clone)]
pub struct MicroGop {
    pub gop_id: u64,
    pub frame_start: u64,       // absolute frame number
    pub frame_count: u32,       // number of frames in this GOP
    pub block_count: u32,       // number of spatial blocks
    pub blocks: Vec<LiveBlock>, // compressed block data
    pub timestamp_ms: u64,      // wall-clock time at ingest
    pub total_bytes: usize,
}

/// A single compressed block within a micro-GOP.
#[derive(Debug, Clone)]
pub struct LiveBlock {
    pub block_id: u32,
    pub data: Vec<u8>,          // compressed bitstream
    pub bits: usize,
    pub n_events: u32,          // number of events in this block (activity proxy)
}

/// Configuration for the live circular buffer.
#[derive(Debug, Clone)]
pub struct LiveConfig {
    pub max_gops: usize,            // maximum GOPs in buffer (depth)
    pub max_memory_bytes: usize,    // memory cap
    pub gop_frame_count: u32,       // frames per GOP (e.g. 16, 32)
    pub width: u32,
    pub height: u32,
    pub block_size: u32,
    pub palette_size: u32,
}

impl Default for LiveConfig {
    fn default() -> Self {
        LiveConfig {
            max_gops: 256,              // ~256 GOPs × 32 frames = 8192 frames ≈ 4.5 min @ 30fps
            max_memory_bytes: 256 * 1024 * 1024, // 256 MB
            gop_frame_count: 32,
            width: 1920, height: 1080,
            block_size: 16, palette_size: 8,
        }
    }
}

/// Live circular buffer.
#[derive(Debug)]
pub struct LiveBuffer {
    config: LiveConfig,
    buffer: VecDeque<MicroGop>,
    next_gop_id: u64,
    total_frames_ingested: u64,
    total_bytes_ingested: u64,
    total_gops_dropped: u64,
    current_memory: usize,
}

impl LiveBuffer {
    pub fn new(config: LiveConfig) -> Self {
        LiveBuffer {
            config,
            buffer: VecDeque::new(),
            next_gop_id: 0,
            total_frames_ingested: 0,
            total_bytes_ingested: 0,
            total_gops_dropped: 0,
            current_memory: 0,
        }
    }

    /// Ingest a new micro-GOP from the encoder.
    /// If buffer is full, oldest GOP is evicted (circular).
    pub fn ingest(&mut self, blocks: Vec<LiveBlock>, frame_count: u32, timestamp_ms: u64) -> u64 {
        let total_bytes: usize = blocks.iter().map(|b| b.data.len()).sum();
        let block_count = blocks.len() as u32;

        let gop = MicroGop {
            gop_id: self.next_gop_id,
            frame_start: self.total_frames_ingested,
            frame_count,
            block_count,
            blocks,
            timestamp_ms,
            total_bytes,
        };

        let gop_id = gop.gop_id;
        self.next_gop_id += 1;
        self.total_frames_ingested += frame_count as u64;
        self.total_bytes_ingested += total_bytes as u64;
        self.current_memory += total_bytes;

        self.buffer.push_back(gop);

        // Evict oldest GOPs if over limits
        while self.buffer.len() > self.config.max_gops
            || self.current_memory > self.config.max_memory_bytes
        {
            if let Some(old) = self.buffer.pop_front() {
                self.current_memory = self.current_memory.saturating_sub(old.total_bytes);
                self.total_gops_dropped += 1;
            } else {
                break;
            }
        }

        gop_id
    }

    /// Resolve a negative time offset to an absolute frame.
    /// t=-30 means "30 frames before current head".
    /// Ref: STV-URI 1.0, ppl:// scheme, t=-N
    pub fn resolve_negative_time(&self, offset: i64) -> Option<u64> {
        if offset >= 0 {
            return Some(offset as u64);
        }
        let abs_offset = (-offset) as u64;
        if abs_offset > self.total_frames_ingested {
            return None; // before buffer start
        }
        Some(self.total_frames_ingested - abs_offset)
    }

    /// Find the GOP containing a given absolute frame.
    pub fn find_gop_for_frame(&self, abs_frame: u64) -> Option<&MicroGop> {
        self.buffer.iter().find(|gop| {
            abs_frame >= gop.frame_start
                && abs_frame < gop.frame_start + gop.frame_count as u64
        })
    }

    /// Get GOPs covering a frame range [start, end].
    pub fn get_gops_in_range(&self, start_frame: u64, end_frame: u64) -> Vec<&MicroGop> {
        self.buffer.iter().filter(|gop| {
            let gop_end = gop.frame_start + gop.frame_count as u64 - 1;
            gop.frame_start <= end_frame && gop_end >= start_frame
        }).collect()
    }

    /// Get the N most recent GOPs (for time-shifting catch-up).
    pub fn recent_gops(&self, count: usize) -> Vec<&MicroGop> {
        self.buffer.iter().rev().take(count).collect()
    }

    /// Current buffer depth in frames.
    pub fn buffered_frames(&self) -> u64 {
        if self.buffer.is_empty() { return 0; }
        let first = self.buffer.front().unwrap();
        let last = self.buffer.back().unwrap();
        (last.frame_start + last.frame_count as u64) - first.frame_start
    }

    /// Oldest available frame.
    pub fn oldest_frame(&self) -> Option<u64> {
        self.buffer.front().map(|g| g.frame_start)
    }

    /// Newest available frame.
    pub fn newest_frame(&self) -> Option<u64> {
        self.buffer.back().map(|g| g.frame_start + g.frame_count as u64 - 1)
    }

    /// Buffer fullness as percentage.
    pub fn fullness(&self) -> f64 {
        self.buffer.len() as f64 / self.config.max_gops as f64
    }

    /// Statistics.
    pub fn stats(&self) -> LiveStats {
        LiveStats {
            gops_in_buffer: self.buffer.len(),
            frames_in_buffer: self.buffered_frames(),
            memory_bytes: self.current_memory,
            total_ingested: self.total_frames_ingested,
            total_bytes: self.total_bytes_ingested,
            gops_dropped: self.total_gops_dropped,
            fullness: self.fullness(),
            oldest_frame: self.oldest_frame(),
            newest_frame: self.newest_frame(),
        }
    }

    pub fn config(&self) -> &LiveConfig { &self.config }
    pub fn gop_count(&self) -> usize { self.buffer.len() }
}

/// Live buffer statistics.
#[derive(Debug, Clone, serde::Serialize)]
pub struct LiveStats {
    pub gops_in_buffer: usize,
    pub frames_in_buffer: u64,
    pub memory_bytes: usize,
    pub total_ingested: u64,
    pub total_bytes: u64,
    pub gops_dropped: u64,
    pub fullness: f64,
    pub oldest_frame: Option<u64>,
    pub newest_frame: Option<u64>,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_blocks(n: u32, bytes_each: usize) -> Vec<LiveBlock> {
        (0..n).map(|i| LiveBlock {
            block_id: i,
            data: vec![i as u8; bytes_each],
            bits: bytes_each * 8,
            n_events: (i * 5) as u32,
        }).collect()
    }

    #[test]
    fn test_ingest_single() {
        let cfg = LiveConfig { max_gops: 10, max_memory_bytes: 1_000_000, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        let gid = buf.ingest(make_blocks(4, 100), 16, 1000);
        assert_eq!(gid, 0);
        assert_eq!(buf.gop_count(), 1);
        assert_eq!(buf.buffered_frames(), 16);
        assert_eq!(buf.stats().memory_bytes, 400);
    }

    #[test]
    fn test_ingest_multiple() {
        let cfg = LiveConfig { max_gops: 10, max_memory_bytes: 1_000_000, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for i in 0..5 {
            buf.ingest(make_blocks(4, 100), 16, i * 500);
        }
        assert_eq!(buf.gop_count(), 5);
        assert_eq!(buf.buffered_frames(), 80);
        assert_eq!(buf.oldest_frame(), Some(0));
        assert_eq!(buf.newest_frame(), Some(79));
    }

    #[test]
    fn test_circular_eviction() {
        let cfg = LiveConfig { max_gops: 3, max_memory_bytes: 1_000_000, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for i in 0..5u64 {
            buf.ingest(make_blocks(2, 50), 16, i * 500);
        }
        assert_eq!(buf.gop_count(), 3); // only 3 kept
        assert_eq!(buf.stats().gops_dropped, 2);
        assert_eq!(buf.oldest_frame(), Some(32)); // GOPs 0,1 evicted
        assert_eq!(buf.newest_frame(), Some(79));
    }

    #[test]
    fn test_memory_eviction() {
        let cfg = LiveConfig { max_gops: 100, max_memory_bytes: 500, gop_frame_count: 8, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for i in 0..10u64 {
            buf.ingest(make_blocks(4, 50), 8, i * 250); // 200 bytes per GOP
        }
        // 500 bytes cap → at most 2-3 GOPs
        assert!(buf.gop_count() <= 3);
        assert!(buf.stats().memory_bytes <= 600);
    }

    #[test]
    fn test_negative_time() {
        let cfg = LiveConfig { max_gops: 10, gop_frame_count: 32, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for i in 0..5 {
            buf.ingest(make_blocks(2, 50), 32, i * 1000);
        }
        // Total ingested: 160 frames
        assert_eq!(buf.resolve_negative_time(-30), Some(130));
        assert_eq!(buf.resolve_negative_time(-160), Some(0));
        assert_eq!(buf.resolve_negative_time(-161), None); // before start
        assert_eq!(buf.resolve_negative_time(42), Some(42));
    }

    #[test]
    fn test_find_gop() {
        let cfg = LiveConfig { max_gops: 10, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        buf.ingest(make_blocks(2, 50), 16, 0);    // frames 0-15
        buf.ingest(make_blocks(2, 50), 16, 500);  // frames 16-31
        buf.ingest(make_blocks(2, 50), 16, 1000); // frames 32-47

        let gop = buf.find_gop_for_frame(20).unwrap();
        assert_eq!(gop.frame_start, 16);
        assert_eq!(gop.gop_id, 1);

        assert!(buf.find_gop_for_frame(100).is_none());
    }

    #[test]
    fn test_gops_in_range() {
        let cfg = LiveConfig { max_gops: 10, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for _ in 0..4 {
            buf.ingest(make_blocks(2, 50), 16, 0);
        }
        // GOPs: [0,15] [16,31] [32,47] [48,63]
        let gops = buf.get_gops_in_range(10, 40);
        assert_eq!(gops.len(), 3); // GOPs 0, 1, 2
    }

    #[test]
    fn test_recent_gops() {
        let cfg = LiveConfig { max_gops: 10, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        for _ in 0..5 {
            buf.ingest(make_blocks(2, 50), 16, 0);
        }
        let recent = buf.recent_gops(2);
        assert_eq!(recent.len(), 2);
        assert_eq!(recent[0].gop_id, 4); // most recent
        assert_eq!(recent[1].gop_id, 3);
    }

    #[test]
    fn test_fullness() {
        let cfg = LiveConfig { max_gops: 4, gop_frame_count: 16, ..Default::default() };
        let mut buf = LiveBuffer::new(cfg);

        assert_eq!(buf.fullness(), 0.0);
        buf.ingest(make_blocks(1, 10), 16, 0);
        assert_eq!(buf.fullness(), 0.25);
        buf.ingest(make_blocks(1, 10), 16, 0);
        buf.ingest(make_blocks(1, 10), 16, 0);
        buf.ingest(make_blocks(1, 10), 16, 0);
        assert_eq!(buf.fullness(), 1.0);
    }
}
