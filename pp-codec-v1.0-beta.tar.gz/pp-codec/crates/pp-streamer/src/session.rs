//! # Session Manager — PPSP session state
//! Ref: modMOT T13-T16, modMCD Session + ViewportState
#![forbid(unsafe_code)]

use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicU64, Ordering};

/// Global session ID counter (monotonic).
static NEXT_SESSION_ID: AtomicU64 = AtomicU64::new(1);

fn next_id() -> u64 {
    NEXT_SESSION_ID.fetch_add(1, Ordering::Relaxed)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum AccessLevel { Read, Query, Write }

#[derive(Debug, Clone, Copy, Hash, PartialEq, Eq)]
pub struct BlockLod {
    pub block_id: usize,
    pub lod: u8,
}

#[derive(Debug, Clone, Default)]
pub struct ViewportState {
    pub visible_blocks: Vec<usize>,
    pub lod_map: HashMap<usize, u8>,
    pub frame_start: u32,
    pub frame_end: u32,
    pub filters: Vec<String>,
}

#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct SessionStats {
    pub blocks_sent: u64,
    pub bytes_sent: u64,
    pub seeks_count: u32,
    pub queries_count: u32,
}

#[derive(Debug)]
pub struct Session {
    pub id: u64,
    pub file_path: String,
    pub access: AccessLevel,
    pub viewport: ViewportState,
    pub tx_history: HashSet<BlockLod>,
    pub stats: SessionStats,
    pub created_at: std::time::Instant,
}

impl Session {
    pub fn new(file_path: String, access: AccessLevel) -> Self {
        Session {
            id: next_id(),
            file_path, access,
            viewport: ViewportState::default(),
            tx_history: HashSet::new(),
            stats: SessionStats::default(),
            created_at: std::time::Instant::now(),
        }
    }

    /// Compute delta: blocks in new viewport not yet sent.
    pub fn compute_delta(&self, new_vp: &ViewportState) -> Vec<BlockLod> {
        let mut delta = Vec::new();
        for &block_id in &new_vp.visible_blocks {
            let lod = new_vp.lod_map.get(&block_id).copied().unwrap_or(0);
            let key = BlockLod { block_id, lod };
            if !self.tx_history.contains(&key) {
                delta.push(key);
            }
        }
        delta
    }

    pub fn apply_seek(&mut self, new_vp: ViewportState, sent: &[BlockLod]) {
        self.viewport = new_vp;
        for bl in sent { self.tx_history.insert(*bl); }
        self.stats.seeks_count += 1;
    }

    pub fn record_tx(&mut self, blocks: u64, bytes: u64) {
        self.stats.blocks_sent += blocks;
        self.stats.bytes_sent += bytes;
    }

    pub fn duration_secs(&self) -> f64 { self.created_at.elapsed().as_secs_f64() }
}

#[derive(Debug, Default)]
pub struct SessionManager {
    sessions: HashMap<u64, Session>,
}

impl SessionManager {
    pub fn new() -> Self { Self { sessions: HashMap::new() } }

    pub fn open(&mut self, file_path: String, access: AccessLevel) -> u64 {
        let s = Session::new(file_path, access);
        let id = s.id;
        self.sessions.insert(id, s);
        id
    }

    pub fn get(&self, id: &u64) -> Option<&Session> { self.sessions.get(id) }
    pub fn get_mut(&mut self, id: &u64) -> Option<&mut Session> { self.sessions.get_mut(id) }

    pub fn close(&mut self, id: &u64) -> Option<SessionStats> {
        self.sessions.remove(id).map(|s| s.stats)
    }

    pub fn active_sessions(&self) -> Vec<&Session> { self.sessions.values().collect() }
    pub fn count(&self) -> usize { self.sessions.len() }

    pub fn aggregate_stats(&self) -> SessionStats {
        let mut a = SessionStats::default();
        for s in self.sessions.values() {
            a.blocks_sent += s.stats.blocks_sent;
            a.bytes_sent += s.stats.bytes_sent;
            a.seeks_count += s.stats.seeks_count;
            a.queries_count += s.stats.queries_count;
        }
        a
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_session_create() {
        let s = Session::new("/cam.ppv".into(), AccessLevel::Read);
        assert_eq!(s.file_path, "/cam.ppv");
        assert!(s.tx_history.is_empty());
    }

    #[test]
    fn test_delta_empty() {
        let s = Session::new("f.ppv".into(), AccessLevel::Read);
        let vp = ViewportState {
            visible_blocks: vec![0, 1, 2],
            lod_map: [(0,0),(1,0),(2,0)].into_iter().collect(),
            ..Default::default()
        };
        assert_eq!(s.compute_delta(&vp).len(), 3);
    }

    #[test]
    fn test_delta_after_seek() {
        let mut s = Session::new("f.ppv".into(), AccessLevel::Read);
        let vp1 = ViewportState {
            visible_blocks: vec![0, 1, 2],
            lod_map: [(0,0),(1,0),(2,0)].into_iter().collect(),
            ..Default::default()
        };
        let sent: Vec<BlockLod> = vp1.visible_blocks.iter()
            .map(|&id| BlockLod { block_id: id, lod: 0 }).collect();
        s.apply_seek(vp1, &sent);

        let vp2 = ViewportState {
            visible_blocks: vec![1, 2, 3],
            lod_map: [(1,0),(2,0),(3,0)].into_iter().collect(),
            ..Default::default()
        };
        let delta = s.compute_delta(&vp2);
        assert_eq!(delta.len(), 1);
        assert_eq!(delta[0].block_id, 3);
    }

    #[test]
    fn test_delta_lod_upgrade() {
        let mut s = Session::new("f.ppv".into(), AccessLevel::Read);
        s.tx_history.insert(BlockLod { block_id: 0, lod: 0 });
        let vp = ViewportState {
            visible_blocks: vec![0],
            lod_map: [(0, 2)].into_iter().collect(),
            ..Default::default()
        };
        let delta = s.compute_delta(&vp);
        assert_eq!(delta.len(), 1);
        assert_eq!(delta[0].lod, 2);
    }

    #[test]
    fn test_manager_lifecycle() {
        let mut m = SessionManager::new();
        let id = m.open("/cam.ppv".into(), AccessLevel::Query);
        assert_eq!(m.count(), 1);
        assert_eq!(m.get(&id).unwrap().access, AccessLevel::Query);
        let stats = m.close(&id).unwrap();
        assert_eq!(stats.blocks_sent, 0);
        assert_eq!(m.count(), 0);
    }

    #[test]
    fn test_aggregate_stats() {
        let mut m = SessionManager::new();
        let id1 = m.open("a.ppv".into(), AccessLevel::Read);
        let id2 = m.open("b.ppv".into(), AccessLevel::Read);
        m.get_mut(&id1).unwrap().record_tx(10, 5000);
        m.get_mut(&id2).unwrap().record_tx(20, 8000);
        let a = m.aggregate_stats();
        assert_eq!(a.blocks_sent, 30);
        assert_eq!(a.bytes_sent, 13000);
    }
}
