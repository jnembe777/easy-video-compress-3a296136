//! # PP-Streamer — PPSP Server over WebSocket
//! Usage: pp-streamer --port 9090 --data /path/to/ppv/files/
//! Ref: planDEV S13-S16, modSFD STR, PPSP 1.0
#![forbid(unsafe_code)]

mod session;
mod handler;
mod live;
mod live_handler;
mod ops;

use std::sync::Arc;
use std::path::PathBuf;
use tokio::sync::Mutex;
use tokio::net::TcpListener;
use futures_util::{StreamExt, SinkExt};
use tokio_tungstenite::accept_async;
use tokio_tungstenite::tungstenite::protocol::Message;
use pp_codec::ppsp::PpspMessage;
use handler::PpspHandler;

struct ServerConfig { port: u16, data_dir: PathBuf }
impl Default for ServerConfig {
    fn default() -> Self { Self { port: 9090, data_dir: PathBuf::from("./data") } }
}

fn parse_args() -> ServerConfig {
    let mut cfg = ServerConfig::default();
    let args: Vec<String> = std::env::args().collect();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--port" if i+1 < args.len() => { cfg.port = args[i+1].parse().unwrap_or(9090); i += 2; }
            "--data" if i+1 < args.len() => { cfg.data_dir = PathBuf::from(&args[i+1]); i += 2; }
            _ => { i += 1; }
        }
    }
    cfg
}

fn load_catalog(handler: &mut PpspHandler, dir: &PathBuf) -> usize {
    let mut count = 0;
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) == Some("ppv") {
                if let Ok(data) = std::fs::read(&path) {
                    let fp = format!("/{}", path.file_name().unwrap_or_default().to_string_lossy());
                    match handler.catalog.load_file(&fp, &data) {
                        Ok(()) => { println!("  📁 {}: {} bytes", fp, data.len()); count += 1; }
                        Err(e) => { eprintln!("  ⚠️  {}: {}", path.display(), e); }
                    }
                }
            }
        }
    }
    count
}

async fn handle_connection(
    stream: tokio::net::TcpStream,
    addr: std::net::SocketAddr,
    handler: Arc<Mutex<PpspHandler>>,
) {
    let ws = match accept_async(stream).await {
        Ok(ws) => ws,
        Err(e) => { eprintln!("  ❌ WS handshake {}: {}", addr, e); return; }
    };
    println!("  🔌 {}", addr);
    let (mut sink, mut rx) = ws.split();

    while let Some(msg) = rx.next().await {
        match msg {
            Ok(Message::Binary(data)) => {
                let ppsp_msg = match PpspMessage::deserialize(&data) {
                    Some(m) => m,
                    None => { eprintln!("  ⚠️  bad msg from {}", addr); continue; }
                };
                let mt = ppsp_msg.msg_type();
                let responses = { handler.lock().await.handle(&ppsp_msg) };
                for resp in responses {
                    let bytes = resp.serialize();
                    if let Err(e) = sink.send(Message::Binary(bytes)).await {
                        eprintln!("  ❌ send {} {}", addr, e); return;
                    }
                }
                if matches!(mt, pp_codec::ppsp::MsgType::Close) { return; }
            }
            Ok(Message::Close(_)) => { return; }
            Ok(Message::Ping(d)) => { let _ = sink.send(Message::Pong(d)).await; }
            Err(_) => { return; }
            _ => {}
        }
    }
}

#[tokio::main]
async fn main() {
    let cfg = parse_args();
    println!("╔═══════════════════════════════════════════════╗");
    println!("║  PP-Streamer v0.1 — PPSP 1.0 / WebSocket    ║");
    println!("╚═══════════════════════════════════════════════╝\n");

    let mut handler = PpspHandler::new();
    println!("📂 Loading from {:?}...", cfg.data_dir);
    let n = load_catalog(&mut handler, &cfg.data_dir);
    println!("   {} files loaded\n", n);

    let handler = Arc::new(Mutex::new(handler));
    let addr = format!("0.0.0.0:{}", cfg.port);
    let listener = TcpListener::bind(&addr).await.expect("bind failed");
    println!("🚀 ws://{}\n", addr);

    loop {
        if let Ok((stream, addr)) = listener.accept().await {
            let h = Arc::clone(&handler);
            tokio::spawn(handle_connection(stream, addr, h));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::handler::PpspHandler;
    use pp_codec::ppsp::*;
    use pp_codec::encoder::encode_video;

    fn setup() -> PpspHandler {
        let mut h = PpspHandler::new();
        let frames: Vec<Vec<u32>> = (0..32).map(|t| {
            (0..256).map(|p| if (p*37+t*71)%100<5 {1} else {0}).collect()
        }).collect();
        let ppv = encode_video(&frames, 16, 16, 8, 4);
        h.catalog.load_file("/test.ppv", &ppv.serialize()).unwrap();
        h
    }

    #[test]
    fn test_e2e_lifecycle() {
        let mut h = setup();
        // OPEN
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppv://x/test.ppv".into(), access: AccessLevel::Query,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };
        // SEEK
        let r = h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:16".into() }));
        let data_count = r.iter().filter(|m| matches!(m, PpspMessage::Data(d) if !d.data.is_empty())).count();
        assert!(data_count >= 1);
        // SEEK again (delta = 0)
        let r2 = h.handle(&PpspMessage::Seek(SeekMsg { session_id: sid, fragment: "t=0:16".into() }));
        let c2 = r2.iter().filter(|m| matches!(m, PpspMessage::Data(d) if !d.data.is_empty())).count();
        assert!(c2 < data_count);
        // QUERY
        let r = h.handle(&PpspMessage::Query(QueryMsg {
            session_id: sid, select: SelectType::Blocks, expression: "activity > 0.0".into(),
        }));
        assert!(matches!(r[0], PpspMessage::Result(_)));
        // CLOSE
        let r = h.handle(&PpspMessage::Close(CloseMsg { session_id: sid }));
        assert!(matches!(r[0], PpspMessage::Error(ErrorMsg { code: 200, .. })));
    }

    #[test]
    fn test_concurrent() {
        let mut h = setup();
        let r1 = h.handle(&PpspMessage::Open(OpenMsg { uri: "ppv://x/test.ppv".into(), access: AccessLevel::Read }));
        let r2 = h.handle(&PpspMessage::Open(OpenMsg { uri: "ppv://x/test.ppv".into(), access: AccessLevel::Query }));
        assert_eq!(h.sessions.count(), 2);
        let s1 = if let PpspMessage::Header(h) = &r1[0] { h.session_id } else { panic!(""); };
        let s2 = if let PpspMessage::Header(h) = &r2[0] { h.session_id } else { panic!(""); };
        assert_ne!(s1, s2);
        h.handle(&PpspMessage::Close(CloseMsg { session_id: s1 }));
        h.handle(&PpspMessage::Close(CloseMsg { session_id: s2 }));
        assert_eq!(h.sessions.count(), 0);
    }

    #[test]
    fn test_wire_roundtrip() {
        let mut h = setup();
        let msg = PpspMessage::Open(OpenMsg { uri: "ppv://x/test.ppv".into(), access: AccessLevel::Read });
        let wire = msg.serialize();
        let parsed = PpspMessage::deserialize(&wire).unwrap();
        let resp = h.handle(&parsed);
        for r in &resp {
            let rw = r.serialize();
            assert!(PpspMessage::deserialize(&rw).is_some());
        }
    }
}
