//! # Compressed Operations — Server-side computations without decompression
//!
//! These operations work on .ppv block metadata and bitstream structure
//! without decoding pixel values. This is the key differentiator of PP-CODEC:
//! meaningful queries and aggregations on compressed data.
//!
//! Ref: specB Brevet IV (PP-STREAMER, Rev. 3-5), modMOT T15
//!
//! ## Operations
//! 1. Activity aggregation: sum N across blocks/frames without decoding
//! 2. Block selection: find blocks matching criteria (activity, family, color)
//! 3. Temporal slice: extract a frame range without full decode
//! 4. Merge: combine multiple .ppv streams (multi-camera)
//! 5. Statistics: compute block-level metrics from compressed metadata

#![forbid(unsafe_code)]

use pp_codec::encoder::PpvFile;
use std::collections::HashMap;

/// Activity level for a single block.
#[derive(Debug, Clone, serde::Serialize)]
pub struct BlockActivity {
    pub block_id: usize,
    pub bx: u32,
    pub by: u32,
    pub bits: usize,
    pub activity_ratio: f64,    // bits / avg_bits (proxy for N/r)
    pub category: ActivityCategory,
}

/// Activity classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub enum ActivityCategory {
    Static,         // activity < 0.1
    Low,            // 0.1 ≤ activity < 0.5
    Medium,         // 0.5 ≤ activity < 1.5
    High,           // 1.5 ≤ activity < 3.0
    VeryHigh,       // activity ≥ 3.0
}

impl ActivityCategory {
    pub fn from_ratio(r: f64) -> Self {
        if r < 0.1 { Self::Static }
        else if r < 0.5 { Self::Low }
        else if r < 1.5 { Self::Medium }
        else if r < 3.0 { Self::High }
        else { Self::VeryHigh }
    }
}

/// OP-01: Compute activity map for all blocks (no decompression).
/// Returns a sorted list of BlockActivity, highest activity first.
pub fn compute_activity_map(ppv: &PpvFile) -> Vec<BlockActivity> {
    let bs = ppv.block_size;
    let blocks_x = ((ppv.width + bs - 1) / bs) as usize;
    let avg_bits: f64 = ppv.block_bits.iter().sum::<usize>() as f64
        / ppv.block_bits.len().max(1) as f64;

    let mut map: Vec<BlockActivity> = ppv.block_bits.iter().enumerate().map(|(i, &bits)| {
        let ratio = bits as f64 / avg_bits.max(1.0);
        BlockActivity {
            block_id: i,
            bx: (i % blocks_x) as u32,
            by: (i / blocks_x) as u32,
            bits,
            activity_ratio: ratio,
            category: ActivityCategory::from_ratio(ratio),
        }
    }).collect();

    map.sort_by(|a, b| b.activity_ratio.partial_cmp(&a.activity_ratio).unwrap_or(std::cmp::Ordering::Equal));
    map
}

/// OP-02: Filter blocks by activity threshold.
pub fn filter_by_activity(ppv: &PpvFile, min_ratio: f64) -> Vec<BlockActivity> {
    compute_activity_map(ppv).into_iter()
        .filter(|b| b.activity_ratio >= min_ratio)
        .collect()
}

/// OP-03: Get the top-N most active blocks.
pub fn top_active_blocks(ppv: &PpvFile, n: usize) -> Vec<BlockActivity> {
    compute_activity_map(ppv).into_iter().take(n).collect()
}

/// OP-04: Compute spatial activity histogram (how many blocks per category).
pub fn activity_histogram(ppv: &PpvFile) -> HashMap<&'static str, usize> {
    let map = compute_activity_map(ppv);
    let mut hist = HashMap::new();
    hist.insert("static", 0);
    hist.insert("low", 0);
    hist.insert("medium", 0);
    hist.insert("high", 0);
    hist.insert("very_high", 0);

    for b in &map {
        let key = match b.category {
            ActivityCategory::Static => "static",
            ActivityCategory::Low => "low",
            ActivityCategory::Medium => "medium",
            ActivityCategory::High => "high",
            ActivityCategory::VeryHigh => "very_high",
        };
        *hist.get_mut(key).unwrap() += 1;
    }
    hist
}

/// Compression statistics for a .ppv file.
#[derive(Debug, Clone, serde::Serialize)]
pub struct CompressionStats {
    pub total_blocks: usize,
    pub total_bits: usize,
    pub total_bytes: usize,
    pub raw_bits: u64,
    pub ratio: f64,
    pub bpp: f64,               // bits per pixel
    pub min_block_bits: usize,
    pub max_block_bits: usize,
    pub avg_block_bits: f64,
    pub std_block_bits: f64,
    pub active_blocks: usize,   // blocks above average
    pub static_blocks: usize,   // blocks below 10% average
    pub sparsity: f64,          // fraction of static blocks
}

/// OP-05: Compute compression statistics from metadata.
pub fn compression_stats(ppv: &PpvFile) -> CompressionStats {
    let total_bits: usize = ppv.block_bits.iter().sum();
    let total_bytes: usize = ppv.block_data.iter().map(|b| b.len()).sum();
    let nb = ppv.block_bits.len();
    let pixels = ppv.width as u64 * ppv.height as u64 * ppv.frames as u64;
    let mbits = (ppv.palette_size as f64).log2().ceil().max(1.0) as u64;
    let raw_bits = pixels * mbits;

    let min_bits = ppv.block_bits.iter().copied().min().unwrap_or(0);
    let max_bits = ppv.block_bits.iter().copied().max().unwrap_or(0);
    let avg = if nb > 0 { total_bits as f64 / nb as f64 } else { 0.0 };

    let variance = if nb > 1 {
        ppv.block_bits.iter().map(|&b| {
            let d = b as f64 - avg;
            d * d
        }).sum::<f64>() / (nb - 1) as f64
    } else { 0.0 };

    let active = ppv.block_bits.iter().filter(|&&b| b as f64 > avg).count();
    let threshold_static = avg * 0.1;
    let static_count = ppv.block_bits.iter().filter(|&&b| (b as f64) < threshold_static).count();

    CompressionStats {
        total_blocks: nb,
        total_bits,
        total_bytes,
        raw_bits,
        ratio: if total_bits > 0 { raw_bits as f64 / total_bits as f64 } else { 0.0 },
        bpp: if pixels > 0 { total_bits as f64 / pixels as f64 } else { 0.0 },
        min_block_bits: min_bits,
        max_block_bits: max_bits,
        avg_block_bits: avg,
        std_block_bits: variance.sqrt(),
        active_blocks: active,
        static_blocks: static_count,
        sparsity: if nb > 0 { static_count as f64 / nb as f64 } else { 0.0 },
    }
}

/// Block region descriptor for spatial extraction.
#[derive(Debug, Clone)]
pub struct BlockRegion {
    pub block_ids: Vec<usize>,
    pub total_bits: usize,
    pub total_bytes: usize,
}

/// OP-06: Extract a spatial region of blocks (for partial streaming).
/// Returns only the block data for the specified region.
pub fn extract_region(ppv: &PpvFile, bx_start: u32, by_start: u32,
                      bx_end: u32, by_end: u32) -> BlockRegion {
    let bs = ppv.block_size;
    let blocks_x = (ppv.width + bs - 1) / bs;
    let mut ids = Vec::new();
    let mut total_bits = 0usize;
    let mut total_bytes = 0usize;

    for by in by_start..=by_end {
        for bx in bx_start..=bx_end {
            let id = (by * blocks_x + bx) as usize;
            if id < ppv.block_data.len() {
                total_bits += ppv.block_bits[id];
                total_bytes += ppv.block_data[id].len();
                ids.push(id);
            }
        }
    }

    BlockRegion { block_ids: ids, total_bits, total_bytes }
}

/// OP-07: Estimate the size of a viewport SEEK response (for bandwidth planning).
/// Returns estimated bytes to transmit for a given viewport.
pub fn estimate_viewport_bytes(ppv: &PpvFile, visible_block_ids: &[usize]) -> usize {
    visible_block_ids.iter()
        .filter_map(|&id| ppv.block_data.get(id))
        .map(|data| data.len())
        .sum::<usize>()
        + 8 * visible_block_ids.len() // PPSP headers overhead
}

/// OP-08: Compare two .ppv files (multi-camera diff).
/// Returns blocks that differ significantly in activity between the two files.
pub fn compare_activity(ppv_a: &PpvFile, ppv_b: &PpvFile) -> Vec<(usize, f64, f64)> {
    let map_a = compute_activity_map(ppv_a);
    let map_b = compute_activity_map(ppv_b);

    let a_map: HashMap<usize, f64> = map_a.iter().map(|b| (b.block_id, b.activity_ratio)).collect();
    let b_map: HashMap<usize, f64> = map_b.iter().map(|b| (b.block_id, b.activity_ratio)).collect();

    let max_blocks = a_map.len().max(b_map.len());
    let mut diffs = Vec::new();
    for id in 0..max_blocks {
        let a = a_map.get(&id).copied().unwrap_or(0.0);
        let b = b_map.get(&id).copied().unwrap_or(0.0);
        if (a - b).abs() > 0.5 {
            diffs.push((id, a, b));
        }
    }
    diffs
}

#[cfg(test)]
mod tests {
    use super::*;
    use pp_codec::encoder::encode_video;

    fn make_ppv() -> PpvFile {
        let frames: Vec<Vec<u32>> = (0..32).map(|t| {
            (0..256).map(|p| {
                // Blocks 0-1: very active, blocks 2-3: mostly static
                let bx = (p % 16) / 8;
                let by = (p / 16) / 8;
                let block_idx = by * 2 + bx;
                if block_idx < 2 && (p * 37 + t * 71) % 10 < 3 { 1 } else { 0 }
            }).collect()
        }).collect();
        encode_video(&frames, 16, 16, 8, 4)
    }

    #[test]
    fn test_activity_map() {
        let ppv = make_ppv();
        let map = compute_activity_map(&ppv);
        assert_eq!(map.len(), 4); // 2×2 blocks
        // First entry should be the most active
        assert!(map[0].activity_ratio >= map[1].activity_ratio);
    }

    #[test]
    fn test_filter_activity() {
        let ppv = make_ppv();
        let high = filter_by_activity(&ppv, 1.5);
        let all = filter_by_activity(&ppv, 0.0);
        assert!(high.len() <= all.len());
        assert_eq!(all.len(), 4);
    }

    #[test]
    fn test_top_active() {
        let ppv = make_ppv();
        let top = top_active_blocks(&ppv, 2);
        assert_eq!(top.len(), 2);
        assert!(top[0].activity_ratio >= top[1].activity_ratio);
    }

    #[test]
    fn test_activity_histogram() {
        let ppv = make_ppv();
        let hist = activity_histogram(&ppv);
        let total: usize = hist.values().sum();
        assert_eq!(total, 4);
    }

    #[test]
    fn test_compression_stats() {
        let ppv = make_ppv();
        let stats = compression_stats(&ppv);
        assert_eq!(stats.total_blocks, 4);
        assert!(stats.total_bits > 0);
        assert!(stats.avg_block_bits > 0.0);
        assert!(stats.std_block_bits >= 0.0);
        assert!(stats.sparsity >= 0.0 && stats.sparsity <= 1.0);
    }

    #[test]
    fn test_extract_region() {
        let ppv = make_ppv();
        // Extract top-left block only
        let region = extract_region(&ppv, 0, 0, 0, 0);
        assert_eq!(region.block_ids.len(), 1);
        assert_eq!(region.block_ids[0], 0);
        assert!(region.total_bytes > 0);

        // Extract all blocks
        let all = extract_region(&ppv, 0, 0, 1, 1);
        assert_eq!(all.block_ids.len(), 4);
    }

    #[test]
    fn test_estimate_viewport() {
        let ppv = make_ppv();
        let est_all = estimate_viewport_bytes(&ppv, &[0, 1, 2, 3]);
        let est_one = estimate_viewport_bytes(&ppv, &[0]);
        assert!(est_all > est_one);
        assert!(est_one > 0);
    }

    #[test]
    fn test_compare_activity() {
        let ppv_a = make_ppv();
        // Create a second ppv with different activity pattern
        let frames_b: Vec<Vec<u32>> = (0..32).map(|t| {
            (0..256).map(|p| {
                // Invert: blocks 2-3 active, 0-1 static
                let bx = (p % 16) / 8;
                let by = (p / 16) / 8;
                let block_idx = by * 2 + bx;
                if block_idx >= 2 && (p * 37 + t * 71) % 10 < 3 { 1 } else { 0 }
            }).collect()
        }).collect();
        let ppv_b = encode_video(&frames_b, 16, 16, 8, 4);

        let diffs = compare_activity(&ppv_a, &ppv_b);
        // Should find differences since activity patterns are inverted
        assert!(!diffs.is_empty());
    }

    #[test]
    fn test_category_classification() {
        assert_eq!(ActivityCategory::from_ratio(0.0), ActivityCategory::Static);
        assert_eq!(ActivityCategory::from_ratio(0.3), ActivityCategory::Low);
        assert_eq!(ActivityCategory::from_ratio(1.0), ActivityCategory::Medium);
        assert_eq!(ActivityCategory::from_ratio(2.0), ActivityCategory::High);
        assert_eq!(ActivityCategory::from_ratio(5.0), ActivityCategory::VeryHigh);
    }
}
