//! # Live Handler — PPSP handler for ppl:// live streams
//!
//! Extends the VOD handler with live-specific capabilities:
//! - Subscriber model: clients subscribe to a live stream
//! - Push notification: new GOPs pushed to all subscribers
//! - Time-shifting: clients can seek backward within buffer window
//! - Catch-up: new clients receive recent GOPs to start quickly
//!
//! Ref: planDEV S25-S28, specS ppl:// scheme, PPSP 1.0 §3.4

#![forbid(unsafe_code)]

use std::collections::HashMap;
use pp_codec::ppsp::*;
use crate::live::{LiveBuffer, LiveConfig, LiveBlock, MicroGop};
use crate::session::{SessionManager, AccessLevel, SessionStats};

/// A live stream identified by its ppl:// path.
#[derive(Debug)]
pub struct LiveStream {
    pub path: String,
    pub buffer: LiveBuffer,
    pub subscribers: Vec<u64>,          // session IDs subscribed to this stream
    pub ingest_count: u64,
}

impl LiveStream {
    pub fn new(path: String, config: LiveConfig) -> Self {
        LiveStream {
            path, buffer: LiveBuffer::new(config),
            subscribers: Vec::new(), ingest_count: 0,
        }
    }
}

/// Handler for live streams.
pub struct LiveHandler {
    pub sessions: SessionManager,
    pub streams: HashMap<String, LiveStream>,
}

impl LiveHandler {
    pub fn new() -> Self {
        LiveHandler { sessions: SessionManager::new(), streams: HashMap::new() }
    }

    /// Register a new live stream (called when encoder connects).
    pub fn register_stream(&mut self, path: &str, config: LiveConfig) {
        self.streams.insert(path.to_string(), LiveStream::new(path.to_string(), config));
    }

    /// Process an incoming PPSP message for a live stream.
    pub fn handle(&mut self, msg: &PpspMessage) -> Vec<PpspMessage> {
        match msg {
            PpspMessage::Open(m) => self.handle_open(m),
            PpspMessage::Seek(m) => self.handle_seek(m),
            PpspMessage::Close(m) => self.handle_close(m),
            _ => vec![PpspMessage::Error(ErrorMsg {
                code: 400, message: "unsupported for live".into(),
            })],
        }
    }

    /// Open: subscribe client to a live stream.
    fn handle_open(&mut self, msg: &OpenMsg) -> Vec<PpspMessage> {
        let path = if let Some(pos) = msg.uri.find("//") {
            let after = &msg.uri[pos + 2..];
            if let Some(slash) = after.find('/') {
                after[slash..].to_string()
            } else {
                return vec![PpspMessage::Error(ErrorMsg { code: 400, message: "no path".into() })];
            }
        } else {
            return vec![PpspMessage::Error(ErrorMsg { code: 400, message: "bad URI".into() })];
        };

        // Extract all needed data from immutable borrow first
        let (width, height, bs, palette_size, buffered, bx, by, catch_up_data) = {
            let stream = match self.streams.get(&path) {
                Some(s) => s,
                None => return vec![PpspMessage::Error(ErrorMsg {
                    code: 404, message: format!("stream not found: {}", path),
                })],
            };
            let cfg = stream.buffer.config();
            let bs = cfg.block_size;
            let bx = (cfg.width + bs - 1) / bs;
            let by = (cfg.height + bs - 1) / bs;
            let buffered = stream.buffer.buffered_frames() as u32;

            // Collect catch-up data (2 most recent GOPs)
            let mut catch_up = Vec::new();
            for gop in stream.buffer.recent_gops(2).into_iter().rev() {
                for block in &gop.blocks {
                    catch_up.push((block.block_id, gop.frame_start as u32,
                        (gop.frame_start + gop.frame_count as u64 - 1) as u32,
                        block.data.clone()));
                }
            }
            (cfg.width, cfg.height, bs, cfg.palette_size, buffered, bx, by, catch_up)
        }; // immutable borrow of self.streams ends here

        let access = match msg.access {
            pp_codec::ppsp::AccessLevel::Read => AccessLevel::Read,
            pp_codec::ppsp::AccessLevel::Query => AccessLevel::Query,
            pp_codec::ppsp::AccessLevel::Write => AccessLevel::Write,
        };

        let sid = self.sessions.open(path.clone(), access);

        // Now we can mutably borrow
        if let Some(s) = self.streams.get_mut(&path) {
            s.subscribers.push(sid);
        }

        let mut responses = vec![PpspMessage::Header(HeaderMsg {
            session_id: sid,
            width, height, frames: buffered,
            block_size: bs, palette_size, num_blocks: bx * by,
        })];

        for (block_id, fs, fe, data) in catch_up_data {
            responses.push(PpspMessage::Data(DataMsg {
                block_id, lod: 0, frame_start: fs, frame_end: fe, data,
            }));
        }

        responses
    }

    /// Seek within the live buffer (time-shifting).
    fn handle_seek(&mut self, msg: &SeekMsg) -> Vec<PpspMessage> {
        let sid = msg.session_id;
        let session = match self.sessions.get(&sid) {
            Some(s) => s,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 410, message: "expired".into() })],
        };

        let stream = match self.streams.get(&session.file_path) {
            Some(s) => s,
            None => return vec![PpspMessage::Error(ErrorMsg { code: 500, message: "stream gone".into() })],
        };

        // Parse fragment to extract time range
        let fragment = &msg.fragment;
        let (start, end) = parse_time_range(fragment, &stream.buffer);

        let gops = stream.buffer.get_gops_in_range(start, end);
        let mut responses = Vec::new();

        for gop in gops {
            for block in &gop.blocks {
                responses.push(PpspMessage::Data(DataMsg {
                    block_id: block.block_id,
                    lod: 0,
                    frame_start: gop.frame_start as u32,
                    frame_end: (gop.frame_start + gop.frame_count as u64 - 1) as u32,
                    data: block.data.clone(),
                }));
            }
        }

        if let Some(s) = self.sessions.get_mut(&sid) {
            s.stats.seeks_count += 1;
            let bytes: u64 = responses.iter().map(|r| {
                if let PpspMessage::Data(d) = r { d.data.len() as u64 } else { 0 }
            }).sum();
            s.record_tx(responses.len() as u64, bytes);
        }

        if responses.is_empty() {
            responses.push(PpspMessage::Error(ErrorMsg {
                code: 404, message: format!("frames {}:{} not in buffer", start, end),
            }));
        }

        responses
    }

    /// Close: unsubscribe from live stream.
    fn handle_close(&mut self, msg: &CloseMsg) -> Vec<PpspMessage> {
        let sid = msg.session_id;
        if let Some(session) = self.sessions.get(&sid) {
            let path = session.file_path.clone();
            if let Some(stream) = self.streams.get_mut(&path) {
                stream.subscribers.retain(|&s| s != sid);
            }
        }
        match self.sessions.close(&sid) {
            Some(stats) => vec![PpspMessage::Error(ErrorMsg {
                code: 200,
                message: format!("live closed: {} blk, {} B", stats.blocks_sent, stats.bytes_sent),
            })],
            None => vec![PpspMessage::Error(ErrorMsg { code: 410, message: "not found".into() })],
        }
    }

    /// Ingest a new GOP from the encoder (push to all subscribers).
    /// Returns DATA messages to send to each subscriber.
    pub fn ingest_gop(
        &mut self, stream_path: &str,
        blocks: Vec<LiveBlock>, frame_count: u32, timestamp_ms: u64,
    ) -> HashMap<u64, Vec<PpspMessage>> {
        let mut notifications: HashMap<u64, Vec<PpspMessage>> = HashMap::new();

        if let Some(stream) = self.streams.get_mut(stream_path) {
            let gop_id = stream.buffer.ingest(blocks.clone(), frame_count, timestamp_ms);
            stream.ingest_count += 1;

            let gop = stream.buffer.find_gop_for_frame(
                stream.buffer.newest_frame().unwrap_or(0)
            );

            if let Some(gop) = gop {
                for &sid in &stream.subscribers {
                    let mut msgs = Vec::new();
                    for block in &gop.blocks {
                        msgs.push(PpspMessage::Data(DataMsg {
                            block_id: block.block_id,
                            lod: 0,
                            frame_start: gop.frame_start as u32,
                            frame_end: (gop.frame_start + gop.frame_count as u64 - 1) as u32,
                            data: block.data.clone(),
                        }));
                    }
                    notifications.insert(sid, msgs);
                }
            }
        }

        notifications
    }

    /// Number of active subscribers across all streams.
    pub fn total_subscribers(&self) -> usize {
        self.streams.values().map(|s| s.subscribers.len()).sum()
    }
}

/// Parse time range from fragment string. Supports negative time (ppl:// time-shifting).
fn parse_time_range(fragment: &str, buffer: &LiveBuffer) -> (u64, u64) {
    // Try to extract t=START:END from fragment
    for part in fragment.split('&') {
        if let Some(rest) = part.strip_prefix("t=") {
            if let Some(colon) = rest.find(':') {
                let start_str = &rest[..colon];
                let end_str = &rest[colon + 1..];
                let start: i64 = start_str.parse().unwrap_or(0);
                let end: i64 = end_str.parse().unwrap_or(i64::MAX);

                let abs_start = buffer.resolve_negative_time(start)
                    .unwrap_or(buffer.oldest_frame().unwrap_or(0));
                let abs_end = buffer.resolve_negative_time(end)
                    .unwrap_or(buffer.newest_frame().unwrap_or(0));

                return (abs_start, abs_end);
            } else {
                let t: i64 = rest.parse().unwrap_or(0);
                let abs = buffer.resolve_negative_time(t)
                    .unwrap_or(buffer.oldest_frame().unwrap_or(0));
                return (abs, abs);
            }
        }
    }

    // Default: entire buffer
    (buffer.oldest_frame().unwrap_or(0), buffer.newest_frame().unwrap_or(0))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::live::LiveConfig;

    fn make_blocks(n: u32) -> Vec<LiveBlock> {
        (0..n).map(|i| LiveBlock {
            block_id: i, data: vec![i as u8; 50],
            bits: 400, n_events: i * 3,
        }).collect()
    }

    fn setup() -> LiveHandler {
        let mut h = LiveHandler::new();
        h.register_stream("/live/cam1", LiveConfig {
            max_gops: 10, max_memory_bytes: 100_000,
            gop_frame_count: 16, width: 32, height: 32,
            block_size: 16, palette_size: 4,
        });
        // Ingest some GOPs
        for i in 0..3 {
            h.ingest_gop("/live/cam1", make_blocks(4), 16, i * 500);
        }
        h
    }

    #[test]
    fn test_register_stream() {
        let mut h = LiveHandler::new();
        h.register_stream("/live/cam1", LiveConfig::default());
        assert!(h.streams.contains_key("/live/cam1"));
    }

    #[test]
    fn test_open_live() {
        let mut h = setup();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        // Should get HEADER + catch-up DATA messages
        assert!(r.len() >= 1);
        assert!(matches!(r[0], PpspMessage::Header(_)));
        // Should have DATA messages from catch-up (2 recent GOPs × 4 blocks = 8)
        let data_count = r.iter().filter(|m| matches!(m, PpspMessage::Data(_))).count();
        assert!(data_count > 0, "catch-up should send data");
    }

    #[test]
    fn test_open_404() {
        let mut h = LiveHandler::new();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/missing".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        assert!(matches!(r[0], PpspMessage::Error(ErrorMsg { code: 404, .. })));
    }

    #[test]
    fn test_subscriber_tracking() {
        let mut h = setup();
        assert_eq!(h.total_subscribers(), 0);

        h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        assert_eq!(h.total_subscribers(), 1);

        h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        assert_eq!(h.total_subscribers(), 2);
    }

    #[test]
    fn test_seek_timeshift() {
        let mut h = setup();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        // Seek with negative time (time-shifting): -30 to -1 = "last 30 frames"
        let r = h.handle(&PpspMessage::Seek(SeekMsg {
            session_id: sid, fragment: "t=-30:-1".into(),
        }));
        let data_count = r.iter().filter(|m| matches!(m, PpspMessage::Data(_))).count();
        assert!(data_count > 0, "time-shift should return data");
    }

    #[test]
    fn test_ingest_notifies_subscribers() {
        let mut h = setup();

        // Subscribe 2 clients
        let r1 = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid1 = if let PpspMessage::Header(hdr) = &r1[0] { hdr.session_id } else { panic!(""); };

        let r2 = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid2 = if let PpspMessage::Header(hdr) = &r2[0] { hdr.session_id } else { panic!(""); };

        // Ingest new GOP
        let notifs = h.ingest_gop("/live/cam1", make_blocks(4), 16, 5000);

        // Both subscribers should get notified
        assert!(notifs.contains_key(&sid1), "subscriber 1 should be notified");
        assert!(notifs.contains_key(&sid2), "subscriber 2 should be notified");
        assert_eq!(notifs[&sid1].len(), 4); // 4 blocks
        assert_eq!(notifs[&sid2].len(), 4);
    }

    #[test]
    fn test_close_unsubscribes() {
        let mut h = setup();
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://cam/live/cam1".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };

        assert_eq!(h.total_subscribers(), 1);

        let r = h.handle(&PpspMessage::Close(CloseMsg { session_id: sid }));
        assert!(matches!(r[0], PpspMessage::Error(ErrorMsg { code: 200, .. })));
        assert_eq!(h.total_subscribers(), 0);
        assert_eq!(h.sessions.count(), 0);
    }

    #[test]
    fn test_full_live_lifecycle() {
        let mut h = LiveHandler::new();
        h.register_stream("/live/cam", LiveConfig {
            max_gops: 5, max_memory_bytes: 50_000,
            gop_frame_count: 8, width: 16, height: 16,
            block_size: 8, palette_size: 4,
        });

        // 1. Encoder starts ingesting
        for i in 0..3 {
            h.ingest_gop("/live/cam", make_blocks(4), 8, i * 250);
        }

        // 2. Client connects (catch-up)
        let r = h.handle(&PpspMessage::Open(OpenMsg {
            uri: "ppl://encoder/live/cam".into(),
            access: pp_codec::ppsp::AccessLevel::Read,
        }));
        let sid = if let PpspMessage::Header(hdr) = &r[0] { hdr.session_id } else { panic!(""); };
        let catch_up_data = r.iter().filter(|m| matches!(m, PpspMessage::Data(_))).count();
        assert!(catch_up_data > 0);

        // 3. More GOPs arrive → push to subscriber
        let notifs = h.ingest_gop("/live/cam", make_blocks(4), 8, 3000);
        assert!(notifs.contains_key(&sid));

        // 4. Client time-shifts
        let r = h.handle(&PpspMessage::Seek(SeekMsg {
            session_id: sid, fragment: "t=-16:-1".into(),
        }));
        assert!(r.iter().any(|m| matches!(m, PpspMessage::Data(_))));

        // 5. Client disconnects
        h.handle(&PpspMessage::Close(CloseMsg { session_id: sid }));
        assert_eq!(h.total_subscribers(), 0);
    }
}
