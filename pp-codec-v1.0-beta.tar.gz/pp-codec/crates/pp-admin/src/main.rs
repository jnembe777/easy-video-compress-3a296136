//! # PP-Admin — Dashboard backend for PP-Streamer
//! Ref: planDEV S29-S32, SFD-STR-001..004
#![forbid(unsafe_code)]

pub mod catalog;
pub mod dashboard;

use catalog::Catalog;
use dashboard::*;

/// Admin backend — combines catalog, dashboard, and access control.
pub struct AdminBackend {
    pub catalog: Catalog,
    pub dashboard: DashboardState,
    pub access: AccessControl,
}

impl AdminBackend {
    pub fn new() -> Self {
        AdminBackend {
            catalog: Catalog::new(),
            dashboard: DashboardState::default(),
            access: AccessControl::new(),
        }
    }

    /// API: GET /api/catalog — list all indexed files.
    pub fn api_list_catalog(&self) -> String {
        ApiResponse::success(self.catalog.list()).to_json()
    }

    /// API: POST /api/catalog — index a new .ppv file.
    pub fn api_index_file(&mut self, path: &str, data: &[u8]) -> String {
        match self.catalog.index_file(path, data) {
            Ok(entry) => ApiResponse::success(entry).to_json(),
            Err(e) => error_response(&e),
        }
    }

    /// API: DELETE /api/catalog/:id — remove a file from catalog.
    pub fn api_remove_file(&mut self, id: &str) -> String {
        match self.catalog.remove(id) {
            Some(entry) => ApiResponse::success(entry).to_json(),
            None => error_response("not found"),
        }
    }

    /// API: GET /api/dashboard — full dashboard state.
    pub fn api_dashboard(&self) -> String {
        self.dashboard.to_json()
    }

    /// API: GET /api/sessions — active sessions.
    pub fn api_sessions(&self) -> String {
        ApiResponse::success(&self.dashboard.sessions).to_json()
    }

    /// API: GET /api/access — list access rules.
    pub fn api_list_rules(&self) -> String {
        self.access.to_json()
    }

    /// API: POST /api/access — add an access rule.
    pub fn api_add_rule(&mut self, client: &str, file: &str, level: &str) -> String {
        match AccessLevel::from_str(level) {
            Some(access) => {
                let id = self.access.add_rule(client, file, access);
                ApiResponse::success(id).to_json()
            }
            None => error_response(&format!("invalid access level: {}", level)),
        }
    }

    /// API: DELETE /api/access/:id — remove a rule.
    pub fn api_remove_rule(&mut self, id: u64) -> String {
        if self.access.remove_rule(id) {
            ApiResponse::success("deleted").to_json()
        } else {
            error_response("rule not found")
        }
    }

    /// API: GET /api/access/check?client=X&file=Y — check access.
    pub fn api_check_access(&self, client: &str, file: &str) -> String {
        match self.access.evaluate(client, file) {
            Some(level) => ApiResponse::success(level.as_str()).to_json(),
            None => error_response("access denied"),
        }
    }

    /// Summary stats for the dashboard header.
    pub fn summary(&self) -> String {
        format!("files={} sessions={} rules={} bytes={}",
            self.catalog.count(),
            self.dashboard.kpi.active_sessions,
            self.access.list().len(),
            self.catalog.total_bytes())
    }
}

fn main() {
    println!("╔═══════════════════════════════════════════════╗");
    println!("║  PP-Admin v0.1 — Dashboard Backend           ║");
    println!("║  PP-CODEC FORGE v2.0                         ║");
    println!("╚═══════════════════════════════════════════════╝");
    println!();
    println!("  REST API endpoints:");
    println!("    GET    /api/catalog          List indexed files");
    println!("    POST   /api/catalog          Index a new .ppv");
    println!("    DELETE /api/catalog/:id      Remove from catalog");
    println!("    GET    /api/dashboard        Full dashboard state");
    println!("    GET    /api/sessions         Active sessions");
    println!("    GET    /api/access           List access rules");
    println!("    POST   /api/access           Add access rule");
    println!("    DELETE /api/access/:id       Remove rule");
    println!("    GET    /api/access/check     Check client access");
    println!();
    println!("  (In production: serve via Axum/Actix-web + React frontend)");
}

#[cfg(test)]
mod tests {
    use super::*;
    use pp_codec::encoder::encode_video;

    fn make_ppv() -> Vec<u8> {
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        encode_video(&frames, 8, 8, 8, 4).serialize()
    }

    #[test]
    fn test_full_admin_lifecycle() {
        let mut admin = AdminBackend::new();

        // 1. Index files
        let r = admin.api_index_file("/cam/nord.ppv", &make_ppv());
        assert!(r.contains("ok\":true"));
        let r = admin.api_index_file("/cam/sud.ppv", &make_ppv());
        assert!(r.contains("ok\":true"));
        assert_eq!(admin.catalog.count(), 2);

        // 2. List catalog
        let r = admin.api_list_catalog();
        assert!(r.contains("nord.ppv"));
        assert!(r.contains("sud.ppv"));

        // 3. Add access rules
        admin.api_add_rule("10.0.1.*", "*", "read");
        admin.api_add_rule("analyst01", "/cam/nord.ppv", "query");
        admin.api_add_rule("encoder01", "*", "write");
        assert_eq!(admin.access.list().len(), 3);

        // 4. Check access
        let r = admin.api_check_access("10.0.1.5", "/cam/sud.ppv");
        assert!(r.contains("read"));
        let r = admin.api_check_access("analyst01", "/cam/nord.ppv");
        assert!(r.contains("query"));
        let r = admin.api_check_access("unknown", "/cam/nord.ppv");
        assert!(r.contains("denied"));

        // 5. Add sessions to dashboard
        admin.dashboard.add_session(SessionRow {
            session_id: 1, client_ip: "10.0.1.5".into(),
            file_path: "/cam/nord.ppv".into(), duration_secs: 120.0,
            blocks_sent: 4200, bytes_sent: 500_000, bandwidth_mbps: 4.0,
            access_level: "read".into(), is_live: false,
        });

        // 6. Dashboard
        let r = admin.api_dashboard();
        assert!(r.contains("active_sessions"));
        assert!(r.contains("4200")); // blocks_sent

        // 7. Summary
        let s = admin.summary();
        assert!(s.contains("files=2"));
        assert!(s.contains("sessions=1"));
        assert!(s.contains("rules=3"));
    }

    #[test]
    fn test_remove_file() {
        let mut admin = AdminBackend::new();
        let r = admin.api_index_file("/test.ppv", &make_ppv());
        assert!(r.contains("ppv-0001"));
        let r = admin.api_remove_file("ppv-0001");
        assert!(r.contains("ok\":true"));
        assert_eq!(admin.catalog.count(), 0);
    }

    #[test]
    fn test_remove_rule() {
        let mut admin = AdminBackend::new();
        admin.api_add_rule("*", "*", "read");
        assert_eq!(admin.access.list().len(), 1);
        let r = admin.api_remove_rule(1);
        assert!(r.contains("deleted"));
        assert_eq!(admin.access.list().len(), 0);
    }

    #[test]
    fn test_invalid_ppv() {
        let mut admin = AdminBackend::new();
        let r = admin.api_index_file("/bad.ppv", b"not a ppv file");
        assert!(r.contains("invalid"));
    }

    #[test]
    fn test_invalid_access_level() {
        let mut admin = AdminBackend::new();
        let r = admin.api_add_rule("*", "*", "superadmin");
        assert!(r.contains("invalid"));
    }
}
