//! # Dashboard — KPIs, metrics, access control (SFD-STR-002/003/004)
#![forbid(unsafe_code)]

use serde::{Serialize, Deserialize};
use std::collections::HashMap;

// ═══════════════════════════════════════════════
// KPI / METRICS (SFD-STR-003)
// ═══════════════════════════════════════════════

/// Real-time KPIs for the dashboard.
#[derive(Debug, Clone, Serialize, Default)]
pub struct DashboardKpi {
    pub active_sessions: u32,
    pub total_bandwidth_mbps: f64,
    pub files_indexed: u32,
    pub queries_total: u64,
    pub latency_p99_ms: f64,
    pub uptime_hours: f64,
}

/// Session row for the sessions table (SFD-STR-002).
#[derive(Debug, Clone, Serialize)]
pub struct SessionRow {
    pub session_id: u64,
    pub client_ip: String,
    pub file_path: String,
    pub duration_secs: f64,
    pub blocks_sent: u64,
    pub bytes_sent: u64,
    pub bandwidth_mbps: f64,
    pub access_level: String,
    pub is_live: bool,
}

/// Family distribution for the MDL pie chart.
#[derive(Debug, Clone, Serialize)]
pub struct FamilyDistribution {
    pub family: String,
    pub count: u32,
    pub percentage: f64,
}

/// Time-series data point for graphs.
#[derive(Debug, Clone, Serialize)]
pub struct TimeSeriesPoint {
    pub timestamp: String,
    pub value: f64,
}

/// Full dashboard state.
#[derive(Debug, Clone, Serialize, Default)]
pub struct DashboardState {
    pub kpi: DashboardKpi,
    pub sessions: Vec<SessionRow>,
    pub family_distribution: Vec<FamilyDistribution>,
    pub bandwidth_history: Vec<TimeSeriesPoint>,
    pub sessions_history: Vec<TimeSeriesPoint>,
}

impl DashboardState {
    /// Compute KPIs from sessions list.
    pub fn compute_kpis(&mut self) {
        self.kpi.active_sessions = self.sessions.len() as u32;
        self.kpi.total_bandwidth_mbps = self.sessions.iter()
            .map(|s| s.bandwidth_mbps).sum();
    }

    /// Add a session row.
    pub fn add_session(&mut self, row: SessionRow) {
        self.sessions.push(row);
        self.compute_kpis();
    }

    /// Remove a session by ID.
    pub fn remove_session(&mut self, session_id: u64) {
        self.sessions.retain(|s| s.session_id != session_id);
        self.compute_kpis();
    }

    /// Export as JSON.
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_default()
    }
}

// ═══════════════════════════════════════════════
// ACCESS CONTROL (SFD-STR-004)
// ═══════════════════════════════════════════════

/// Access level.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AccessLevel {
    Read,       // decode only
    Query,      // + compressed-domain queries
    Write,      // + contribute live data
}

impl AccessLevel {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "read" => Some(Self::Read),
            "query" => Some(Self::Query),
            "write" => Some(Self::Write),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self { Self::Read => "read", Self::Query => "query", Self::Write => "write" }
    }

    /// Check if this level permits a given action.
    pub fn permits(&self, required: AccessLevel) -> bool {
        match (self, required) {
            (_, AccessLevel::Read) => true,
            (AccessLevel::Query, AccessLevel::Query) => true,
            (AccessLevel::Write, _) => true,
            _ => false,
        }
    }
}

/// Access control rule (SFD-STR-004).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AccessRule {
    pub id: u64,
    pub client_pattern: String,     // IP, subnet (10.0.1.*), or identifier
    pub file_pattern: String,       // path or wildcard *
    pub access: AccessLevel,
}

/// Access control manager.
#[derive(Debug, Default)]
pub struct AccessControl {
    rules: Vec<AccessRule>,
    next_id: u64,
}

impl AccessControl {
    pub fn new() -> Self { Self { rules: Vec::new(), next_id: 1 } }

    /// Add a rule.
    pub fn add_rule(&mut self, client: &str, file: &str, access: AccessLevel) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        self.rules.push(AccessRule {
            id, client_pattern: client.to_string(),
            file_pattern: file.to_string(), access,
        });
        id
    }

    /// Remove a rule by ID.
    pub fn remove_rule(&mut self, id: u64) -> bool {
        let before = self.rules.len();
        self.rules.retain(|r| r.id != id);
        self.rules.len() < before
    }

    /// Evaluate access for a client + file combination.
    /// Returns the most permissive matching rule, or None (deny).
    pub fn evaluate(&self, client: &str, file: &str) -> Option<AccessLevel> {
        let mut best: Option<AccessLevel> = None;

        for rule in &self.rules {
            if matches_pattern(&rule.client_pattern, client)
                && matches_pattern(&rule.file_pattern, file)
            {
                match best {
                    None => best = Some(rule.access),
                    Some(current) => {
                        if rule.access.permits(current) && !current.permits(rule.access) {
                            best = Some(rule.access);
                        }
                    }
                }
            }
        }

        best
    }

    /// List all rules.
    pub fn list(&self) -> &[AccessRule] { &self.rules }

    /// Export as JSON.
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(&self.rules).unwrap_or_default()
    }
}

/// Simple wildcard pattern matching (* matches any).
fn matches_pattern(pattern: &str, value: &str) -> bool {
    if pattern == "*" { return true; }
    if pattern.ends_with('*') {
        let prefix = &pattern[..pattern.len() - 1];
        return value.starts_with(prefix);
    }
    pattern == value
}

// ═══════════════════════════════════════════════
// REST API RESPONSE TYPES
// ═══════════════════════════════════════════════

/// API response envelope.
#[derive(Debug, Serialize)]
pub struct ApiResponse<T: Serialize> {
    pub ok: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T: Serialize> ApiResponse<T> {
    pub fn success(data: T) -> Self { Self { ok: true, data: Some(data), error: None } }
    pub fn to_json(&self) -> String { serde_json::to_string(self).unwrap_or_default() }
}

pub fn error_response(msg: &str) -> String {
    format!(r#"{{"ok":false,"error":"{}"}}"#, msg.replace('"', "\\\""))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dashboard_kpis() {
        let mut d = DashboardState::default();
        d.add_session(SessionRow {
            session_id: 1, client_ip: "10.0.1.5".into(),
            file_path: "/nord.ppv".into(), duration_secs: 120.0,
            blocks_sent: 4200, bytes_sent: 500_000, bandwidth_mbps: 4.0,
            access_level: "read".into(), is_live: false,
        });
        d.add_session(SessionRow {
            session_id: 2, client_ip: "10.0.1.8".into(),
            file_path: "/sud.ppv".into(), duration_secs: 60.0,
            blocks_sent: 2100, bytes_sent: 250_000, bandwidth_mbps: 2.0,
            access_level: "query".into(), is_live: true,
        });
        assert_eq!(d.kpi.active_sessions, 2);
        assert_eq!(d.kpi.total_bandwidth_mbps, 6.0);

        d.remove_session(1);
        assert_eq!(d.kpi.active_sessions, 1);
        assert_eq!(d.kpi.total_bandwidth_mbps, 2.0);
    }

    #[test]
    fn test_dashboard_json() {
        let d = DashboardState::default();
        let json = d.to_json();
        assert!(json.contains("active_sessions"));
    }

    #[test]
    fn test_access_level_permits() {
        assert!(AccessLevel::Write.permits(AccessLevel::Read));
        assert!(AccessLevel::Write.permits(AccessLevel::Query));
        assert!(AccessLevel::Query.permits(AccessLevel::Read));
        assert!(!AccessLevel::Read.permits(AccessLevel::Query));
    }

    #[test]
    fn test_access_rules() {
        let mut ac = AccessControl::new();
        ac.add_rule("10.0.1.*", "*", AccessLevel::Read);
        ac.add_rule("analyst01", "/nord.ppv", AccessLevel::Query);
        ac.add_rule("encoder01", "*", AccessLevel::Write);

        assert_eq!(ac.evaluate("10.0.1.5", "/sud.ppv"), Some(AccessLevel::Read));
        assert_eq!(ac.evaluate("analyst01", "/nord.ppv"), Some(AccessLevel::Query));
        assert_eq!(ac.evaluate("encoder01", "/any.ppv"), Some(AccessLevel::Write));
        assert_eq!(ac.evaluate("unknown", "/test.ppv"), None); // denied
    }

    #[test]
    fn test_rule_crud() {
        let mut ac = AccessControl::new();
        let id = ac.add_rule("*", "*", AccessLevel::Read);
        assert_eq!(ac.list().len(), 1);
        ac.remove_rule(id);
        assert_eq!(ac.list().len(), 0);
    }

    #[test]
    fn test_wildcard_matching() {
        assert!(matches_pattern("*", "anything"));
        assert!(matches_pattern("10.0.1.*", "10.0.1.5"));
        assert!(!matches_pattern("10.0.1.*", "10.0.2.5"));
        assert!(matches_pattern("/cam.ppv", "/cam.ppv"));
        assert!(!matches_pattern("/cam.ppv", "/other.ppv"));
    }

    #[test]
    fn test_api_response() {
        let resp = ApiResponse::success(vec!["file1", "file2"]);
        assert!(resp.ok);
        let json = resp.to_json();
        assert!(json.contains("file1"));
    }
}
