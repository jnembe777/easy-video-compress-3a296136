//! # Catalog Manager — .ppv file registry (SFD-STR-001)
//! Ref: modSFD STR-001, modMCD pp_catalog.ppv_files
#![forbid(unsafe_code)]

use pp_codec::encoder::PpvFile;
use serde::{Serialize, Deserialize};
use std::collections::HashMap;

/// Metadata for a catalogued .ppv file.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CatalogEntry {
    pub id: String,
    pub path: String,
    pub width: u32,
    pub height: u32,
    pub frames: u32,
    pub block_size: u32,
    pub palette_size: u32,
    pub num_blocks: u32,
    pub blocks_x: u32,
    pub blocks_y: u32,
    pub file_bytes: usize,
    pub total_bits: usize,
    pub ratio: f64,
    pub created_at: String,
}

/// The file catalog (SFD-STR-001).
#[derive(Debug, Default)]
pub struct Catalog {
    entries: HashMap<String, CatalogEntry>,
    next_id: u64,
}

impl Catalog {
    pub fn new() -> Self { Self { entries: HashMap::new(), next_id: 1 } }

    /// Index a .ppv file from its binary content.
    pub fn index_file(&mut self, path: &str, data: &[u8]) -> Result<CatalogEntry, String> {
        let ppv = PpvFile::deserialize(data)
            .ok_or_else(|| format!("invalid .ppv: {}", path))?;

        let bs = ppv.block_size;
        let bx = (ppv.width + bs - 1) / bs;
        let by = (ppv.height + bs - 1) / bs;
        let total_bits: usize = ppv.block_bits.iter().sum();
        let pixels = ppv.width as u64 * ppv.height as u64 * ppv.frames as u64;
        let mbits = (ppv.palette_size as f64).log2().ceil().max(1.0) as u64;
        let raw_bits = pixels * mbits;
        let ratio = if total_bits > 0 { raw_bits as f64 / total_bits as f64 } else { 0.0 };

        let id = format!("ppv-{:04}", self.next_id);
        self.next_id += 1;

        let entry = CatalogEntry {
            id: id.clone(),
            path: path.to_string(),
            width: ppv.width, height: ppv.height, frames: ppv.frames,
            block_size: bs, palette_size: ppv.palette_size,
            num_blocks: bx * by, blocks_x: bx, blocks_y: by,
            file_bytes: data.len(),
            total_bits, ratio,
            created_at: "2026-03-20T00:00:00Z".to_string(),
        };

        self.entries.insert(id, entry.clone());
        Ok(entry)
    }

    /// Remove a file from the catalog.
    pub fn remove(&mut self, id: &str) -> Option<CatalogEntry> {
        self.entries.remove(id)
    }

    /// Get entry by ID.
    pub fn get(&self, id: &str) -> Option<&CatalogEntry> { self.entries.get(id) }

    /// Search by path pattern.
    pub fn search(&self, pattern: &str) -> Vec<&CatalogEntry> {
        let lower = pattern.to_lowercase();
        self.entries.values()
            .filter(|e| e.path.to_lowercase().contains(&lower))
            .collect()
    }

    /// List all entries.
    pub fn list(&self) -> Vec<&CatalogEntry> {
        let mut entries: Vec<_> = self.entries.values().collect();
        entries.sort_by(|a, b| a.path.cmp(&b.path));
        entries
    }

    /// Count.
    pub fn count(&self) -> usize { self.entries.len() }

    /// Total bytes across all files.
    pub fn total_bytes(&self) -> usize {
        self.entries.values().map(|e| e.file_bytes).sum()
    }

    /// Export catalog as JSON.
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(&self.list()).unwrap_or_default()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pp_codec::encoder::encode_video;

    fn make_ppv_bytes() -> Vec<u8> {
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        encode_video(&frames, 8, 8, 8, 4).serialize()
    }

    #[test]
    fn test_index() {
        let mut cat = Catalog::new();
        let entry = cat.index_file("/cam/nord.ppv", &make_ppv_bytes()).unwrap();
        assert_eq!(entry.width, 8);
        assert_eq!(entry.frames, 16);
        assert_eq!(cat.count(), 1);
    }

    #[test]
    fn test_list_and_search() {
        let mut cat = Catalog::new();
        cat.index_file("/cam/nord.ppv", &make_ppv_bytes()).unwrap();
        cat.index_file("/cam/sud.ppv", &make_ppv_bytes()).unwrap();
        assert_eq!(cat.list().len(), 2);
        assert_eq!(cat.search("nord").len(), 1);
        assert_eq!(cat.search("cam").len(), 2);
    }

    #[test]
    fn test_remove() {
        let mut cat = Catalog::new();
        let e = cat.index_file("/test.ppv", &make_ppv_bytes()).unwrap();
        assert_eq!(cat.count(), 1);
        cat.remove(&e.id);
        assert_eq!(cat.count(), 0);
    }

    #[test]
    fn test_json() {
        let mut cat = Catalog::new();
        cat.index_file("/test.ppv", &make_ppv_bytes()).unwrap();
        let json = cat.to_json();
        assert!(json.contains("test.ppv"));
        assert!(json.contains("width"));
    }
}
