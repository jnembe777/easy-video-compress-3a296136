//! # STV-URI 1.0 — Spatio-Temporal Video URI
//!
//! Parser, resolver and composer for the PP-CODEC addressing scheme.
//! Ref: specS STV-URI 1.0 §2.1–2.5
//!
//! ## Syntax
//! ```text
//! ppv://authority/path[#fragment]
//! fragment := param ( '&' param )*
//! param    := key '=' value
//! ```
//!
//! ## Reserved keys
//! t, b, p, lod, tag, color, act, fam, fmt, w, speed

#![forbid(unsafe_code)]

use std::collections::BTreeMap;
use std::fmt;

/// URI scheme variants.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StvScheme {
    Ppv,        // ppv:// — VOD via PPSP
    Ppl,        // ppl:// — Live stream
    PpvHttps,   // ppv+https:// — HTTP fallback
}

impl fmt::Display for StvScheme {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            StvScheme::Ppv => write!(f, "ppv"),
            StvScheme::Ppl => write!(f, "ppl"),
            StvScheme::PpvHttps => write!(f, "ppv+https"),
        }
    }
}

/// Temporal range: single frame or interval.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FrameRange {
    Single(i64),             // t=120 (negative for live: t=-30)
    Interval(i64, i64),      // t=100:500
}

/// Spatial block region.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BlockRegion {
    Single(u32, u32),                // b=5,3
    Range(u32, u32, u32, u32),       // b=2,1:8,6 (x1,y1,x2,y2)
}

/// Pixel coordinates.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PixelCoord {
    pub x: u32,
    pub y: u32,
}

/// Level of detail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LodLevel {
    Auto,
    N(u8),  // N0, N1, N2, N3, N4
}

impl fmt::Display for LodLevel {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            LodLevel::Auto => write!(f, "auto"),
            LodLevel::N(n) => write!(f, "N{}", n),
        }
    }
}

/// Output format.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OutputFormat {
    Raw,
    Json,
    Image,
    Stream,
}

/// Parsed STV-URI fragment — all optional parameters.
#[derive(Debug, Clone, Default)]
pub struct StvFragment {
    pub t: Option<FrameRange>,
    pub b: Option<BlockRegion>,
    pub p: Option<PixelCoord>,
    pub lod: Option<LodLevel>,
    pub tag: Option<String>,
    pub color: Option<String>,        // "#RRGGBB" or "palette:N"
    pub act: Option<f64>,             // activity threshold (0.0–1.0)
    pub fam: Option<String>,          // family name
    pub fmt: Option<OutputFormat>,
    pub extra: BTreeMap<String, String>, // unknown keys preserved
}

/// A fully parsed STV-URI.
#[derive(Debug, Clone)]
pub struct StvUri {
    pub scheme: StvScheme,
    pub authority: String,
    pub path: String,
    pub fragment: StvFragment,
}

/// Parse error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StvParseError {
    InvalidScheme(String),
    MissingAuthority,
    MissingPath,
    InvalidFragment(String),
    InvalidValue(String, String),
}

impl fmt::Display for StvParseError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            StvParseError::InvalidScheme(s) => write!(f, "invalid scheme: {}", s),
            StvParseError::MissingAuthority => write!(f, "missing authority"),
            StvParseError::MissingPath => write!(f, "missing path"),
            StvParseError::InvalidFragment(s) => write!(f, "invalid fragment: {}", s),
            StvParseError::InvalidValue(k, v) => write!(f, "invalid value for {}: {}", k, v),
        }
    }
}

impl StvUri {
    /// Parse an STV-URI string.
    ///
    /// Accepts: ppv://authority/path[#fragment]
    ///          ppl://authority/path[#fragment]
    ///          ppv+https://authority/path[#fragment]
    pub fn parse(input: &str) -> Result<Self, StvParseError> {
        let input = input.trim();

        // 1. Split scheme
        let (scheme, rest) = if input.starts_with("ppv+https://") {
            (StvScheme::PpvHttps, &input[12..])
        } else if input.starts_with("ppv://") {
            (StvScheme::Ppv, &input[6..])
        } else if input.starts_with("ppl://") {
            (StvScheme::Ppl, &input[6..])
        } else {
            let end = input.find("://").unwrap_or(input.len().min(20));
            return Err(StvParseError::InvalidScheme(input[..end].to_string()));
        };

        // 2. Split fragment
        let (authority_path, frag_str) = match rest.find('#') {
            Some(pos) => (&rest[..pos], Some(&rest[pos + 1..])),
            None => (rest, None),
        };

        // 3. Split authority / path
        let slash_pos = authority_path.find('/')
            .ok_or(StvParseError::MissingPath)?;
        let authority = authority_path[..slash_pos].to_string();
        if authority.is_empty() {
            return Err(StvParseError::MissingAuthority);
        }
        let path = authority_path[slash_pos..].to_string();

        // 4. Parse fragment
        let fragment = match frag_str {
            Some(s) if !s.is_empty() => parse_fragment(s)?,
            _ => StvFragment::default(),
        };

        Ok(StvUri { scheme, authority, path, fragment })
    }

    /// Compose URI back to string.
    pub fn to_string(&self) -> String {
        let mut s = format!("{}://{}{}", self.scheme, self.authority, self.path);
        let frag = compose_fragment(&self.fragment);
        if !frag.is_empty() {
            s.push('#');
            s.push_str(&frag);
        }
        s
    }

    /// Compose a new URI by merging additional fragment parameters.
    /// Existing keys are overridden by the new fragment.
    pub fn with_fragment(&self, additional: &StvFragment) -> StvUri {
        let mut merged = self.fragment.clone();
        if additional.t.is_some() { merged.t = additional.t.clone(); }
        if additional.b.is_some() { merged.b = additional.b.clone(); }
        if additional.p.is_some() { merged.p = additional.p.clone(); }
        if additional.lod.is_some() { merged.lod = additional.lod.clone(); }
        if additional.tag.is_some() { merged.tag = additional.tag.clone(); }
        if additional.color.is_some() { merged.color = additional.color.clone(); }
        if additional.act.is_some() { merged.act = additional.act; }
        if additional.fam.is_some() { merged.fam = additional.fam.clone(); }
        if additional.fmt.is_some() { merged.fmt = additional.fmt.clone(); }
        for (k, v) in &additional.extra {
            merged.extra.insert(k.clone(), v.clone());
        }
        StvUri {
            scheme: self.scheme.clone(),
            authority: self.authority.clone(),
            path: self.path.clone(),
            fragment: merged,
        }
    }
}

/// Extraction plan produced by resolving a STV-URI against a .ppv header.
#[derive(Debug, Clone)]
pub struct ExtractionPlan {
    pub block_ids: Vec<usize>,
    pub lod: u8,
    pub frame_range: (u32, u32),   // (start, end) inclusive
    pub filters: Vec<String>,       // semantic filters to apply
}

/// Resolve a STV-URI fragment against a .ppv header to produce an extraction plan.
///
/// ## Arguments
/// * `frag` — parsed fragment
/// * `width`, `height`, `frames`, `block_size` — from PpvFile header
pub fn resolve(
    frag: &StvFragment,
    width: u32,
    height: u32,
    frames: u32,
    block_size: u32,
) -> ExtractionPlan {
    let blocks_x = (width + block_size - 1) / block_size;
    let blocks_y = (height + block_size - 1) / block_size;
    let total_blocks = (blocks_x * blocks_y) as usize;

    // 1. Frame range
    let (t_start, t_end) = match &frag.t {
        Some(FrameRange::Single(t)) => {
            let t = if *t < 0 { (frames as i64 + t).max(0) as u32 } else { *t as u32 };
            (t.min(frames - 1), t.min(frames - 1))
        }
        Some(FrameRange::Interval(a, b)) => {
            let a = if *a < 0 { (frames as i64 + a).max(0) as u32 } else { *a as u32 };
            let b = if *b < 0 { (frames as i64 + b).max(0) as u32 } else { *b as u32 };
            (a.min(frames - 1), b.min(frames - 1))
        }
        None => (0, frames - 1),
    };

    // 2. Block selection
    let block_ids: Vec<usize> = match &frag.b {
        Some(BlockRegion::Single(bx, by)) => {
            let id = (*by * blocks_x + *bx) as usize;
            if id < total_blocks { vec![id] } else { vec![] }
        }
        Some(BlockRegion::Range(x1, y1, x2, y2)) => {
            let mut ids = Vec::new();
            for by in *y1..=*y2 {
                for bx in *x1..=*x2 {
                    let id = (by * blocks_x + bx) as usize;
                    if id < total_blocks { ids.push(id); }
                }
            }
            ids
        }
        None => {
            // Check if pixel coord specifies a block
            match &frag.p {
                Some(PixelCoord { x, y }) => {
                    let bx = x / block_size;
                    let by = y / block_size;
                    let id = (by * blocks_x + bx) as usize;
                    if id < total_blocks { vec![id] } else { vec![] }
                }
                None => (0..total_blocks).collect(), // all blocks
            }
        }
    };

    // 3. LOD
    let lod = match &frag.lod {
        Some(LodLevel::N(n)) => *n,
        _ => {
            // Auto: compute from block count (fewer blocks = higher LOD)
            let ratio = total_blocks as f64 / block_ids.len().max(1) as f64;
            if ratio > 10.0 { 3 } else if ratio > 4.0 { 2 } else if ratio > 1.5 { 1 } else { 0 }
        }
    };

    // 4. Filters
    let mut filters = Vec::new();
    if let Some(ref tag) = frag.tag { filters.push(format!("tag={}", tag)); }
    if let Some(ref color) = frag.color { filters.push(format!("color={}", color)); }
    if let Some(act) = frag.act { filters.push(format!("act>{:.3}", act)); }
    if let Some(ref fam) = frag.fam { filters.push(format!("fam={}", fam)); }

    ExtractionPlan {
        block_ids,
        lod,
        frame_range: (t_start, t_end),
        filters,
    }
}

// ═══ Internal parsing helpers ═══

fn parse_fragment(s: &str) -> Result<StvFragment, StvParseError> {
    let mut frag = StvFragment::default();
    for param in s.split('&') {
        if param.is_empty() { continue; }
        let (key, value) = match param.find('=') {
            Some(pos) => (&param[..pos], &param[pos + 1..]),
            None => return Err(StvParseError::InvalidFragment(param.to_string())),
        };
        match key {
            "t" => { frag.t = Some(parse_frame_range(value)?); }
            "b" => { frag.b = Some(parse_block_region(value)?); }
            "p" => { frag.p = Some(parse_pixel_coord(value)?); }
            "lod" => { frag.lod = Some(parse_lod(value)?); }
            "tag" => { frag.tag = Some(value.to_string()); }
            "color" => { frag.color = Some(value.to_string()); }
            "act" => {
                let v: f64 = value.parse().map_err(|_| StvParseError::InvalidValue("act".into(), value.into()))?;
                frag.act = Some(v);
            }
            "fam" => { frag.fam = Some(value.to_string()); }
            "fmt" => { frag.fmt = Some(parse_format(value)?); }
            _ => { frag.extra.insert(key.to_string(), value.to_string()); }
        }
    }
    Ok(frag)
}

fn parse_frame_range(s: &str) -> Result<FrameRange, StvParseError> {
    if let Some(pos) = s.find(':') {
        let a: i64 = s[..pos].parse().map_err(|_| StvParseError::InvalidValue("t".into(), s.into()))?;
        let b: i64 = s[pos+1..].parse().map_err(|_| StvParseError::InvalidValue("t".into(), s.into()))?;
        Ok(FrameRange::Interval(a, b))
    } else {
        let v: i64 = s.parse().map_err(|_| StvParseError::InvalidValue("t".into(), s.into()))?;
        Ok(FrameRange::Single(v))
    }
}

fn parse_block_region(s: &str) -> Result<BlockRegion, StvParseError> {
    if let Some(pos) = s.find(':') {
        let left = &s[..pos];
        let right = &s[pos+1..];
        let (x1, y1) = parse_xy(left, "b")?;
        let (x2, y2) = parse_xy(right, "b")?;
        Ok(BlockRegion::Range(x1, y1, x2, y2))
    } else {
        let (x, y) = parse_xy(s, "b")?;
        Ok(BlockRegion::Single(x, y))
    }
}

fn parse_xy(s: &str, key: &str) -> Result<(u32, u32), StvParseError> {
    let parts: Vec<&str> = s.split(',').collect();
    if parts.len() != 2 {
        return Err(StvParseError::InvalidValue(key.into(), s.into()));
    }
    let x: u32 = parts[0].parse().map_err(|_| StvParseError::InvalidValue(key.into(), s.into()))?;
    let y: u32 = parts[1].parse().map_err(|_| StvParseError::InvalidValue(key.into(), s.into()))?;
    Ok((x, y))
}

fn parse_pixel_coord(s: &str) -> Result<PixelCoord, StvParseError> {
    let (x, y) = parse_xy(s, "p")?;
    Ok(PixelCoord { x, y })
}

fn parse_lod(s: &str) -> Result<LodLevel, StvParseError> {
    match s {
        "auto" => Ok(LodLevel::Auto),
        _ if s.starts_with('N') || s.starts_with('n') => {
            let n: u8 = s[1..].parse().map_err(|_| StvParseError::InvalidValue("lod".into(), s.into()))?;
            Ok(LodLevel::N(n))
        }
        _ => Err(StvParseError::InvalidValue("lod".into(), s.into())),
    }
}

fn parse_format(s: &str) -> Result<OutputFormat, StvParseError> {
    match s {
        "raw" => Ok(OutputFormat::Raw),
        "json" => Ok(OutputFormat::Json),
        "image" => Ok(OutputFormat::Image),
        "stream" => Ok(OutputFormat::Stream),
        _ => Err(StvParseError::InvalidValue("fmt".into(), s.into())),
    }
}

fn compose_fragment(frag: &StvFragment) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(ref t) = frag.t {
        match t {
            FrameRange::Single(v) => parts.push(format!("t={}", v)),
            FrameRange::Interval(a, b) => parts.push(format!("t={}:{}", a, b)),
        }
    }
    if let Some(ref b) = frag.b {
        match b {
            BlockRegion::Single(x, y) => parts.push(format!("b={},{}", x, y)),
            BlockRegion::Range(x1, y1, x2, y2) => parts.push(format!("b={},{}:{},{}", x1, y1, x2, y2)),
        }
    }
    if let Some(ref p) = frag.p { parts.push(format!("p={},{}", p.x, p.y)); }
    if let Some(ref l) = frag.lod { parts.push(format!("lod={}", l)); }
    if let Some(ref tag) = frag.tag { parts.push(format!("tag={}", tag)); }
    if let Some(ref c) = frag.color { parts.push(format!("color={}", c)); }
    if let Some(act) = frag.act { parts.push(format!("act={:.3}", act)); }
    if let Some(ref f) = frag.fam { parts.push(format!("fam={}", f)); }
    if let Some(ref f) = frag.fmt {
        let s = match f {
            OutputFormat::Raw => "raw",
            OutputFormat::Json => "json",
            OutputFormat::Image => "image",
            OutputFormat::Stream => "stream",
        };
        parts.push(format!("fmt={}", s));
    }
    for (k, v) in &frag.extra {
        parts.push(format!("{}={}", k, v));
    }
    parts.join("&")
}

// ═══════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_basic() {
        let uri = StvUri::parse("ppv://cam.local/nord.ppv").unwrap();
        assert_eq!(uri.scheme, StvScheme::Ppv);
        assert_eq!(uri.authority, "cam.local");
        assert_eq!(uri.path, "/nord.ppv");
    }

    #[test]
    fn test_parse_ppl() {
        let uri = StvUri::parse("ppl://cam.live/stream").unwrap();
        assert_eq!(uri.scheme, StvScheme::Ppl);
    }

    #[test]
    fn test_parse_ppv_https() {
        let uri = StvUri::parse("ppv+https://cdn.example.com/video.ppv").unwrap();
        assert_eq!(uri.scheme, StvScheme::PpvHttps);
    }

    #[test]
    fn test_parse_fragment_t_single() {
        let uri = StvUri::parse("ppv://cam/feed.ppv#t=120").unwrap();
        assert_eq!(uri.fragment.t, Some(FrameRange::Single(120)));
    }

    #[test]
    fn test_parse_fragment_t_range() {
        let uri = StvUri::parse("ppv://cam/feed.ppv#t=100:500").unwrap();
        assert_eq!(uri.fragment.t, Some(FrameRange::Interval(100, 500)));
    }

    #[test]
    fn test_parse_fragment_t_negative() {
        let uri = StvUri::parse("ppl://cam/stream#t=-30").unwrap();
        assert_eq!(uri.fragment.t, Some(FrameRange::Single(-30)));
    }

    #[test]
    fn test_parse_fragment_block() {
        let uri = StvUri::parse("ppv://cam/f.ppv#b=5,3").unwrap();
        assert_eq!(uri.fragment.b, Some(BlockRegion::Single(5, 3)));
    }

    #[test]
    fn test_parse_fragment_block_range() {
        let uri = StvUri::parse("ppv://cam/f.ppv#b=2,1:8,6").unwrap();
        assert_eq!(uri.fragment.b, Some(BlockRegion::Range(2, 1, 8, 6)));
    }

    #[test]
    fn test_parse_fragment_pixel() {
        let uri = StvUri::parse("ppv://cam/f.ppv#p=120,80").unwrap();
        assert_eq!(uri.fragment.p, Some(PixelCoord { x: 120, y: 80 }));
    }

    #[test]
    fn test_parse_fragment_lod() {
        let uri = StvUri::parse("ppv://cam/f.ppv#lod=N2").unwrap();
        assert_eq!(uri.fragment.lod, Some(LodLevel::N(2)));
    }

    #[test]
    fn test_parse_fragment_lod_auto() {
        let uri = StvUri::parse("ppv://cam/f.ppv#lod=auto").unwrap();
        assert_eq!(uri.fragment.lod, Some(LodLevel::Auto));
    }

    #[test]
    fn test_parse_multi_params() {
        let uri = StvUri::parse("ppv://cam/f.ppv#t=100:200&b=5,3&lod=N3&act=0.1&fam=bspline").unwrap();
        assert_eq!(uri.fragment.t, Some(FrameRange::Interval(100, 200)));
        assert_eq!(uri.fragment.b, Some(BlockRegion::Single(5, 3)));
        assert_eq!(uri.fragment.lod, Some(LodLevel::N(3)));
        assert_eq!(uri.fragment.act, Some(0.1));
        assert_eq!(uri.fragment.fam, Some("bspline".into()));
    }

    #[test]
    fn test_roundtrip() {
        let input = "ppv://cam.local/nord.ppv#t=100:200&b=5,3&lod=N2";
        let uri = StvUri::parse(input).unwrap();
        let output = uri.to_string();
        let uri2 = StvUri::parse(&output).unwrap();
        assert_eq!(uri2.fragment.t, uri.fragment.t);
        assert_eq!(uri2.fragment.b, uri.fragment.b);
        assert_eq!(uri2.fragment.lod, uri.fragment.lod);
    }

    #[test]
    fn test_compose_fragment() {
        let base = StvUri::parse("ppv://cam/f.ppv#t=120").unwrap();
        let mut extra = StvFragment::default();
        extra.b = Some(BlockRegion::Single(5, 3));
        extra.lod = Some(LodLevel::N(3));
        let merged = base.with_fragment(&extra);
        assert_eq!(merged.fragment.t, Some(FrameRange::Single(120)));
        assert_eq!(merged.fragment.b, Some(BlockRegion::Single(5, 3)));
        assert_eq!(merged.fragment.lod, Some(LodLevel::N(3)));
    }

    #[test]
    fn test_resolve_full() {
        let frag = StvFragment::default(); // no filters = all blocks
        let plan = resolve(&frag, 1920, 1080, 1024, 16);
        assert_eq!(plan.block_ids.len(), 120 * 68); // ceil(1920/16) * ceil(1080/16)
        assert_eq!(plan.frame_range, (0, 1023));
    }

    #[test]
    fn test_resolve_single_block() {
        let mut frag = StvFragment::default();
        frag.b = Some(BlockRegion::Single(5, 3));
        frag.t = Some(FrameRange::Interval(100, 200));
        let plan = resolve(&frag, 1920, 1080, 1024, 16);
        assert_eq!(plan.block_ids.len(), 1);
        assert_eq!(plan.frame_range, (100, 200));
    }

    #[test]
    fn test_resolve_pixel_to_block() {
        let mut frag = StvFragment::default();
        frag.p = Some(PixelCoord { x: 120, y: 80 });
        let plan = resolve(&frag, 1920, 1080, 1024, 16);
        assert_eq!(plan.block_ids.len(), 1); // pixel (120,80) → block (7,5)
        let blocks_x = (1920 + 15) / 16;
        assert_eq!(plan.block_ids[0], (5 * blocks_x + 7) as usize);
    }

    #[test]
    fn test_resolve_negative_time_live() {
        let mut frag = StvFragment::default();
        frag.t = Some(FrameRange::Single(-30));
        let plan = resolve(&frag, 640, 480, 1000, 16);
        assert_eq!(plan.frame_range, (970, 970)); // 1000 - 30
    }

    #[test]
    fn test_invalid_scheme() {
        assert!(StvUri::parse("http://cam/f.ppv").is_err());
    }

    #[test]
    fn test_invalid_no_path() {
        assert!(StvUri::parse("ppv://cam").is_err());
    }

    #[test]
    fn test_format_parse() {
        let uri = StvUri::parse("ppv://cam/f.ppv#fmt=json").unwrap();
        assert_eq!(uri.fragment.fmt, Some(OutputFormat::Json));
    }

    #[test]
    fn test_color_and_tag() {
        let uri = StvUri::parse("ppv://cam/f.ppv#color=#FF0000&tag=vehicle").unwrap();
        assert_eq!(uri.fragment.color, Some("#FF0000".into()));
        assert_eq!(uri.fragment.tag, Some("vehicle".into()));
    }

    #[test]
    fn test_resolve_with_filters() {
        let mut frag = StvFragment::default();
        frag.act = Some(0.1);
        frag.fam = Some("trigo".into());
        frag.tag = Some("person".into());
        let plan = resolve(&frag, 640, 480, 512, 16);
        assert_eq!(plan.filters.len(), 3);
    }
}
