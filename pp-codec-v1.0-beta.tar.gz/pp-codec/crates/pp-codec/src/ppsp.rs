//! # PPSP 1.0 — Point Process Streaming Protocol
//!
//! Binary protocol for streaming PP-CODEC video over WebSocket or HTTP/2.
//! Ref: specS PPSP 1.0 §3.2
//!
//! ## Message format
//! ```text
//! [2B] magic    = 0x5050 ('PP')
//! [1B] version  = 0x01
//! [1B] msg_type = OPEN|HEADER|SEEK|DATA|QUERY|RESULT|CLOSE|ERROR
//! [4B] payload_length (little-endian)
//! [...] payload (msg_type-specific)
//! ```

#![forbid(unsafe_code)]

/// Protocol constants.
pub const PPSP_MAGIC: u16 = 0x5050;   // 'PP'
pub const PPSP_VERSION: u8 = 0x01;

/// Message type codes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum MsgType {
    Open    = 0x01,
    Header  = 0x02,
    Seek    = 0x03,
    Data    = 0x04,
    Query   = 0x05,
    Result  = 0x06,
    Close   = 0x07,
    Error   = 0x08,
}

impl MsgType {
    pub fn from_u8(v: u8) -> Option<Self> {
        match v {
            0x01 => Some(MsgType::Open),
            0x02 => Some(MsgType::Header),
            0x03 => Some(MsgType::Seek),
            0x04 => Some(MsgType::Data),
            0x05 => Some(MsgType::Query),
            0x06 => Some(MsgType::Result),
            0x07 => Some(MsgType::Close),
            0x08 => Some(MsgType::Error),
            _ => None,
        }
    }
}

/// Access level for a session.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AccessLevel {
    Read,
    Query,
    Write,
}

impl AccessLevel {
    pub fn to_u8(&self) -> u8 {
        match self { AccessLevel::Read => 1, AccessLevel::Query => 2, AccessLevel::Write => 3 }
    }
    pub fn from_u8(v: u8) -> Option<Self> {
        match v { 1 => Some(Self::Read), 2 => Some(Self::Query), 3 => Some(Self::Write), _ => None }
    }
}

/// Select type for query results.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SelectType {
    Blocks,
    Frames,
    Pixels,
    Events,
}

impl SelectType {
    pub fn to_u8(&self) -> u8 {
        match self { Self::Blocks => 1, Self::Frames => 2, Self::Pixels => 3, Self::Events => 4 }
    }
    pub fn from_u8(v: u8) -> Option<Self> {
        match v { 1 => Some(Self::Blocks), 2 => Some(Self::Frames), 3 => Some(Self::Pixels), 4 => Some(Self::Events), _ => None }
    }
}

/// Error codes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorCode {
    NotFound       = 404,
    AccessDenied   = 403,
    BadRequest     = 400,
    ServerError    = 500,
    SessionExpired = 410,
}

impl ErrorCode {
    pub fn from_u16(v: u16) -> Option<Self> {
        match v {
            404 => Some(Self::NotFound), 403 => Some(Self::AccessDenied),
            400 => Some(Self::BadRequest), 500 => Some(Self::ServerError),
            410 => Some(Self::SessionExpired), _ => None,
        }
    }
}

// ═══════════════════════════════════════════════
// MESSAGE PAYLOADS
// ═══════════════════════════════════════════════

/// Client → Server: Open a session.
#[derive(Debug, Clone)]
pub struct OpenMsg {
    pub uri: String,           // STV-URI
    pub access: AccessLevel,
}

/// Server → Client: Session opened, here's the header.
#[derive(Debug, Clone)]
pub struct HeaderMsg {
    pub session_id: u64,
    pub width: u32,
    pub height: u32,
    pub frames: u32,
    pub block_size: u32,
    pub palette_size: u32,
    pub num_blocks: u32,
}

/// Client → Server: Update viewport.
#[derive(Debug, Clone)]
pub struct SeekMsg {
    pub session_id: u64,
    pub fragment: String,      // STV-URI fragment (just the #part)
}

/// Server → Client: Block data.
#[derive(Debug, Clone)]
pub struct DataMsg {
    pub block_id: u32,
    pub lod: u8,
    pub frame_start: u32,
    pub frame_end: u32,
    pub data: Vec<u8>,         // compressed block data
}

/// Client → Server: Compressed-domain query.
#[derive(Debug, Clone)]
pub struct QueryMsg {
    pub session_id: u64,
    pub select: SelectType,
    pub expression: String,
}

/// Server → Client: Query results.
#[derive(Debug, Clone)]
pub struct ResultMsg {
    pub request_id: u64,
    pub total_count: u32,
    pub matches: Vec<BlockMatch>,
}

/// A single block match in query results.
#[derive(Debug, Clone)]
pub struct BlockMatch {
    pub block_id: u32,
    pub bx: u32,
    pub by: u32,
    pub n_total: u32,
    pub family: u8,            // 0=const, 1=hist, 2=bspline, 3=trigo, 4=daub
    pub activity: f32,
}

/// Client → Server: Close session.
#[derive(Debug, Clone)]
pub struct CloseMsg {
    pub session_id: u64,
}

/// Server → Client: Error.
#[derive(Debug, Clone)]
pub struct ErrorMsg {
    pub code: u16,
    pub message: String,
}

/// All PPSP messages in a single enum.
#[derive(Debug, Clone)]
pub enum PpspMessage {
    Open(OpenMsg),
    Header(HeaderMsg),
    Seek(SeekMsg),
    Data(DataMsg),
    Query(QueryMsg),
    Result(ResultMsg),
    Close(CloseMsg),
    Error(ErrorMsg),
}

// ═══════════════════════════════════════════════
// SERIALIZATION (binary, little-endian)
// ═══════════════════════════════════════════════

impl PpspMessage {
    /// Serialize to binary wire format.
    pub fn serialize(&self) -> Vec<u8> {
        let (msg_type, payload) = match self {
            PpspMessage::Open(m) => (MsgType::Open, serialize_open(m)),
            PpspMessage::Header(m) => (MsgType::Header, serialize_header(m)),
            PpspMessage::Seek(m) => (MsgType::Seek, serialize_seek(m)),
            PpspMessage::Data(m) => (MsgType::Data, serialize_data(m)),
            PpspMessage::Query(m) => (MsgType::Query, serialize_query(m)),
            PpspMessage::Result(m) => (MsgType::Result, serialize_result(m)),
            PpspMessage::Close(m) => (MsgType::Close, serialize_close(m)),
            PpspMessage::Error(m) => (MsgType::Error, serialize_error(m)),
        };

        let mut out = Vec::with_capacity(8 + payload.len());
        out.extend_from_slice(&PPSP_MAGIC.to_le_bytes());
        out.push(PPSP_VERSION);
        out.push(msg_type as u8);
        out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        out.extend_from_slice(&payload);
        out
    }

    /// Deserialize from binary wire format.
    pub fn deserialize(data: &[u8]) -> Option<Self> {
        if data.len() < 8 { return None; }
        let magic = u16::from_le_bytes([data[0], data[1]]);
        if magic != PPSP_MAGIC { return None; }
        let _version = data[2];
        let msg_type = MsgType::from_u8(data[3])?;
        let payload_len = u32::from_le_bytes([data[4], data[5], data[6], data[7]]) as usize;
        if data.len() < 8 + payload_len { return None; }
        let payload = &data[8..8 + payload_len];

        match msg_type {
            MsgType::Open => deserialize_open(payload).map(PpspMessage::Open),
            MsgType::Header => deserialize_header(payload).map(PpspMessage::Header),
            MsgType::Seek => deserialize_seek(payload).map(PpspMessage::Seek),
            MsgType::Data => deserialize_data(payload).map(PpspMessage::Data),
            MsgType::Query => deserialize_query(payload).map(PpspMessage::Query),
            MsgType::Result => deserialize_result(payload).map(PpspMessage::Result),
            MsgType::Close => deserialize_close(payload).map(PpspMessage::Close),
            MsgType::Error => deserialize_error(payload).map(PpspMessage::Error),
        }
    }

    /// Message type.
    pub fn msg_type(&self) -> MsgType {
        match self {
            PpspMessage::Open(_) => MsgType::Open,
            PpspMessage::Header(_) => MsgType::Header,
            PpspMessage::Seek(_) => MsgType::Seek,
            PpspMessage::Data(_) => MsgType::Data,
            PpspMessage::Query(_) => MsgType::Query,
            PpspMessage::Result(_) => MsgType::Result,
            PpspMessage::Close(_) => MsgType::Close,
            PpspMessage::Error(_) => MsgType::Error,
        }
    }
}

// ═══ Helpers ═══

fn write_u16(buf: &mut Vec<u8>, v: u16) { buf.extend_from_slice(&v.to_le_bytes()); }
fn write_u32(buf: &mut Vec<u8>, v: u32) { buf.extend_from_slice(&v.to_le_bytes()); }
fn write_u64(buf: &mut Vec<u8>, v: u64) { buf.extend_from_slice(&v.to_le_bytes()); }
fn write_f32(buf: &mut Vec<u8>, v: f32) { buf.extend_from_slice(&v.to_le_bytes()); }
fn write_str(buf: &mut Vec<u8>, s: &str) {
    write_u32(buf, s.len() as u32);
    buf.extend_from_slice(s.as_bytes());
}
fn read_u16(data: &[u8], off: &mut usize) -> Option<u16> {
    if *off + 2 > data.len() { return None; }
    let v = u16::from_le_bytes([data[*off], data[*off+1]]); *off += 2; Some(v)
}
fn read_u32(data: &[u8], off: &mut usize) -> Option<u32> {
    if *off + 4 > data.len() { return None; }
    let v = u32::from_le_bytes([data[*off], data[*off+1], data[*off+2], data[*off+3]]); *off += 4; Some(v)
}
fn read_u64(data: &[u8], off: &mut usize) -> Option<u64> {
    if *off + 8 > data.len() { return None; }
    let v = u64::from_le_bytes(data[*off..*off+8].try_into().ok()?); *off += 8; Some(v)
}
fn read_f32(data: &[u8], off: &mut usize) -> Option<f32> {
    if *off + 4 > data.len() { return None; }
    let v = f32::from_le_bytes([data[*off], data[*off+1], data[*off+2], data[*off+3]]); *off += 4; Some(v)
}
fn read_str(data: &[u8], off: &mut usize) -> Option<String> {
    let len = read_u32(data, off)? as usize;
    if *off + len > data.len() { return None; }
    let s = std::str::from_utf8(&data[*off..*off+len]).ok()?.to_string();
    *off += len; Some(s)
}

fn serialize_open(m: &OpenMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_str(&mut buf, &m.uri);
    buf.push(m.access.to_u8());
    buf
}
fn deserialize_open(data: &[u8]) -> Option<OpenMsg> {
    let mut off = 0;
    let uri = read_str(data, &mut off)?;
    let access = AccessLevel::from_u8(*data.get(off)?)?;
    Some(OpenMsg { uri, access })
}

fn serialize_header(m: &HeaderMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u64(&mut buf, m.session_id);
    write_u32(&mut buf, m.width); write_u32(&mut buf, m.height);
    write_u32(&mut buf, m.frames); write_u32(&mut buf, m.block_size);
    write_u32(&mut buf, m.palette_size); write_u32(&mut buf, m.num_blocks);
    buf
}
fn deserialize_header(data: &[u8]) -> Option<HeaderMsg> {
    let mut off = 0;
    Some(HeaderMsg {
        session_id: read_u64(data, &mut off)?,
        width: read_u32(data, &mut off)?, height: read_u32(data, &mut off)?,
        frames: read_u32(data, &mut off)?, block_size: read_u32(data, &mut off)?,
        palette_size: read_u32(data, &mut off)?, num_blocks: read_u32(data, &mut off)?,
    })
}

fn serialize_seek(m: &SeekMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u64(&mut buf, m.session_id);
    write_str(&mut buf, &m.fragment);
    buf
}
fn deserialize_seek(data: &[u8]) -> Option<SeekMsg> {
    let mut off = 0;
    Some(SeekMsg { session_id: read_u64(data, &mut off)?, fragment: read_str(data, &mut off)? })
}

fn serialize_data(m: &DataMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u32(&mut buf, m.block_id); buf.push(m.lod);
    write_u32(&mut buf, m.frame_start); write_u32(&mut buf, m.frame_end);
    write_u32(&mut buf, m.data.len() as u32);
    buf.extend_from_slice(&m.data);
    buf
}
fn deserialize_data(data: &[u8]) -> Option<DataMsg> {
    let mut off = 0;
    let block_id = read_u32(data, &mut off)?;
    let lod = *data.get(off)?; off += 1;
    let frame_start = read_u32(data, &mut off)?;
    let frame_end = read_u32(data, &mut off)?;
    let data_len = read_u32(data, &mut off)? as usize;
    if off + data_len > data.len() { return None; }
    let block_data = data[off..off+data_len].to_vec();
    Some(DataMsg { block_id, lod, frame_start, frame_end, data: block_data })
}

fn serialize_query(m: &QueryMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u64(&mut buf, m.session_id);
    buf.push(m.select.to_u8());
    write_str(&mut buf, &m.expression);
    buf
}
fn deserialize_query(data: &[u8]) -> Option<QueryMsg> {
    let mut off = 0;
    let session_id = read_u64(data, &mut off)?;
    let select = SelectType::from_u8(*data.get(off)?)?; off += 1;
    let expression = read_str(data, &mut off)?;
    Some(QueryMsg { session_id, select, expression })
}

fn serialize_result(m: &ResultMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u64(&mut buf, m.request_id);
    write_u32(&mut buf, m.total_count);
    write_u32(&mut buf, m.matches.len() as u32);
    for bm in &m.matches {
        write_u32(&mut buf, bm.block_id);
        write_u32(&mut buf, bm.bx); write_u32(&mut buf, bm.by);
        write_u32(&mut buf, bm.n_total); buf.push(bm.family);
        write_f32(&mut buf, bm.activity);
    }
    buf
}
fn deserialize_result(data: &[u8]) -> Option<ResultMsg> {
    let mut off = 0;
    let request_id = read_u64(data, &mut off)?;
    let total_count = read_u32(data, &mut off)?;
    let match_count = read_u32(data, &mut off)? as usize;
    let mut matches = Vec::with_capacity(match_count);
    for _ in 0..match_count {
        matches.push(BlockMatch {
            block_id: read_u32(data, &mut off)?,
            bx: read_u32(data, &mut off)?, by: read_u32(data, &mut off)?,
            n_total: read_u32(data, &mut off)?,
            family: *data.get(off).unwrap_or(&0), // safe: checked by read_u32 above
            activity: { off += 1; read_f32(data, &mut off)? },
        });
    }
    Some(ResultMsg { request_id, total_count, matches })
}

fn serialize_close(m: &CloseMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u64(&mut buf, m.session_id);
    buf
}
fn deserialize_close(data: &[u8]) -> Option<CloseMsg> {
    let mut off = 0;
    Some(CloseMsg { session_id: read_u64(data, &mut off)? })
}

fn serialize_error(m: &ErrorMsg) -> Vec<u8> {
    let mut buf = Vec::new();
    write_u16(&mut buf, m.code);
    write_str(&mut buf, &m.message);
    buf
}
fn deserialize_error(data: &[u8]) -> Option<ErrorMsg> {
    let mut off = 0;
    Some(ErrorMsg { code: read_u16(data, &mut off)?, message: read_str(data, &mut off)? })
}

// ═══════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn roundtrip(msg: PpspMessage) -> PpspMessage {
        let bytes = msg.serialize();
        assert!(bytes.len() >= 8);
        assert_eq!(u16::from_le_bytes([bytes[0], bytes[1]]), PPSP_MAGIC);
        assert_eq!(bytes[2], PPSP_VERSION);
        PpspMessage::deserialize(&bytes).expect("roundtrip failed")
    }

    #[test]
    fn test_open_roundtrip() {
        let msg = PpspMessage::Open(OpenMsg {
            uri: "ppv://cam.local/nord.ppv#t=120&b=5,3".into(),
            access: AccessLevel::Query,
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Open(m) = rt {
            assert_eq!(m.uri, "ppv://cam.local/nord.ppv#t=120&b=5,3");
            assert_eq!(m.access, AccessLevel::Query);
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_header_roundtrip() {
        let msg = PpspMessage::Header(HeaderMsg {
            session_id: 42, width: 1920, height: 1080, frames: 1024,
            block_size: 16, palette_size: 8, num_blocks: 8160,
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Header(m) = rt {
            assert_eq!(m.session_id, 42);
            assert_eq!(m.width, 1920);
            assert_eq!(m.num_blocks, 8160);
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_seek_roundtrip() {
        let msg = PpspMessage::Seek(SeekMsg {
            session_id: 99, fragment: "t=200:300&lod=N3".into(),
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Seek(m) = rt {
            assert_eq!(m.session_id, 99);
            assert_eq!(m.fragment, "t=200:300&lod=N3");
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_data_roundtrip() {
        let block_data = vec![0xDE, 0xAD, 0xBE, 0xEF, 0x42];
        let msg = PpspMessage::Data(DataMsg {
            block_id: 123, lod: 2, frame_start: 100, frame_end: 200,
            data: block_data.clone(),
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Data(m) = rt {
            assert_eq!(m.block_id, 123);
            assert_eq!(m.lod, 2);
            assert_eq!(m.data, block_data);
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_query_roundtrip() {
        let msg = PpspMessage::Query(QueryMsg {
            session_id: 7, select: SelectType::Blocks,
            expression: "activity > 0.1 AND family = bspline".into(),
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Query(m) = rt {
            assert_eq!(m.session_id, 7);
            assert_eq!(m.select, SelectType::Blocks);
            assert!(m.expression.contains("bspline"));
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_result_roundtrip() {
        let msg = PpspMessage::Result(ResultMsg {
            request_id: 42, total_count: 2,
            matches: vec![
                BlockMatch { block_id: 10, bx: 2, by: 3, n_total: 50, family: 2, activity: 0.39 },
                BlockMatch { block_id: 25, bx: 5, by: 1, n_total: 120, family: 3, activity: 0.94 },
            ],
        });
        let rt = roundtrip(msg);
        if let PpspMessage::Result(m) = rt {
            assert_eq!(m.total_count, 2);
            assert_eq!(m.matches.len(), 2);
            assert_eq!(m.matches[0].block_id, 10);
            assert!((m.matches[1].activity - 0.94).abs() < 0.01);
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_close_roundtrip() {
        let msg = PpspMessage::Close(CloseMsg { session_id: 999 });
        let rt = roundtrip(msg);
        if let PpspMessage::Close(m) = rt { assert_eq!(m.session_id, 999); }
        else { panic!("wrong type"); }
    }

    #[test]
    fn test_error_roundtrip() {
        let msg = PpspMessage::Error(ErrorMsg { code: 404, message: "File not found".into() });
        let rt = roundtrip(msg);
        if let PpspMessage::Error(m) = rt {
            assert_eq!(m.code, 404);
            assert_eq!(m.message, "File not found");
        } else { panic!("wrong type"); }
    }

    #[test]
    fn test_invalid_magic() {
        let mut bytes = PpspMessage::Close(CloseMsg { session_id: 1 }).serialize();
        bytes[0] = 0xFF; // corrupt magic
        assert!(PpspMessage::deserialize(&bytes).is_none());
    }

    #[test]
    fn test_truncated() {
        assert!(PpspMessage::deserialize(&[0x50, 0x50, 0x01]).is_none());
    }

    #[test]
    fn test_msg_type() {
        let msg = PpspMessage::Open(OpenMsg { uri: "ppv://x/y".into(), access: AccessLevel::Read });
        assert_eq!(msg.msg_type(), MsgType::Open);
    }
}
