//! # Heuristiques calibrées — Arbres de décision P3bis
//!
//! Traduit les arbres FORGE-SIM P3bis en Rust.
//! Framework tree : 100% accuracy, 2 comparaisons.
//! Family tree : bspline_K6 défaut, 78.9% accuracy.

#![forbid(unsafe_code)]

/// Block descriptors computed from pixel traces.
#[derive(Debug, Clone)]
pub struct BlockDescriptors {
    pub lambda_avg: f64,
    pub var_ratio: f64,
    pub density: f64,
    pub spectral_energy: f64,
    pub spectral_centroid: f64,
    pub peak_ratio: f64,
    pub h_temporal: f64,
    pub mean_n: f64,
}

impl BlockDescriptors {
    pub fn from_traces(traces: &[&[u32]], r: u32) -> Self {
        let n_pixels = traces.len();
        if n_pixels == 0 || r < 2 {
            return Self { lambda_avg: 0.0, var_ratio: 0.0, density: 0.0,
                spectral_energy: 0.0, spectral_centroid: 0.0,
                peak_ratio: 1.0, h_temporal: 0.0, mean_n: 0.0 };
        }
        let mut jump_counts: Vec<u32> = Vec::with_capacity(n_pixels);
        let mut total_jumps = 0u64;
        let mut alpha_profile = vec![0u32; r as usize];

        for trace in traces {
            let mut nj = 0u32;
            for t in 1..r as usize {
                if t < trace.len() && trace[t] != trace[t - 1] {
                    nj += 1;
                    if t < alpha_profile.len() { alpha_profile[t] += 1; }
                }
            }
            jump_counts.push(nj);
            total_jumps += nj as u64;
        }

        let n = n_pixels as f64;
        let mean_n = total_jumps as f64 / n;
        let lambda_avg = mean_n / r as f64;

        let var_n = if n > 1.0 {
            jump_counts.iter().map(|&c| (c as f64 - mean_n).powi(2)).sum::<f64>() / (n - 1.0)
        } else { 0.0 };
        let var_ratio = if mean_n > 0.001 { var_n / mean_n } else { 0.0 };

        let alpha_f: Vec<f64> = alpha_profile.iter().map(|&c| c as f64 / n).collect();

        // Simple DFT for spectral features
        let r_len = alpha_f.len();
        let n_freqs = r_len / 2;
        let mut power = vec![0.0f64; n_freqs.max(1)];
        for k in 1..n_freqs {
            let mut re = 0.0f64;
            let mut im = 0.0f64;
            let omega = 2.0 * std::f64::consts::PI * k as f64 / r_len as f64;
            for (t, &val) in alpha_f.iter().enumerate() {
                re += val * (omega * t as f64).cos();
                im += val * (omega * t as f64).sin();
            }
            power[k] = re * re + im * im;
        }
        let spectral_energy: f64 = power.iter().sum();
        let weighted: f64 = power.iter().enumerate().map(|(k, &p)| k as f64 * p).sum();
        let spectral_centroid = if spectral_energy > 1e-10 { weighted / spectral_energy } else { 0.0 };

        let mean_alpha = alpha_f.iter().sum::<f64>() / r as f64;
        let max_alpha = alpha_f.iter().cloned().fold(0.0f64, f64::max);
        let peak_ratio = if mean_alpha > 1e-10 { max_alpha / mean_alpha } else { 1.0 };

        let total: f64 = alpha_f.iter().sum();
        let h_temporal = if total > 1e-15 {
            alpha_f.iter().filter(|&&v| v > 0.0).map(|&v| { let p = v / total; -p * p.log2() }).sum()
        } else { 0.0 };

        Self { lambda_avg, var_ratio, density: lambda_avg, spectral_energy, spectral_centroid, peak_ratio, h_temporal, mean_n }
    }
}

// ─── Framework Tree (P3bis, 100% accuracy) ──────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Framework { Vector, Marked }

#[inline]
pub fn select_framework(m: u32, desc: &BlockDescriptors) -> Framework {
    if m <= 5 { Framework::Vector }
    else if desc.lambda_avg <= 0.67 { Framework::Marked }
    else { Framework::Vector }
}

// ─── Family Tree (P3bis, 78.9% accuracy) ────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IntensityFamily {
    Constant,
    Histogram { k: u32 },
    BSpline { k: u32 },
    Trigonometric { p: u32 },
    Daubechies { j: u32 },
}

pub fn select_family(r: u32, desc: &BlockDescriptors) -> IntensityFamily {
    if desc.lambda_avg < 0.01 || desc.mean_n < 1.0 {
        return IntensityFamily::Constant;
    }
    if desc.spectral_energy > 50.0 && desc.peak_ratio > 1.8 {
        let p = if desc.spectral_centroid < 3.0 { 1 }
                else if desc.spectral_centroid < 8.0 { 2 }
                else { 4 };
        return IntensityFamily::Trigonometric { p };
    }
    if r <= 32 {
        return IntensityFamily::Daubechies { j: 2 };
    }
    let k = if desc.lambda_avg < 0.3 { 6 }
            else if desc.lambda_avg < 0.6 { 8 }
            else { 10 };
    IntensityFamily::BSpline { k }
}

// ─── Combined Strategy ──────────────────────────────────────

#[derive(Debug, Clone)]
pub struct BlockStrategy {
    pub framework: Framework,
    pub family: IntensityFamily,
    pub descriptors: BlockDescriptors,
}

pub fn compute_block_strategy(traces: &[&[u32]], r: u32, m: u32) -> BlockStrategy {
    let descriptors = BlockDescriptors::from_traces(traces, r);
    let framework = select_framework(m, &descriptors);
    let family = select_family(r, &descriptors);
    BlockStrategy { framework, family, descriptors }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn traces_as_refs(t: &[Vec<u32>]) -> Vec<&[u32]> { t.iter().map(|v| v.as_slice()).collect() }

    #[test]
    fn framework_small_palette_vector() {
        let t: Vec<Vec<u32>> = (0..64).map(|_| vec![0u32; 64]).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 64);
        assert_eq!(select_framework(2, &d), Framework::Vector);
    }

    #[test]
    fn framework_sparse_large_palette_marked() {
        let t: Vec<Vec<u32>> = (0..64).map(|p| {
            let mut v = vec![0u32; 64]; if p % 20 == 0 { v[30] = 1; } v
        }).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 64);
        assert_eq!(select_framework(32, &d), Framework::Marked);
    }

    #[test]
    fn framework_dense_vector() {
        let t: Vec<Vec<u32>> = (0..64).map(|p| (0..64).map(|t| ((p+t*3)%8) as u32).collect()).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 64);
        assert_eq!(select_framework(32, &d), Framework::Vector);
    }

    #[test]
    fn family_static_constant() {
        let t: Vec<Vec<u32>> = (0..64).map(|_| vec![0u32; 128]).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 128);
        assert_eq!(select_family(128, &d), IntensityFamily::Constant);
    }

    #[test]
    fn family_small_r_daubechies() {
        let t: Vec<Vec<u32>> = (0..64).map(|_| { let mut v = vec![0u32; 16]; v[5]=3; v[10]=2; v }).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 16);
        if d.lambda_avg >= 0.01 {
            assert_eq!(select_family(16, &d), IntensityFamily::Daubechies { j: 2 });
        }
    }

    #[test]
    fn family_default_bspline() {
        let t: Vec<Vec<u32>> = (0..64).map(|p| {
            let mut v = vec![0u32; 128];
            for i in (10..30).step_by(3) { v[i] = (p % 4) as u32; }
            v
        }).collect();
        let r = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&r, 128);
        if d.lambda_avg >= 0.01 && d.spectral_energy <= 50.0 {
            match select_family(128, &d) {
                IntensityFamily::BSpline { .. } => {},
                other => panic!("Expected BSpline, got {:?}", other),
            }
        }
    }

    #[test]
    fn strategy_all_configs_no_panic() {
        for (np, r, m) in [(4,4,2),(16,32,4),(64,64,8),(256,128,16),(64,256,32)] {
            let t: Vec<Vec<u32>> = (0..np).map(|p| (0..r).map(|t| ((p*7+t*3)%m) as u32).collect()).collect();
            let refs = traces_as_refs(&t);
            let _ = compute_block_strategy(&refs, r as u32, m as u32);
        }
    }

    #[test]
    fn descriptors_smoke() {
        let t: Vec<Vec<u32>> = (0..64).map(|p| (0..64).map(|t| ((p+t)%4) as u32).collect()).collect();
        let refs = traces_as_refs(&t);
        let d = BlockDescriptors::from_traces(&refs, 64);
        assert!(d.lambda_avg > 0.0);
        assert!(d.mean_n > 0.0);
        assert!(d.spectral_energy >= 0.0);
        assert!(d.peak_ratio >= 1.0);
    }
}
