//! # Encodeur de Bloc — Pipeline PP par pixel
//!
//! Encode la trace temporelle d'un pixel sur r frames :
//! 1. Construire la palette TCC (couleurs uniques)
//! 2. Décomposition monochromatique : pour chaque couleur, lister les positions
//! 3. Sélectionner L₁/L₃/L₄ via Algorithme 1 corrigé
//! 4. Encoder chaque sous-processus dans le bitstream
//! 5. Le décodeur inverse exactement le processus
//!
//! Référence : docB Section 3, uniform_temp_coding.pdf Algorithm 1

#![forbid(unsafe_code)]

use pp_core::bits::{BitWriter, BitReader};
use pp_core::codes::{write_delta, read_delta, write_fixed, read_fixed};
use crate::algorithm1::{EncodingType, Thresholds, select_encoding_with_thresholds};

/// Encoded block — compressed representation of a pixel's temporal trace.
#[derive(Debug, Clone)]
pub struct EncodedBlock {
    pub data: Vec<u8>,
    pub bits_used: usize,
    pub r: u32,
    pub num_colors: u32,
    pub encoding_stats: EncodingStats,
}

#[derive(Debug, Clone, Default)]
pub struct EncodingStats {
    pub l1_count: u32,
    pub l3_count: u32,
    pub l4_count: u32,
    pub total_bits: usize,
}

/// Encode a single pixel's temporal trace.
///
/// `trace` is a sequence of r color values (palette indices after quantization).
/// Each value is in [0, m) where m = palette_size.
///
/// Returns the compressed bitstream.
pub fn encode_pixel_trace(trace: &[u32], m: u32) -> EncodedBlock {
    let r = trace.len() as u32;
    assert!(r >= 2, "need at least 2 frames");
    assert!(m >= 1, "palette must have at least 1 color");

    let mut writer = BitWriter::with_capacity((r as usize * 4) / 8 + 64);
    let mut stats = EncodingStats::default();

    // 1. Build palette: find unique colors and their positions
    let mut color_positions: std::collections::BTreeMap<u32, Vec<u32>> = std::collections::BTreeMap::new();
    for (t, &color) in trace.iter().enumerate() {
        color_positions.entry(color).or_default().push(t as u32);
    }

    let k = color_positions.len() as u32; // number of unique colors
    let palette_bits = if m > 1 { ((m as f64).log2().ceil() as u32).max(1) } else { 0 };

    // 2. Write header: K (number of unique colors), r, m
    write_delta(&mut writer, k as u64);
    write_delta(&mut writer, r as u64);
    write_delta(&mut writer, m as u64);

    // 3. Precompute thresholds for this (r, m) pair
    let thresholds = if m >= 2 { Some(Thresholds::compute(r as u64, m as u64)) } else { None };

    // 4. For each color: write color index + encode positions
    for (&color, positions) in &color_positions {
        let n = positions.len() as u64;

        // Write the color value
        if palette_bits > 0 {
            write_fixed(&mut writer, color as u64, palette_bits);
        }

        // Write N (number of positions for this color)
        write_delta(&mut writer, n.max(1));

        if n == 0 {
            continue;
        }

        // Select encoding
        let enc = if let Some(ref t) = thresholds {
            if n as u64 >= r as u64 {
                EncodingType::L1
            } else {
                select_encoding_with_thresholds(n, t)
            }
        } else {
            EncodingType::L1
        };

        // Write encoding type flag (2 bits: 00=L1, 01=L3, 10=L4)
        match enc {
            EncodingType::L1 => { writer.write_bits(0b00, 2); stats.l1_count += 1; }
            EncodingType::L3 => { writer.write_bits(0b01, 2); stats.l3_count += 1; }
            EncodingType::L4 => { writer.write_bits(0b10, 2); stats.l4_count += 1; }
        }

        // Encode positions based on selected method
        match enc {
            EncodingType::L1 => {
                // L₁: full state encoding — write r bits, 1 where color is present
                for t in 0..r {
                    let bit = if positions.contains(&t) { 1u8 } else { 0u8 };
                    writer.write_bit(bit);
                }
            }
            EncodingType::L3 => {
                // L₃: boolean vector — write r-bit vector + color already written
                for t in 0..r {
                    let bit = if positions.contains(&t) { 1u8 } else { 0u8 };
                    writer.write_bit(bit);
                }
            }
            EncodingType::L4 => {
                // L₄: combinatorial address — write positions directly
                // We use a simple delta encoding of sorted positions
                let r_bits = ((r as f64).log2().ceil() as u32).max(1);
                let mut prev = 0u32;
                for &pos in positions {
                    // Write position as fixed-width (simple but correct)
                    write_fixed(&mut writer, pos as u64, r_bits);
                    prev = pos;
                }
                let _ = prev; // suppress warning
            }
        }
    }

    let bits_used = writer.bit_len();
    stats.total_bits = bits_used;

    EncodedBlock {
        data: writer.finish(),
        bits_used,
        r,
        num_colors: k,
        encoding_stats: stats,
    }
}

/// Decode a pixel's temporal trace from a compressed bitstream.
///
/// Returns the reconstructed trace of r color values.
pub fn decode_pixel_trace(encoded: &EncodedBlock) -> Vec<u32> {
    let mut reader = BitReader::with_bit_len(&encoded.data, encoded.bits_used);

    // 1. Read header
    let k = read_delta(&mut reader) as u32;
    let r = read_delta(&mut reader) as u32;
    let m = read_delta(&mut reader) as u32;

    let palette_bits = if m > 1 { ((m as f64).log2().ceil() as u32).max(1) } else { 0 };

    // Initialize trace with a default value (will be overwritten)
    let mut trace = vec![0u32; r as usize];

    // 2. For each color: read color index + decode positions
    for _ in 0..k {
        // Read color value
        let color = if palette_bits > 0 {
            read_fixed(&mut reader, palette_bits) as u32
        } else {
            0
        };

        // Read N
        let n = read_delta(&mut reader) as u32;
        if n == 0 {
            continue;
        }

        // Read encoding type
        let enc_flag = reader.read_bits(2);

        match enc_flag {
            0b00 | 0b01 => {
                // L₁ or L₃: read r-bit boolean vector
                for t in 0..r {
                    if reader.read_bit() == 1 {
                        trace[t as usize] = color;
                    }
                }
            }
            0b10 => {
                // L₄: read positions
                let r_bits = ((r as f64).log2().ceil() as u32).max(1);
                for _ in 0..n {
                    let pos = read_fixed(&mut reader, r_bits) as u32;
                    if (pos as usize) < trace.len() {
                        trace[pos as usize] = color;
                    }
                }
            }
            _ => {
                // Reserved — treat as L₁
                for t in 0..r {
                    if reader.read_bit() == 1 {
                        trace[t as usize] = color;
                    }
                }
            }
        }
    }

    trace
}

/// Encode an entire frame block (B×B pixels over r frames).
///
/// `frames` is a slice of r frames, each frame is a row-major W×H grid of color indices.
/// `block_x`, `block_y` are the top-left corner of the block.
/// `block_size` is B (width = height of block).
///
/// Returns encoded data for each pixel in the block (row-major).
pub fn encode_block(
    frames: &[Vec<u32>],
    width: u32,
    block_x: u32,
    block_y: u32,
    block_size: u32,
    palette_size: u32,
) -> Vec<EncodedBlock> {
    let _r = frames.len();
    let mut encoded_pixels = Vec::with_capacity((block_size * block_size) as usize);

    for dy in 0..block_size {
        for dx in 0..block_size {
            let x = block_x + dx;
            let y = block_y + dy;
            let pixel_idx = (y * width + x) as usize;

            // Extract temporal trace for this pixel
            let trace: Vec<u32> = frames.iter()
                .map(|frame| {
                    if pixel_idx < frame.len() { frame[pixel_idx] } else { 0 }
                })
                .collect();

            encoded_pixels.push(encode_pixel_trace(&trace, palette_size));
        }
    }

    encoded_pixels
}

/// Decode an entire frame block back to pixel traces.
pub fn decode_block(encoded_pixels: &[EncodedBlock]) -> Vec<Vec<u32>> {
    encoded_pixels.iter().map(|enc| decode_pixel_trace(enc)).collect()
}

// ─── Container Format ───────────────────────────────────────────────

/// Simple .ppv container: header + blocks + seek table.
#[derive(Debug, Clone)]
pub struct PpvFile {
    pub width: u32,
    pub height: u32,
    pub frames: u32,
    pub block_size: u32,
    pub palette_size: u32,
    pub block_data: Vec<Vec<u8>>,   // One byte vector per block
    pub block_bits: Vec<usize>,      // Bit counts per block
}

impl PpvFile {
    /// Magic bytes for .ppv format
    const MAGIC: [u8; 4] = [b'P', b'P', b'V', 0x02];

    /// Serialize to a .ppv file.
    pub fn serialize(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(1024 + self.block_data.iter().map(|b| b.len()).sum::<usize>());

        // Magic
        out.extend_from_slice(&Self::MAGIC);

        // Header (fixed size, 20 bytes)
        out.extend_from_slice(&self.width.to_le_bytes());
        out.extend_from_slice(&self.height.to_le_bytes());
        out.extend_from_slice(&self.frames.to_le_bytes());
        out.extend_from_slice(&self.block_size.to_le_bytes());
        out.extend_from_slice(&self.palette_size.to_le_bytes());

        // Number of blocks
        let num_blocks = self.block_data.len() as u32;
        out.extend_from_slice(&num_blocks.to_le_bytes());

        // Seek table: offset and size for each block
        let mut offset = 4 + 20 + 4 + num_blocks as usize * 12; // header + seek table
        for i in 0..num_blocks as usize {
            out.extend_from_slice(&(offset as u32).to_le_bytes());
            out.extend_from_slice(&(self.block_data[i].len() as u32).to_le_bytes());
            out.extend_from_slice(&(self.block_bits[i] as u32).to_le_bytes());
            offset += self.block_data[i].len();
        }

        // Block data
        for block in &self.block_data {
            out.extend_from_slice(block);
        }

        out
    }

    /// Deserialize from a .ppv file.
    pub fn deserialize(data: &[u8]) -> Option<Self> {
        if data.len() < 28 || &data[0..4] != &Self::MAGIC {
            return None;
        }

        let read_u32 = |offset: usize| -> Option<u32> {
            if offset + 4 > data.len() { return None; }
            Some(u32::from_le_bytes([data[offset], data[offset+1], data[offset+2], data[offset+3]]))
        };

        let width = read_u32(4)?;
        let height = read_u32(8)?;
        let frames = read_u32(12)?;
        let block_size = read_u32(16)?;
        let palette_size = read_u32(20)?;
        let num_blocks = read_u32(24)?;

        let seek_start = 28;
        let seek_end = seek_start + num_blocks as usize * 12;
        if seek_end > data.len() {
            return None; // seek table extends beyond data
        }

        let mut block_data = Vec::with_capacity(num_blocks as usize);
        let mut block_bits = Vec::with_capacity(num_blocks as usize);

        for i in 0..num_blocks as usize {
            let entry_offset = seek_start + i * 12;
            let offset = read_u32(entry_offset)? as usize;
            let size = read_u32(entry_offset + 4)? as usize;
            let bits = read_u32(entry_offset + 8)? as usize;

            if offset + size <= data.len() {
                block_data.push(data[offset..offset + size].to_vec());
                block_bits.push(bits);
            } else {
                return None;
            }
        }

        Some(PpvFile { width, height, frames, block_size, palette_size, block_data, block_bits })
    }
}

// ─── Full Pipeline ──────────────────────────────────────────────────

/// Encode a complete video (frames of palette-indexed pixels) to .ppv format.
///
/// Each frame is a Vec<u32> of length width*height, values in [0, palette_size).
pub fn encode_video(
    frames: &[Vec<u32>],
    width: u32,
    height: u32,
    block_size: u32,
    palette_size: u32,
) -> PpvFile {
    let r = frames.len() as u32;
    let blocks_x = (width + block_size - 1) / block_size;
    let blocks_y = (height + block_size - 1) / block_size;

    let mut block_data = Vec::new();
    let mut block_bits = Vec::new();

    for by in 0..blocks_y {
        for bx in 0..blocks_x {
            let x0 = bx * block_size;
            let y0 = by * block_size;

            // Encode all pixels in this block
            let encoded = encode_block(frames, width, x0, y0, block_size, palette_size);

            // Concatenate all pixel bitstreams into one block bitstream
            let mut block_writer = BitWriter::with_capacity(encoded.len() * 32);
            write_delta(&mut block_writer, encoded.len() as u64);

            for pixel_enc in &encoded {
                // Write pixel data length, then data
                write_delta(&mut block_writer, pixel_enc.bits_used as u64);
                // Copy bits (we write the raw bytes and track bits)
                for &byte in &pixel_enc.data {
                    block_writer.write_bits(byte as u64, 8);
                }
            }

            let bits = block_writer.bit_len();
            block_data.push(block_writer.finish());
            block_bits.push(bits);
        }
    }

    PpvFile { width, height, frames: r, block_size, palette_size, block_data, block_bits }
}

/// Decode a .ppv file back to frames.
pub fn decode_video(ppv: &PpvFile) -> Vec<Vec<u32>> {
    let r = ppv.frames as usize;
    let w = ppv.width as usize;
    let h = ppv.height as usize;
    let bs = ppv.block_size as usize;

    let mut frames: Vec<Vec<u32>> = (0..r).map(|_| vec![0u32; w * h]).collect();

    let blocks_x = (w + bs - 1) / bs;
    let blocks_y = (h + bs - 1) / bs;

    for by in 0..blocks_y {
        for bx in 0..blocks_x {
            let block_idx = by * blocks_x + bx;
            if block_idx >= ppv.block_data.len() { continue; }

            let mut reader = BitReader::with_bit_len(&ppv.block_data[block_idx], ppv.block_bits[block_idx]);
            let num_pixels = read_delta(&mut reader) as usize;

            let x0 = bx * bs;
            let y0 = by * bs;

            for p in 0..num_pixels {
                let dx = p % bs;
                let dy = p / bs;
                let x = x0 + dx;
                let y = y0 + dy;

                if x >= w || y >= h { 
                    // Read and discard this pixel's data
                    let pixel_bits = read_delta(&mut reader) as usize;
                    let pixel_bytes = (pixel_bits + 7) / 8;
                    for _ in 0..pixel_bytes {
                        reader.read_bits(8);
                    }
                    continue; 
                }

                let pixel_bits = read_delta(&mut reader) as usize;
                let pixel_bytes = (pixel_bits + 7) / 8;

                // Read pixel data
                let mut pixel_data = Vec::with_capacity(pixel_bytes);
                for _ in 0..pixel_bytes {
                    pixel_data.push(reader.read_bits(8) as u8);
                }

                let encoded = EncodedBlock {
                    data: pixel_data,
                    bits_used: pixel_bits,
                    r: ppv.frames,
                    num_colors: 0,
                    encoding_stats: EncodingStats::default(),
                };

                let trace = decode_pixel_trace(&encoded);
                let pixel_idx = y * w + x;
                for (t, &color) in trace.iter().enumerate() {
                    if t < r {
                        frames[t][pixel_idx] = color;
                    }
                }
            }
        }
    }

    frames
}

// ─── V2 Pipeline with Heuristic Strategy ─────────────────────────

use crate::heuristics::{compute_block_strategy, Framework};

/// Encode a complete video using the calibrated P3bis heuristics.
///
/// Improvement over `encode_video`:
/// - Computes block descriptors and strategy before encoding
/// - When framework = Vector (dense block), forces L₁ for all sub-processes
///   → skips per-pixel threshold computation (faster)
/// - When framework = Marked (sparse block), uses standard Algorithm 1
/// - Reports per-block strategy choices in `VideoStats`
///
/// The .ppv format is identical — the decoder doesn't need changes.
pub fn encode_video_v2(
    frames: &[Vec<u32>],
    width: u32,
    height: u32,
    block_size: u32,
    palette_size: u32,
) -> (PpvFile, VideoStats) {
    let r = frames.len() as u32;
    let blocks_x = (width + block_size - 1) / block_size;
    let blocks_y = (height + block_size - 1) / block_size;

    let mut block_data = Vec::new();
    let mut block_bits = Vec::new();
    let mut stats = VideoStats::default();

    for by in 0..blocks_y {
        for bx in 0..blocks_x {
            let x0 = bx * block_size;
            let y0 = by * block_size;

            // 1. Extract all pixel traces for this block
            let mut traces: Vec<Vec<u32>> = Vec::with_capacity((block_size * block_size) as usize);
            for dy in 0..block_size {
                for dx in 0..block_size {
                    let x = x0 + dx;
                    let y = y0 + dy;
                    let pixel_idx = (y * width + x) as usize;
                    let trace: Vec<u32> = frames.iter()
                        .map(|frame| if pixel_idx < frame.len() { frame[pixel_idx] } else { 0 })
                        .collect();
                    traces.push(trace);
                }
            }

            // 2. Compute block strategy using P3bis heuristics
            let trace_refs: Vec<&[u32]> = traces.iter().map(|t| t.as_slice()).collect();
            let strategy = compute_block_strategy(&trace_refs, r, palette_size);

            match strategy.framework {
                Framework::Vector => stats.vector_blocks += 1,
                Framework::Marked => stats.marked_blocks += 1,
            }

            // 3. Encode pixels using strategy
            let encoded: Vec<EncodedBlock> = if strategy.framework == Framework::Vector {
                // Vector: force L₁ for dense blocks — skip threshold computation
                traces.iter()
                    .map(|trace| encode_pixel_trace_forced(trace, palette_size, EncodingType::L1))
                    .collect()
            } else {
                // Marked: standard Algorithm 1 selection per pixel
                traces.iter()
                    .map(|trace| encode_pixel_trace(trace, palette_size))
                    .collect()
            };

            // 4. Concatenate pixel bitstreams
            let mut block_writer = BitWriter::with_capacity(encoded.len() * 32);
            write_delta(&mut block_writer, encoded.len() as u64);

            for pixel_enc in &encoded {
                write_delta(&mut block_writer, pixel_enc.bits_used as u64);
                for &byte in &pixel_enc.data {
                    block_writer.write_bits(byte as u64, 8);
                }
                stats.total_l1 += pixel_enc.encoding_stats.l1_count;
                stats.total_l3 += pixel_enc.encoding_stats.l3_count;
                stats.total_l4 += pixel_enc.encoding_stats.l4_count;
            }

            let bits = block_writer.bit_len();
            stats.total_bits += bits;
            block_data.push(block_writer.finish());
            block_bits.push(bits);
        }
    }

    let ppv = PpvFile { width, height, frames: r, block_size, palette_size, block_data, block_bits };
    (ppv, stats)
}

/// Encode a pixel trace with a forced encoding type (used by V2 when framework=Vector).
fn encode_pixel_trace_forced(trace: &[u32], m: u32, forced: EncodingType) -> EncodedBlock {
    let r = trace.len() as u32;
    assert!(r >= 2 && m >= 1);

    let mut writer = BitWriter::with_capacity((r as usize * 4) / 8 + 64);
    let mut stats = EncodingStats::default();

    let mut color_positions: std::collections::BTreeMap<u32, Vec<u32>> = std::collections::BTreeMap::new();
    for (t, &color) in trace.iter().enumerate() {
        color_positions.entry(color).or_default().push(t as u32);
    }

    let k = color_positions.len() as u32;
    let palette_bits = if m > 1 { ((m as f64).log2().ceil() as u32).max(1) } else { 0 };

    write_delta(&mut writer, k as u64);
    write_delta(&mut writer, r as u64);
    write_delta(&mut writer, m as u64);

    for (&color, positions) in &color_positions {
        let n = positions.len() as u64;
        if palette_bits > 0 { write_fixed(&mut writer, color as u64, palette_bits); }
        write_delta(&mut writer, n.max(1));
        if n == 0 { continue; }

        // Use forced encoding (typically L₁ for Vector blocks)
        let enc = if n >= r as u64 { EncodingType::L1 } else { forced };

        match enc {
            EncodingType::L1 => { writer.write_bits(0b00, 2); stats.l1_count += 1; }
            EncodingType::L3 => { writer.write_bits(0b01, 2); stats.l3_count += 1; }
            EncodingType::L4 => { writer.write_bits(0b10, 2); stats.l4_count += 1; }
        }

        match enc {
            EncodingType::L1 | EncodingType::L3 => {
                for t in 0..r {
                    let bit = if positions.contains(&t) { 1u8 } else { 0u8 };
                    writer.write_bit(bit);
                }
            }
            EncodingType::L4 => {
                let r_bits = ((r as f64).log2().ceil() as u32).max(1);
                for &pos in positions { write_fixed(&mut writer, pos as u64, r_bits); }
            }
        }
    }

    let bits_used = writer.bit_len();
    stats.total_bits = bits_used;
    EncodedBlock { data: writer.finish(), bits_used, r, num_colors: k, encoding_stats: stats }
}

/// Per-video encoding statistics from the V2 pipeline.
#[derive(Debug, Clone, Default)]
pub struct VideoStats {
    pub vector_blocks: u32,
    pub marked_blocks: u32,
    pub total_l1: u32,
    pub total_l3: u32,
    pub total_l4: u32,
    pub total_bits: usize,
}

// ─── V3 Pipeline: Parallel Encoding ─────────────────────────────

use rayon::prelude::*;

/// A block's coordinates and extracted traces, ready for parallel encoding.
struct BlockJob {
    bx: u32,
    by: u32,
    traces: Vec<Vec<u32>>,
}

/// Result of encoding a single block.
struct BlockResult {
    data: Vec<u8>,
    bits: usize,
    stats: VideoStats,
}

/// Encode a single block (called from parallel context).
fn encode_block_job(job: &BlockJob, r: u32, m: u32) -> BlockResult {
    let trace_refs: Vec<&[u32]> = job.traces.iter().map(|t| t.as_slice()).collect();
    let strategy = compute_block_strategy(&trace_refs, r, m);

    let mut block_stats = VideoStats::default();
    match strategy.framework {
        Framework::Vector => block_stats.vector_blocks = 1,
        Framework::Marked => block_stats.marked_blocks = 1,
    }

    let encoded: Vec<EncodedBlock> = if strategy.framework == Framework::Vector {
        job.traces.iter()
            .map(|trace| encode_pixel_trace_forced(trace, m, EncodingType::L1))
            .collect()
    } else {
        job.traces.iter()
            .map(|trace| encode_pixel_trace(trace, m))
            .collect()
    };

    let mut block_writer = BitWriter::with_capacity(encoded.len() * 32);
    write_delta(&mut block_writer, encoded.len() as u64);

    for pixel_enc in &encoded {
        write_delta(&mut block_writer, pixel_enc.bits_used as u64);
        for &byte in &pixel_enc.data {
            block_writer.write_bits(byte as u64, 8);
        }
        block_stats.total_l1 += pixel_enc.encoding_stats.l1_count;
        block_stats.total_l3 += pixel_enc.encoding_stats.l3_count;
        block_stats.total_l4 += pixel_enc.encoding_stats.l4_count;
    }

    let bits = block_writer.bit_len();
    block_stats.total_bits = bits;

    BlockResult { data: block_writer.finish(), bits, stats: block_stats }
}

/// Encode a complete video using parallel block processing (V3).
///
/// Each block is encoded independently on a separate Rayon thread.
/// The .ppv format is identical — the decoder doesn't need changes.
///
/// Speedup: ≈ N_cores × on multi-core systems.
pub fn encode_video_parallel(
    frames: &[Vec<u32>],
    width: u32,
    height: u32,
    block_size: u32,
    palette_size: u32,
) -> (PpvFile, VideoStats) {
    let r = frames.len() as u32;
    let blocks_x = (width + block_size - 1) / block_size;
    let blocks_y = (height + block_size - 1) / block_size;

    // 1. Extract all block traces (sequential — memory-bound)
    let mut jobs: Vec<BlockJob> = Vec::with_capacity((blocks_x * blocks_y) as usize);

    for by in 0..blocks_y {
        for bx in 0..blocks_x {
            let x0 = bx * block_size;
            let y0 = by * block_size;

            let mut traces = Vec::with_capacity((block_size * block_size) as usize);
            for dy in 0..block_size {
                for dx in 0..block_size {
                    let x = x0 + dx;
                    let y = y0 + dy;
                    let idx = (y * width + x) as usize;
                    let trace: Vec<u32> = frames.iter()
                        .map(|f| if idx < f.len() { f[idx] } else { 0 })
                        .collect();
                    traces.push(trace);
                }
            }
            jobs.push(BlockJob { bx, by, traces });
        }
    }

    // 2. Encode all blocks in parallel (CPU-bound — this is where Rayon shines)
    let results: Vec<BlockResult> = jobs.par_iter()
        .map(|job| encode_block_job(job, r, palette_size))
        .collect();

    // 3. Assemble PpvFile (sequential — fast)
    let mut block_data = Vec::with_capacity(results.len());
    let mut block_bits = Vec::with_capacity(results.len());
    let mut total_stats = VideoStats::default();

    for result in &results {
        block_data.push(result.data.clone());
        block_bits.push(result.bits);
        total_stats.vector_blocks += result.stats.vector_blocks;
        total_stats.marked_blocks += result.stats.marked_blocks;
        total_stats.total_l1 += result.stats.total_l1;
        total_stats.total_l3 += result.stats.total_l3;
        total_stats.total_l4 += result.stats.total_l4;
        total_stats.total_bits += result.stats.total_bits;
    }

    let ppv = PpvFile { width, height, frames: r, block_size, palette_size, block_data, block_bits };
    (ppv, total_stats)
}

// ─── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pixel_trace_roundtrip_static() {
        // All-same pixel (static): should compress very well
        let trace = vec![5u32; 64]; // r=64, all color 5
        let encoded = encode_pixel_trace(&trace, 8);
        let decoded = decode_pixel_trace(&encoded);
        assert_eq!(trace, decoded, "static pixel roundtrip failed");
        eprintln!("Static pixel: {} frames → {} bits ({:.1}× compression)",
            trace.len(), encoded.bits_used,
            (trace.len() as f64 * 3.0) / (encoded.bits_used as f64).max(1.0));
    }

    #[test]
    fn pixel_trace_roundtrip_sparse() {
        // Mostly static with 2 changes
        let mut trace = vec![0u32; 100]; // r=100
        trace[30] = 3;
        trace[31] = 3;
        trace[70] = 7;
        let encoded = encode_pixel_trace(&trace, 8);
        let decoded = decode_pixel_trace(&encoded);
        assert_eq!(trace, decoded, "sparse pixel roundtrip failed");
        eprintln!("Sparse pixel: {} frames → {} bits", trace.len(), encoded.bits_used);
    }

    #[test]
    fn pixel_trace_roundtrip_dense() {
        // Alternating colors
        let trace: Vec<u32> = (0..64).map(|t| (t % 4) as u32).collect();
        let encoded = encode_pixel_trace(&trace, 4);
        let decoded = decode_pixel_trace(&encoded);
        assert_eq!(trace, decoded, "dense pixel roundtrip failed");
    }

    #[test]
    fn pixel_trace_roundtrip_two_colors() {
        let trace: Vec<u32> = (0..32).map(|t| if t < 20 { 0 } else { 1 }).collect();
        let encoded = encode_pixel_trace(&trace, 2);
        let decoded = decode_pixel_trace(&encoded);
        assert_eq!(trace, decoded, "two-color roundtrip failed");
    }

    #[test]
    fn pixel_trace_single_frame() {
        let trace = vec![42u32; 2]; // minimum r=2
        let encoded = encode_pixel_trace(&trace, 256);
        let decoded = decode_pixel_trace(&encoded);
        assert_eq!(trace, decoded);
    }

    #[test]
    fn block_encode_decode_roundtrip() {
        let width = 4u32;
        let height = 4u32;
        let r = 16; // 16 frames
        let palette = 4;

        // Generate synthetic frames
        let frames: Vec<Vec<u32>> = (0..r).map(|t| {
            (0..width * height).map(|p| ((p + t as u32) % palette) as u32).collect()
        }).collect();

        let encoded = encode_block(&frames, width, 0, 0, 4, palette);
        let decoded = decode_block(&encoded);

        // Verify each pixel
        for (p, pixel_decoded) in decoded.iter().enumerate() {
            let x = p as u32 % width;
            let y = p as u32 / width;
            for t in 0..r {
                let expected = frames[t][(y * width + x) as usize];
                assert_eq!(pixel_decoded[t], expected,
                    "block roundtrip failed at pixel ({},{}) frame {}", x, y, t);
            }
        }
    }

    #[test]
    fn full_pipeline_roundtrip_tiny() {
        let w = 8u32;
        let h = 8u32;
        let r = 16;
        let m = 4u32;
        let bs = 4u32;

        // Generate test frames
        let frames: Vec<Vec<u32>> = (0..r).map(|t| {
            (0..(w * h)).map(|p| ((p + t as u32 * 3) % m)).collect()
        }).collect();

        // Encode
        let ppv = encode_video(&frames, w, h, bs, m);

        // Serialize → deserialize
        let bytes = ppv.serialize();
        let ppv2 = PpvFile::deserialize(&bytes).expect("deserialize failed");

        // Decode
        let decoded = decode_video(&ppv2);

        // Verify
        assert_eq!(decoded.len(), r as usize);
        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t],
                "pipeline roundtrip failed at frame {}", t);
        }

        let ratio = (w * h * r as u32 * 2) as f64 / bytes.len() as f64;
        eprintln!("Pipeline roundtrip: {}×{} × {} frames, {} colors → {} bytes ({:.1}:1 ratio)",
            w, h, r, m, bytes.len(), ratio);
    }

    #[test]
    fn full_pipeline_roundtrip_surveillance() {
        // Simulated surveillance: 90% static, 10% activity
        let w = 32u32;
        let h = 24u32;
        let r = 64u32;
        let m = 8u32;
        let bs = 8u32;

        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                // 90% static background (color 0)
                if p % 10 != 0 || t < 20 || t > 40 {
                    0u32
                } else {
                    // Activity burst in frames 20-40 for every 10th pixel
                    ((t * 3 + p) % m as usize) as u32
                }
            }).collect()
        }).collect();

        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();
        let ppv2 = PpvFile::deserialize(&bytes).expect("deserialize failed");
        let decoded = decode_video(&ppv2);

        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t],
                "surveillance roundtrip failed at frame {}", t);
        }

        let raw_size = (w * h * r * 3) as f64; // ~3 bits per pixel naive
        let ratio = raw_size / bytes.len() as f64;
        eprintln!("Surveillance: {}×{} × {} frames → {} bytes ({:.1}:1)",
            w, h, r, bytes.len(), ratio);
    }

    #[test]
    fn container_serialize_deserialize() {
        let ppv = PpvFile {
            width: 16, height: 16, frames: 8,
            block_size: 8, palette_size: 4,
            block_data: vec![vec![0xAA, 0xBB], vec![0xCC, 0xDD]],
            block_bits: vec![16, 16],
        };

        let bytes = ppv.serialize();
        assert_eq!(&bytes[0..4], &PpvFile::MAGIC);

        let ppv2 = PpvFile::deserialize(&bytes).expect("deserialize failed");
        assert_eq!(ppv2.width, 16);
        assert_eq!(ppv2.height, 16);
        assert_eq!(ppv2.frames, 8);
        assert_eq!(ppv2.block_data.len(), 2);
        assert_eq!(ppv2.block_data[0], vec![0xAA, 0xBB]);
    }

    #[test]
    fn ppv_file_magic_check() {
        assert!(PpvFile::deserialize(&[0, 0, 0, 0]).is_none());
        assert!(PpvFile::deserialize(&[]).is_none());
    }

    // ─── V2 Pipeline Tests ───

    #[test]
    fn v2_roundtrip_matches_original() {
        let w = 16u32; let h = 16; let r = 32; let m = 8; let bs = 8;
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                if p % 10 != 0 || t < 8 || t > 24 { 0u32 }
                else { ((t * 3 + p) % m as usize) as u32 }
            }).collect()
        }).collect();

        // V2 encode
        let (ppv, stats) = encode_video_v2(&frames, w, h, bs, m);
        let bytes = ppv.serialize();
        let ppv2 = PpvFile::deserialize(&bytes).expect("v2 deserialize failed");

        // Decode (uses same decoder as v1)
        let decoded = decode_video(&ppv2);
        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t], "v2 roundtrip failed at frame {}", t);
        }

        eprintln!("V2 stats: vector={}, marked={}, L1={}, L3={}, L4={}",
            stats.vector_blocks, stats.marked_blocks,
            stats.total_l1, stats.total_l3, stats.total_l4);
    }

    #[test]
    fn v2_dense_uses_vector_framework() {
        let w = 16u32; let h = 16; let r = 32; let m = 8; let bs = 8;
        // Dense: every pixel changes every frame
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w*h) as usize).map(|p| ((p + t*3) % m as usize) as u32).collect()
        }).collect();

        let (_, stats) = encode_video_v2(&frames, w, h, bs, m);
        assert!(stats.vector_blocks > 0, "dense blocks should use Vector framework");
    }

    #[test]
    fn v2_sparse_uses_marked_framework() {
        let w = 16u32; let h = 16; let r = 64; let m = 32; let bs = 8;
        // Very sparse: < 1% activity
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w*h) as usize).map(|p| {
                if p == 50 && t == 30 { 1u32 } else { 0u32 }
            }).collect()
        }).collect();

        let (ppv, stats) = encode_video_v2(&frames, w, h, bs, m);
        assert!(stats.marked_blocks > 0, "sparse blocks should use Marked framework");

        // Still lossless
        let bytes = ppv.serialize();
        let decoded = decode_video(&PpvFile::deserialize(&bytes).unwrap());
        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t], "v2 sparse roundtrip failed at frame {}", t);
        }
    }

    // ─── V3 Parallel Pipeline Tests ───

    #[test]
    fn v3_parallel_roundtrip() {
        let w = 32u32; let h = 32; let r = 64; let m = 8; let bs = 8;
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                let hash = ((p * 2654435761) ^ (t * 2246822519)) & 0xFFFF;
                if (hash % 20) == 0 && t > 16 && t < 48 { (hash % 7 + 1) as u32 } else { 0 }
            }).collect()
        }).collect();

        let (ppv, stats) = encode_video_parallel(&frames, w, h, bs, m);
        let bytes = ppv.serialize();
        let decoded = decode_video(&PpvFile::deserialize(&bytes).unwrap());
        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t], "v3 parallel roundtrip failed at frame {}", t);
        }
        eprintln!("V3 parallel: vector={}, marked={}, bits={}",
            stats.vector_blocks, stats.marked_blocks, stats.total_bits);
    }

    #[test]
    fn v3_matches_v2_output() {
        let w = 16u32; let h = 16; let r = 32; let m = 8; let bs = 8;
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                if p % 10 != 0 || t < 8 || t > 24 { 0u32 }
                else { ((t * 3 + p) % m as usize) as u32 }
            }).collect()
        }).collect();

        let (_, stats_v2) = encode_video_v2(&frames, w, h, bs, m);
        let (_, stats_v3) = encode_video_parallel(&frames, w, h, bs, m);

        assert_eq!(stats_v2.vector_blocks, stats_v3.vector_blocks);
        assert_eq!(stats_v2.marked_blocks, stats_v3.marked_blocks);
        assert_eq!(stats_v2.total_bits, stats_v3.total_bits, "V2 and V3 must produce identical bitstreams");
    }

    #[test]
    fn v3_large_throughput() {
        let w = 64u32; let h = 64; let r = 128; let m = 16; let bs = 8;
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                let hash = ((p * 2654435761) ^ (t * 2246822519)) & 0xFFFF;
                if (hash % 25) == 0 && t >= 32 && t <= 96 { (hash % 15 + 1) as u32 } else { 0 }
            }).collect()
        }).collect();

        let t0 = std::time::Instant::now();
        let (ppv, _) = encode_video_parallel(&frames, w, h, bs, m);
        let par_time = t0.elapsed();

        let t1 = std::time::Instant::now();
        let (ppv2, _) = encode_video_v2(&frames, w, h, bs, m);
        let seq_time = t1.elapsed();

        // Verify lossless
        let bytes = ppv.serialize();
        let decoded = decode_video(&PpvFile::deserialize(&bytes).unwrap());
        for t in 0..r as usize {
            assert_eq!(frames[t], decoded[t], "v3 large roundtrip failed");
        }

        let pixels = w as u64 * h as u64 * r as u64;
        let par_mpxs = pixels as f64 / par_time.as_secs_f64() / 1e6;
        let seq_mpxs = pixels as f64 / seq_time.as_secs_f64() / 1e6;
        let speedup = seq_time.as_secs_f64() / par_time.as_secs_f64();

        eprintln!("V3 parallel 64×64×128: {:.1} ms ({:.1} MPx/s) vs V2 seq: {:.1} ms ({:.1} MPx/s) → speedup {:.2}×",
            par_time.as_secs_f64() * 1000.0, par_mpxs,
            seq_time.as_secs_f64() * 1000.0, seq_mpxs, speedup);
    }
}
