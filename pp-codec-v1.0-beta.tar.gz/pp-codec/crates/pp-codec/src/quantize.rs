//! # Quantificateur RGB → Palette
//!
//! Convertit des frames RGB (3 octets/pixel) en frames à palette indexée
//! (1 entier/pixel) exploitables par le codec PP.
//!
//! Algorithme : Median Cut (Heckbert 1982) — O(n·log(m)) où n = pixels, m = palette.
//! Ref : planDEV S01-S02, modMOT T1 (extraction traces)
//!
//! ## Usage
//! ```ignore
//! let rgb_frames: Vec<Vec<u8>> = load_rgb_video();
//! let (palette, indexed_frames) = quantize_rgb(&rgb_frames, w, h, 8);
//! let ppv = encode_video(&indexed_frames, w, h, 16, palette.len() as u32);
//! ```

#![forbid(unsafe_code)]

use std::collections::BTreeMap;

/// A color in RGB space (8 bits per channel).
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Rgb {
    pub r: u8,
    pub g: u8,
    pub b: u8,
}

impl Rgb {
    pub fn new(r: u8, g: u8, b: u8) -> Self {
        Rgb { r, g, b }
    }

    /// Squared Euclidean distance in RGB space.
    pub fn distance_sq(&self, other: &Rgb) -> u32 {
        let dr = (self.r as i32) - (other.r as i32);
        let dg = (self.g as i32) - (other.g as i32);
        let db = (self.b as i32) - (other.b as i32);
        (dr * dr + dg * dg + db * db) as u32
    }
}

/// A palette of up to m colors.
#[derive(Debug, Clone)]
pub struct Palette {
    pub colors: Vec<Rgb>,
    lookup: BTreeMap<Rgb, u32>, // exact match cache
}

impl Palette {
    /// Find the nearest palette index for a given RGB color.
    /// Uses exact match first, then brute-force nearest in RGB space.
    pub fn nearest(&self, color: &Rgb) -> u32 {
        // Exact match (common for low-color content like surveillance)
        if let Some(&idx) = self.lookup.get(color) {
            return idx;
        }
        // Brute-force nearest (O(m), m ≤ 256 typical)
        let mut best_idx = 0u32;
        let mut best_dist = u32::MAX;
        for (i, pc) in self.colors.iter().enumerate() {
            let d = color.distance_sq(pc);
            if d < best_dist {
                best_dist = d;
                best_idx = i as u32;
            }
        }
        best_idx
    }

    /// Number of colors in the palette.
    pub fn len(&self) -> usize {
        self.colors.len()
    }

    pub fn is_empty(&self) -> bool {
        self.colors.is_empty()
    }
}

/// A box in RGB space used by median cut.
#[derive(Debug)]
struct ColorBox {
    pixels: Vec<Rgb>,
}

impl ColorBox {
    fn new(pixels: Vec<Rgb>) -> Self {
        ColorBox { pixels }
    }

    /// Range of each channel.
    fn ranges(&self) -> (u32, u32, u32) {
        let (mut rmin, mut rmax) = (255u8, 0u8);
        let (mut gmin, mut gmax) = (255u8, 0u8);
        let (mut bmin, mut bmax) = (255u8, 0u8);
        for p in &self.pixels {
            rmin = rmin.min(p.r); rmax = rmax.max(p.r);
            gmin = gmin.min(p.g); gmax = gmax.max(p.g);
            bmin = bmin.min(p.b); bmax = bmax.max(p.b);
        }
        ((rmax - rmin) as u32, (gmax - gmin) as u32, (bmax - bmin) as u32)
    }

    /// Split along the widest axis at the median.
    fn split(mut self) -> (ColorBox, ColorBox) {
        let (rr, gr, br) = self.ranges();
        // Sort along widest axis
        if rr >= gr && rr >= br {
            self.pixels.sort_by_key(|p| p.r);
        } else if gr >= br {
            self.pixels.sort_by_key(|p| p.g);
        } else {
            self.pixels.sort_by_key(|p| p.b);
        }
        let mid = self.pixels.len() / 2;
        let right = self.pixels.split_off(mid);
        (ColorBox::new(self.pixels), ColorBox::new(right))
    }

    /// Average color of all pixels in this box.
    fn average(&self) -> Rgb {
        if self.pixels.is_empty() {
            return Rgb::new(0, 0, 0);
        }
        let n = self.pixels.len() as u64;
        let (mut sr, mut sg, mut sb) = (0u64, 0u64, 0u64);
        for p in &self.pixels {
            sr += p.r as u64;
            sg += p.g as u64;
            sb += p.b as u64;
        }
        Rgb::new((sr / n) as u8, (sg / n) as u8, (sb / n) as u8)
    }

    fn volume(&self) -> u32 {
        let (rr, gr, br) = self.ranges();
        (rr + 1) * (gr + 1) * (br + 1)
    }
}

/// Median-cut quantization: reduce RGB colors to a palette of m colors.
///
/// Returns the palette and a lookup table for fast nearest-color queries.
///
/// ## Arguments
/// * `pixels` — all unique RGB colors from the video (deduplicated)
/// * `target_m` — desired palette size (2..=65536)
pub fn median_cut(unique_colors: &[Rgb], target_m: usize) -> Palette {
    let m = target_m.max(1).min(65536);

    if unique_colors.len() <= m {
        // Fewer unique colors than target → use them all
        let colors: Vec<Rgb> = unique_colors.to_vec();
        let lookup: BTreeMap<Rgb, u32> = colors.iter().enumerate()
            .map(|(i, &c)| (c, i as u32)).collect();
        return Palette { colors, lookup };
    }

    // Start with one box containing all colors
    let mut boxes: Vec<ColorBox> = vec![ColorBox::new(unique_colors.to_vec())];

    // Split the largest box until we have m boxes
    while boxes.len() < m {
        // Find the box with the largest volume (widest color spread)
        let mut best_idx = 0;
        let mut best_vol = 0;
        for (i, b) in boxes.iter().enumerate() {
            if b.pixels.len() >= 2 {
                let v = b.volume();
                if v > best_vol {
                    best_vol = v;
                    best_idx = i;
                }
            }
        }
        if best_vol == 0 {
            break; // all boxes have 1 pixel
        }
        let biggest = boxes.remove(best_idx);
        let (left, right) = biggest.split();
        if !left.pixels.is_empty() { boxes.push(left); }
        if !right.pixels.is_empty() { boxes.push(right); }
    }

    // Average color per box = palette entry
    let colors: Vec<Rgb> = boxes.iter().map(|b| b.average()).collect();
    let mut lookup = BTreeMap::new();
    // Build lookup for exact matches from original pixels
    for b in &boxes {
        let avg = b.average();
        let idx = colors.iter().position(|c| *c == avg).unwrap_or(0) as u32;
        for p in &b.pixels {
            lookup.insert(*p, idx);
        }
    }

    Palette { colors, lookup }
}

/// Extract all unique RGB colors from a set of frames.
///
/// ## Arguments
/// * `rgb_frames` — r frames, each frame = w*h*3 bytes (R, G, B, R, G, B, ...)
/// * `max_sample` — if > 0, sample at most this many pixels (for performance on large videos)
pub fn extract_unique_colors(rgb_frames: &[Vec<u8>], max_sample: usize) -> Vec<Rgb> {
    let mut unique: BTreeMap<Rgb, ()> = BTreeMap::new();
    let mut count = 0usize;
    let total_pixels: usize = rgb_frames.iter().map(|f| f.len() / 3).sum();
    let step = if max_sample > 0 && total_pixels > max_sample {
        total_pixels / max_sample
    } else {
        1
    };

    let mut global_idx = 0usize;
    for frame in rgb_frames {
        let npx = frame.len() / 3;
        for p in 0..npx {
            if global_idx % step == 0 {
                let r = frame[p * 3];
                let g = frame[p * 3 + 1];
                let b = frame[p * 3 + 2];
                unique.insert(Rgb::new(r, g, b), ());
                count += 1;
            }
            global_idx += 1;
        }
    }
    unique.keys().copied().collect()
}

/// Quantize RGB video frames to palette-indexed frames.
///
/// This is the main entry point: takes RGB frames and produces indexed frames
/// ready for `encode_video`.
///
/// ## Arguments
/// * `rgb_frames` — r frames, each w*h*3 bytes (R,G,B,R,G,B,...)
/// * `width` — frame width in pixels
/// * `height` — frame height in pixels
/// * `target_m` — desired palette size (e.g. 8, 16, 256)
///
/// ## Returns
/// * `(Palette, Vec<Vec<u32>>)` — the palette and indexed frames ready for PP encoding
pub fn quantize_rgb(
    rgb_frames: &[Vec<u8>],
    width: u32,
    height: u32,
    target_m: usize,
) -> (Palette, Vec<Vec<u32>>) {
    let npx = (width * height) as usize;

    // 1. Extract unique colors (sample up to 500K for speed)
    let unique = extract_unique_colors(rgb_frames, 500_000);

    // 2. Build palette via median cut
    let palette = median_cut(&unique, target_m);

    // 3. Map each pixel in each frame to its nearest palette index
    let indexed: Vec<Vec<u32>> = rgb_frames.iter().map(|frame| {
        assert!(frame.len() >= npx * 3, "frame too short");
        (0..npx).map(|p| {
            let color = Rgb::new(frame[p*3], frame[p*3+1], frame[p*3+2]);
            palette.nearest(&color)
        }).collect()
    }).collect();

    (palette, indexed)
}

/// Reconstruct RGB frames from palette-indexed frames.
///
/// Inverse of `quantize_rgb` (lossy: only the palette colors are preserved).
pub fn dequantize_rgb(
    indexed_frames: &[Vec<u32>],
    palette: &Palette,
    width: u32,
    height: u32,
) -> Vec<Vec<u8>> {
    let npx = (width * height) as usize;
    indexed_frames.iter().map(|frame| {
        let mut rgb = Vec::with_capacity(npx * 3);
        for &idx in frame.iter().take(npx) {
            let c = palette.colors.get(idx as usize).copied()
                .unwrap_or(Rgb::new(0, 0, 0));
            rgb.push(c.r);
            rgb.push(c.g);
            rgb.push(c.b);
        }
        rgb
    }).collect()
}

/// Compute PSNR between original RGB frames and reconstructed RGB frames.
///
/// Returns PSNR in dB. For lossless (identical frames), returns f64::INFINITY.
pub fn compute_psnr(original: &[Vec<u8>], reconstructed: &[Vec<u8>]) -> f64 {
    let mut mse_sum = 0.0f64;
    let mut count = 0u64;
    for (orig, recon) in original.iter().zip(reconstructed.iter()) {
        for (&o, &r) in orig.iter().zip(recon.iter()) {
            let diff = (o as f64) - (r as f64);
            mse_sum += diff * diff;
            count += 1;
        }
    }
    if count == 0 { return f64::INFINITY; }
    let mse = mse_sum / (count as f64);
    if mse < 1e-10 { return f64::INFINITY; }
    10.0 * (255.0_f64 * 255.0 / mse).log10()
}

// ═══════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rgb_distance() {
        let a = Rgb::new(0, 0, 0);
        let b = Rgb::new(255, 255, 255);
        assert_eq!(a.distance_sq(&b), 255*255*3);
        assert_eq!(a.distance_sq(&a), 0);
    }

    #[test]
    fn test_median_cut_exact() {
        // 4 colors → palette of 4 = exact
        let colors = vec![
            Rgb::new(0,0,0), Rgb::new(255,0,0),
            Rgb::new(0,255,0), Rgb::new(0,0,255),
        ];
        let palette = median_cut(&colors, 4);
        assert_eq!(palette.len(), 4);
    }

    #[test]
    fn test_median_cut_reduce() {
        // Many colors → palette of 8
        let mut colors = Vec::new();
        for r in (0..=255).step_by(16) {
            for g in (0..=255).step_by(64) {
                colors.push(Rgb::new(r as u8, g as u8, 128));
            }
        }
        let palette = median_cut(&colors, 8);
        assert_eq!(palette.len(), 8);
    }

    #[test]
    fn test_quantize_roundtrip() {
        let w = 4u32;
        let h = 4u32;
        // 3 frames of 4x4 pixels, mostly black with some red
        let frame1 = vec![0u8; 48]; // all black
        let mut frame2 = vec![0u8; 48];
        frame2[0] = 255; // pixel (0,0) = red
        let frame3 = vec![0u8; 48];
        let rgb_frames = vec![frame1, frame2, frame3];

        let (palette, indexed) = quantize_rgb(&rgb_frames, w, h, 8);
        assert!(palette.len() <= 8);
        assert_eq!(indexed.len(), 3);
        assert_eq!(indexed[0].len(), 16); // 4*4 pixels

        // Dequantize and check PSNR
        let recon = dequantize_rgb(&indexed, &palette, w, h);
        let psnr = compute_psnr(&rgb_frames, &recon);
        assert!(psnr > 30.0 || psnr == f64::INFINITY);
    }

    #[test]
    fn test_quantize_single_color() {
        let w = 2u32; let h = 2u32;
        let frame = vec![128u8; 12]; // all gray
        let (palette, indexed) = quantize_rgb(&[frame.clone()], w, h, 4);
        // Single color → palette of 1, all indices = 0
        assert_eq!(palette.len(), 1);
        assert!(indexed[0].iter().all(|&v| v == 0));
    }

    #[test]
    fn test_psnr_identical() {
        let a = vec![vec![100u8; 30]];
        assert_eq!(compute_psnr(&a, &a), f64::INFINITY);
    }

    #[test]
    fn test_psnr_different() {
        let a = vec![vec![100u8; 30]];
        let b = vec![vec![110u8; 30]];
        let psnr = compute_psnr(&a, &b);
        assert!(psnr > 20.0 && psnr < 40.0);
    }

    #[test]
    fn test_extract_unique_colors() {
        let frame = vec![
            255, 0, 0,  0, 255, 0,  0, 0, 255,  255, 0, 0,
        ];
        let unique = extract_unique_colors(&[frame], 0);
        assert_eq!(unique.len(), 3); // red, green, blue
    }

    #[test]
    fn test_full_pipeline_rgb_to_ppv() {
        // End-to-end: RGB → quantize → encode → decode → dequantize → PSNR
        let w = 8u32; let h = 8u32; let r = 16;
        let mut rgb_frames = Vec::new();
        for t in 0..r {
            let mut frame = vec![0u8; (w * h * 3) as usize];
            // One pixel changes color each frame
            let idx = (t % (w * h) as usize) * 3;
            frame[idx] = ((t * 37) % 256) as u8;
            frame[idx + 1] = ((t * 73) % 256) as u8;
            frame[idx + 2] = ((t * 113) % 256) as u8;
            rgb_frames.push(frame);
        }

        let (palette, indexed) = quantize_rgb(&rgb_frames, w, h, 16);
        let m = palette.len() as u32;

        // Now encode with PP-CODEC
        // (would call encode_video here in the real pipeline)
        // Verify indexed frames are valid
        for frame in &indexed {
            assert_eq!(frame.len(), (w * h) as usize);
            for &idx in frame {
                assert!(idx < m);
            }
        }
    }
}
