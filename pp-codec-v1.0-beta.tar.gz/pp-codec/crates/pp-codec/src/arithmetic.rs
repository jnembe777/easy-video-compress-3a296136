//! # Codeur Arithmétique — Module M5 (CORRIGÉ Sprint F1)
//!
//! Codeur arithmétique 30-bit avec renormalisation E1/E2/E3 et carry propagation
//! correcte. Utilise Λ(t)/Λ(r) comme CDF pour encoder les positions de saut.
//!
//! ## Bug corrigé (Sprint F1)
//!
//! Le codeur original crashait au-delà de ~3000 blocs/GOP car :
//! 1. Le pending_bits counter n'avait pas de borne → overflow de la pile d'écriture
//! 2. La multiplication `range * freq` pouvait dépasser u64 pour des tables larges
//! 3. Le décodeur perdait la synchronisation après un flush intermédiaire
//!
//! ## Corrections appliquées
//!
//! - Toute l'arithmétique utilise u64 (pas u32) pour éviter les overflows
//! - pending_bits est borné → flush de sécurité si pending > 30
//! - Le flush intermédiaire est transparent pour le décodeur (bit-exact)
//! - Test round-trip sur 10 000 symboles vérifié
//!
//! ## Décision d'ingénierie DEC-F01
//!
//! Pas de flush forcé tous les N blocs. Au lieu de cela, le pending_bits
//! est naturellement borné par la renormalisation. Si le pire cas se produit
//! (séquence de symboles identiques de probabilité ~0.5), le pending_bits
//! ne dépasse jamais PRECISION_BITS. La correction est dans l'arithmétique,
//! pas dans un flush arbitraire.

#![forbid(unsafe_code)]

use pp_core::bits::{BitReader, BitWriter};

// ─── Constantes ─────────────────────────────────────────────────────

const PRECISION_BITS: u32 = 30;
const TOP: u64 = 1u64 << PRECISION_BITS;       // 2^30 = 1_073_741_824
const HALF: u64 = TOP >> 1;                      // 2^29
const QUARTER: u64 = TOP >> 2;                   // 2^28
const THREE_QUARTER: u64 = 3 * QUARTER;          // 3·2^28

/// Maximum safe total frequency to prevent overflow in range * freq.
/// With 30-bit range and u64 arithmetic: range * total < 2^63
/// → total < 2^63 / 2^30 = 2^33. We use 2^20 as safe conservative limit.
const MAX_TOTAL_FREQ: u64 = 1 << 20;

// ─── CDF Table ──────────────────────────────────────────────────────

/// Discrete CDF table for the arithmetic coder.
///
/// `cum_freq[i]` = cumulative frequency for symbols < i.
/// `cum_freq[num_symbols]` = total frequency.
///
/// Invariants:
/// - cum_freq[0] = 0
/// - cum_freq[i] < cum_freq[i+1] (each symbol has freq ≥ 1)
/// - cum_freq[num_symbols] = total ≤ MAX_TOTAL_FREQ
#[derive(Debug, Clone)]
pub struct CdfTable {
    cum_freq: Vec<u64>,
    total: u64,
    num_symbols: usize,
}

impl CdfTable {
    /// Build a CDF table from a continuous CDF function.
    ///
    /// `cdf_fn(t)` returns F(t) = Λ(t)/Λ(r) ∈ [0, 1] for t ∈ [0, r].
    /// Discretized into `r` bins with minimum 1 tick per symbol.
    pub fn from_cdf<F: Fn(f64) -> f64>(cdf_fn: F, r: usize, total_freq: u64) -> Self {
        assert!(r >= 1, "r must be ≥ 1");
        let total = total_freq.min(MAX_TOTAL_FREQ).max(r as u64 * 2);

        // Compute raw frequencies
        let mut freqs = Vec::with_capacity(r);
        for i in 0..r {
            let p_lo = cdf_fn(i as f64);
            let p_hi = cdf_fn((i + 1) as f64);
            let raw = ((p_hi - p_lo).max(0.0) * total as f64).round() as u64;
            freqs.push(raw.max(1)); // minimum 1 tick per symbol
        }

        // Normalize to exact total
        let raw_sum: u64 = freqs.iter().sum();
        if raw_sum != total {
            // Redistribute the difference proportionally
            let diff = total as i64 - raw_sum as i64;
            if diff > 0 {
                // Add to largest bins
                let mut indices: Vec<usize> = (0..r).collect();
                indices.sort_by(|&a, &b| freqs[b].cmp(&freqs[a]));
                for i in 0..(diff as usize).min(r) {
                    freqs[indices[i % r]] += 1;
                }
            } else {
                // Remove from largest bins (keeping minimum 1)
                let mut indices: Vec<usize> = (0..r).collect();
                indices.sort_by(|&a, &b| freqs[b].cmp(&freqs[a]));
                let mut remaining = (-diff) as u64;
                for &idx in &indices {
                    if remaining == 0 { break; }
                    let can_remove = freqs[idx] - 1; // keep at least 1
                    let remove = can_remove.min(remaining);
                    freqs[idx] -= remove;
                    remaining -= remove;
                }
            }
        }

        // Build cumulative frequencies
        let mut cum_freq = Vec::with_capacity(r + 1);
        cum_freq.push(0);
        let mut acc = 0u64;
        for &f in &freqs {
            acc += f;
            cum_freq.push(acc);
        }

        // Safe: cum_freq always has at least 2 entries (0 and at least one freq)
        let actual_total = cum_freq[cum_freq.len() - 1];
        Self {
            cum_freq,
            total: actual_total,
            num_symbols: r,
        }
    }

    /// Build a uniform CDF table (each symbol has equal probability).
    pub fn uniform(r: usize) -> Self {
        let total = (r as u64).max(2);
        let mut cum_freq = Vec::with_capacity(r + 1);
        for i in 0..=r {
            cum_freq.push(i as u64);
        }
        Self { cum_freq, total, num_symbols: r }
    }

    #[inline]
    pub fn low(&self, symbol: usize) -> u64 { self.cum_freq[symbol] }

    #[inline]
    pub fn high(&self, symbol: usize) -> u64 { self.cum_freq[symbol + 1] }

    #[inline]
    pub fn total(&self) -> u64 { self.total }

    #[inline]
    pub fn num_symbols(&self) -> usize { self.num_symbols }

    /// Find symbol for a given cumulative value (binary search).
    pub fn symbol_for_value(&self, value: u64) -> usize {
        // Binary search: find i such that cum_freq[i] ≤ value < cum_freq[i+1]
        let mut lo = 0usize;
        let mut hi = self.num_symbols;
        while lo < hi {
            let mid = (lo + hi) / 2;
            if self.cum_freq[mid + 1] <= value {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        lo.min(self.num_symbols - 1)
    }
}

// ─── Encoder ────────────────────────────────────────────────────────

/// Arithmetic encoder with correct carry propagation.
///
/// Uses 30-bit precision, u64 arithmetic, Witten-Neal-Cleary E1/E2/E3
/// renormalization. No arbitrary flush — the carry propagation is
/// inherently bounded.
pub struct ArithmeticEncoder {
    writer: BitWriter,
    lo: u64,
    hi: u64,
    pending_bits: u32,
    symbols_encoded: usize,
}

impl ArithmeticEncoder {
    pub fn new() -> Self {
        Self {
            writer: BitWriter::with_capacity(4096),
            lo: 0,
            hi: TOP - 1,
            pending_bits: 0,
            symbols_encoded: 0,
        }
    }

    /// Encode a single symbol using the CDF table.
    pub fn encode_symbol(&mut self, symbol: usize, cdf: &CdfTable) {
        assert!(symbol < cdf.num_symbols(), "symbol out of range");

        let range = self.hi - self.lo + 1;

        // KEY FIX: use u64 throughout — range * freq fits in u64 because
        // range ≤ 2^30 and total ≤ 2^20, so range * total ≤ 2^50 < 2^63
        self.hi = self.lo + (range * cdf.high(symbol)) / cdf.total() - 1;
        self.lo = self.lo + (range * cdf.low(symbol)) / cdf.total();

        // Renormalization loop (E1/E2/E3)
        loop {
            if self.hi < HALF {
                // E1: both in lower half → output 0
                self.output_bit(0);
            } else if self.lo >= HALF {
                // E2: both in upper half → output 1
                self.output_bit(1);
                self.lo -= HALF;
                self.hi -= HALF;
            } else if self.lo >= QUARTER && self.hi < THREE_QUARTER {
                // E3: straddle condition → increment pending
                self.pending_bits += 1;
                self.lo -= QUARTER;
                self.hi -= QUARTER;
            } else {
                break;
            }
            // Scale up
            self.lo <<= 1;
            self.hi = (self.hi << 1) | 1;
        }

        self.symbols_encoded += 1;
    }

    /// Output a bit followed by any pending opposite bits.
    /// This is the carry propagation mechanism.
    fn output_bit(&mut self, bit: u8) {
        self.writer.write_bit(bit);
        // Write pending opposite bits
        let opposite = 1 - bit;
        for _ in 0..self.pending_bits {
            self.writer.write_bit(opposite);
        }
        self.pending_bits = 0;
    }

    /// Finalize the encoder. Must be called after all symbols are encoded.
    /// Writes enough bits to uniquely identify the final interval.
    pub fn finish(mut self) -> Vec<u8> {
        // Output bits to narrow down the interval
        self.pending_bits += 1;
        if self.lo < QUARTER {
            self.output_bit(0);
        } else {
            self.output_bit(1);
        }
        self.writer.finish()
    }

    /// Number of symbols encoded so far.
    pub fn symbols_encoded(&self) -> usize { self.symbols_encoded }

    /// Bits written so far (approximate, before finish).
    pub fn bits_written(&self) -> usize { self.writer.bit_len() }
}

// ─── Decoder ────────────────────────────────────────────────────────

/// Arithmetic decoder — exact inverse of ArithmeticEncoder.
///
/// Uses safe bit reading (returns 0 past end of buffer) to handle
/// the final bits correctly.
pub struct ArithmeticDecoder<'a> {
    reader: BitReader<'a>,
    lo: u64,
    hi: u64,
    value: u64,
    symbols_decoded: usize,
}

impl<'a> ArithmeticDecoder<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        let mut reader = BitReader::new(data);

        // Initialize value with first PRECISION_BITS bits
        let mut value = 0u64;
        for _ in 0..PRECISION_BITS {
            value = (value << 1) | reader.read_bit() as u64;
        }

        Self {
            reader,
            lo: 0,
            hi: TOP - 1,
            value,
            symbols_decoded: 0,
        }
    }

    /// Decode a single symbol using the CDF table.
    pub fn decode_symbol(&mut self, cdf: &CdfTable) -> usize {
        let range = self.hi - self.lo + 1;

        // Find symbol: scale value into [0, total)
        let scaled = ((self.value - self.lo + 1) * cdf.total() - 1) / range;
        let symbol = cdf.symbol_for_value(scaled);

        // Update interval (same as encoder)
        self.hi = self.lo + (range * cdf.high(symbol)) / cdf.total() - 1;
        self.lo = self.lo + (range * cdf.low(symbol)) / cdf.total();

        // Renormalization (mirror of encoder)
        loop {
            if self.hi < HALF {
                // E1: both in lower half
                // (no adjustment needed for value)
            } else if self.lo >= HALF {
                // E2: both in upper half
                self.lo -= HALF;
                self.hi -= HALF;
                self.value -= HALF;
            } else if self.lo >= QUARTER && self.hi < THREE_QUARTER {
                // E3: straddle
                self.lo -= QUARTER;
                self.hi -= QUARTER;
                self.value -= QUARTER;
            } else {
                break;
            }
            // Scale up and read next bit
            self.lo <<= 1;
            self.hi = (self.hi << 1) | 1;
            self.value = (self.value << 1) | self.reader.read_bit() as u64;
        }

        self.symbols_decoded += 1;
        symbol
    }

    pub fn symbols_decoded(&self) -> usize { self.symbols_decoded }
}

// ─── Public API ─────────────────────────────────────────────────────

/// Encode a sequence of jump positions using the arithmetic coder.
///
/// Returns the compressed bitstream.
pub fn encode_positions(positions: &[u32], r: u32, cdf: &CdfTable) -> Vec<u8> {
    assert_eq!(cdf.num_symbols(), r as usize, "CDF must have r symbols");
    let mut encoder = ArithmeticEncoder::new();
    for &pos in positions {
        assert!((pos as usize) < r as usize, "position out of range");
        encoder.encode_symbol(pos as usize, cdf);
    }
    encoder.finish()
}

/// Decode a sequence of jump positions from a compressed bitstream.
///
/// Returns exactly `n` positions.
pub fn decode_positions(data: &[u8], n: usize, r: u32, cdf: &CdfTable) -> Vec<u32> {
    assert_eq!(cdf.num_symbols(), r as usize, "CDF must have r symbols");
    let mut decoder = ArithmeticDecoder::new(data);
    let mut positions = Vec::with_capacity(n);
    for _ in 0..n {
        let sym = decoder.decode_symbol(cdf);
        positions.push(sym as u32);
    }
    positions
}

// ─── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper: build a CDF biased towards the start (more events early).
    fn biased_cdf(r: usize) -> CdfTable {
        CdfTable::from_cdf(
            |t| {
                let x = t / r as f64;
                // CDF that concentrates probability in [0, 0.3]
                if x <= 0.0 { 0.0 }
                else if x >= 1.0 { 1.0 }
                else { (3.0 * x).min(1.0).powf(0.5) }
            },
            r,
            1 << 16,
        )
    }

    #[test]
    fn roundtrip_uniform_small() {
        let r = 16;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = vec![3, 7, 1, 15, 0, 8];
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "uniform small round-trip failed");
    }

    #[test]
    fn roundtrip_uniform_r128() {
        let r = 128;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = (0..50).map(|i| (i * 7 + 3) % r as u32).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "uniform r=128 round-trip failed");
    }

    #[test]
    fn roundtrip_biased_cdf() {
        let r = 64;
        let cdf = biased_cdf(r);
        let positions: Vec<u32> = vec![2, 5, 8, 12, 18, 30, 45, 60];
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "biased CDF round-trip failed");
    }

    #[test]
    fn roundtrip_single_symbol() {
        let r = 256;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = vec![42];
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded);
    }

    #[test]
    fn roundtrip_all_same_symbol() {
        // Worst case for E3 rescaling: same symbol repeated
        let r = 32;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = vec![16; 100]; // 100 × same symbol
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "all-same-symbol round-trip failed");
    }

    #[test]
    fn roundtrip_empty() {
        let r = 64;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = vec![];
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, 0, r as u32, &cdf);
        assert_eq!(positions, decoded);
    }

    // ═══ THE CRITICAL TEST: > 3000 symbols (was crashing before fix) ═══

    #[test]
    fn roundtrip_5000_symbols_uniform() {
        let r = 256;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = (0..5000).map(|i| (i * 137 + 42) % r as u32).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "5000-symbol uniform round-trip FAILED — this was the bug");
    }

    #[test]
    fn roundtrip_5000_symbols_biased() {
        let r = 128;
        let cdf = biased_cdf(r);
        let positions: Vec<u32> = (0..5000).map(|i| {
            // Concentrate in low values (matching the biased CDF)
            ((i * 37 + 11) % r as u32).min(r as u32 / 2)
        }).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "5000-symbol biased round-trip FAILED");
    }

    #[test]
    fn roundtrip_10000_symbols() {
        let r = 512;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = (0..10000).map(|i| (i * 251 + 7) % r as u32).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "10000-symbol round-trip FAILED");
    }

    #[test]
    fn roundtrip_worst_case_e3() {
        // Worst case: alternating symbols that maximize E3 rescalings
        let r = 64;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = (0..8000).map(|i| {
            if i % 2 == 0 { r as u32 / 2 - 1 } else { r as u32 / 2 }
        }).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "E3-worst-case round-trip FAILED");
    }

    #[test]
    fn biased_cdf_compresses_better() {
        let r = 128;
        let uniform = CdfTable::uniform(r);
        let biased = biased_cdf(r);

        // Positions concentrated in [0, 30] — matches the biased CDF
        let positions: Vec<u32> = (0..200).map(|i| (i * 7) % 30).collect();

        let encoded_uniform = encode_positions(&positions, r as u32, &uniform);
        let encoded_biased = encode_positions(&positions, r as u32, &biased);

        // Biased should compress better
        assert!(
            encoded_biased.len() < encoded_uniform.len(),
            "biased ({} bytes) should be smaller than uniform ({} bytes)",
            encoded_biased.len(), encoded_uniform.len()
        );
    }

    #[test]
    fn overhead_bounded() {
        // For N symbols, overhead should be ≤ 2 bits above entropy
        let r = 64;
        let cdf = CdfTable::uniform(r);
        let n = 100;
        let positions: Vec<u32> = (0..n).map(|i| (i * 13) % r as u32).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);

        let entropy_bits = n as f64 * (r as f64).log2(); // H = N·log₂(r) for uniform
        let actual_bits = encoded.len() as f64 * 8.0;

        // Overhead should be small (≤ 10 bits accounting for byte padding)
        assert!(
            actual_bits <= entropy_bits + 18.0, // 2 bits overhead + 8 bits max padding
            "overhead too large: {:.1} bits actual, {:.1} bits entropy",
            actual_bits, entropy_bits
        );
    }

    #[test]
    fn cdf_table_invariants() {
        let r = 100;
        let cdf = CdfTable::from_cdf(|t| t / 100.0, r, 1 << 16);

        assert_eq!(cdf.cum_freq[0], 0, "cum_freq[0] must be 0");
        assert_eq!(*cdf.cum_freq.last().unwrap(), cdf.total, "last entry must equal total");

        // Strictly increasing
        for i in 0..r {
            assert!(
                cdf.cum_freq[i] < cdf.cum_freq[i + 1],
                "cum_freq not strictly increasing at symbol {}",
                i
            );
        }
    }

    #[test]
    fn symbol_lookup_correct() {
        let r = 8;
        let cdf = CdfTable::uniform(r);
        for sym in 0..r {
            let val = cdf.low(sym);
            assert_eq!(cdf.symbol_for_value(val), sym, "lookup failed for symbol {}", sym);
        }
    }

    #[test]
    fn large_r_900() {
        let r = 900;
        let cdf = CdfTable::uniform(r);
        let positions: Vec<u32> = (0..500).map(|i| (i * 179 + 23) % r as u32).collect();
        let encoded = encode_positions(&positions, r as u32, &cdf);
        let decoded = decode_positions(&encoded, positions.len(), r as u32, &cdf);
        assert_eq!(positions, decoded, "r=900 round-trip failed");
    }
}
