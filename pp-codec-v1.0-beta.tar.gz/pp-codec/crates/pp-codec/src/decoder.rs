//! # Décodeur PP — Accès aléatoire O(1) par bloc
//!
//! Sprint F4 : le décodeur lit un fichier .ppv et reconstruit :
//! - Toutes les frames (mode séquentiel)
//! - Un seul bloc (mode accès aléatoire O(1) via seek table)
//! - Une plage de frames (mode temporel)
//! - Un seul pixel à travers le temps (mode trace)
//!
//! Le round-trip lossless est garanti : decode(encode(x)) == x pour tout x.

#![forbid(unsafe_code)]

use pp_core::bits::BitReader;
use pp_core::codes::read_delta;
use crate::encoder::{PpvFile, EncodedBlock, EncodingStats, decode_pixel_trace};

/// Decoded video — all frames reconstructed.
#[derive(Debug, Clone)]
pub struct DecodedVideo {
    pub width: u32,
    pub height: u32,
    pub frames: Vec<Vec<u32>>,
    pub stats: DecodeStats,
}

/// Stats from decoding.
#[derive(Debug, Clone, Default)]
pub struct DecodeStats {
    pub blocks_decoded: u32,
    pub pixels_decoded: u64,
    pub bytes_read: usize,
    pub frames_reconstructed: u32,
}

/// Random-access decoder for .ppv files.
///
/// Holds the parsed container in memory and can decode individual blocks
/// without touching the rest of the file.
pub struct PpvDecoder {
    ppv: PpvFile,
    blocks_x: u32,
    blocks_y: u32,
}

impl PpvDecoder {
    /// Open a .ppv file from raw bytes.
    pub fn from_bytes(data: &[u8]) -> Option<Self> {
        let ppv = PpvFile::deserialize(data)?;
        let blocks_x = (ppv.width + ppv.block_size - 1) / ppv.block_size;
        let blocks_y = (ppv.height + ppv.block_size - 1) / ppv.block_size;
        Some(Self { ppv, blocks_x, blocks_y })
    }

    /// Video dimensions.
    pub fn width(&self) -> u32 { self.ppv.width }
    pub fn height(&self) -> u32 { self.ppv.height }
    pub fn num_frames(&self) -> u32 { self.ppv.frames }
    pub fn block_size(&self) -> u32 { self.ppv.block_size }
    pub fn palette_size(&self) -> u32 { self.ppv.palette_size }
    pub fn num_blocks(&self) -> u32 { self.blocks_x * self.blocks_y }
    pub fn blocks_x(&self) -> u32 { self.blocks_x }
    pub fn blocks_y(&self) -> u32 { self.blocks_y }

    /// Total compressed size in bytes.
    pub fn compressed_size(&self) -> usize {
        self.ppv.block_data.iter().map(|b| b.len()).sum()
    }

    /// Decode a single block by its grid coordinates (bx, by).
    /// Returns pixel traces for all pixels in the block (row-major).
    /// Each trace is a Vec<u32> of length num_frames.
    ///
    /// This is O(1) seek + O(B²·r) decode — no need to read other blocks.
    pub fn decode_block(&self, bx: u32, by: u32) -> Option<Vec<Vec<u32>>> {
        if bx >= self.blocks_x || by >= self.blocks_y {
            return None;
        }
        let block_idx = (by * self.blocks_x + bx) as usize;
        if block_idx >= self.ppv.block_data.len() {
            return None;
        }

        let block_data = &self.ppv.block_data[block_idx];
        let block_bits = self.ppv.block_bits[block_idx];
        let mut reader = BitReader::with_bit_len(block_data, block_bits);

        let num_pixels = read_delta(&mut reader) as usize;
        let mut traces = Vec::with_capacity(num_pixels);

        for _ in 0..num_pixels {
            let pixel_bits = read_delta(&mut reader) as usize;
            let pixel_bytes = (pixel_bits + 7) / 8;

            let mut pixel_data = Vec::with_capacity(pixel_bytes);
            for _ in 0..pixel_bytes {
                pixel_data.push(reader.read_bits(8) as u8);
            }

            let encoded = EncodedBlock {
                data: pixel_data,
                bits_used: pixel_bits,
                r: self.ppv.frames,
                num_colors: 0,
                encoding_stats: EncodingStats::default(),
            };

            traces.push(decode_pixel_trace(&encoded));
        }

        Some(traces)
    }

    /// Decode a single pixel's temporal trace by its (x, y) coordinates.
    /// Returns a Vec<u32> of length num_frames.
    ///
    /// Internally finds which block contains this pixel and decodes only that block.
    pub fn decode_pixel(&self, x: u32, y: u32) -> Option<Vec<u32>> {
        if x >= self.ppv.width || y >= self.ppv.height {
            return None;
        }
        let bs = self.ppv.block_size;
        let bx = x / bs;
        let by = y / bs;
        let dx = (x % bs) as usize;
        let dy = (y % bs) as usize;
        let pixel_in_block = dy * bs as usize + dx;

        let traces = self.decode_block(bx, by)?;
        traces.into_iter().nth(pixel_in_block)
    }

    /// Decode all blocks and reconstruct all frames.
    pub fn decode_all(&self) -> DecodedVideo {
        let r = self.ppv.frames as usize;
        let w = self.ppv.width as usize;
        let h = self.ppv.height as usize;
        let bs = self.ppv.block_size as usize;

        let mut frames: Vec<Vec<u32>> = (0..r).map(|_| vec![0u32; w * h]).collect();
        let mut stats = DecodeStats::default();

        for by in 0..self.blocks_y {
            for bx in 0..self.blocks_x {
                if let Some(traces) = self.decode_block(bx, by) {
                    stats.blocks_decoded += 1;

                    let x0 = (bx * self.ppv.block_size) as usize;
                    let y0 = (by * self.ppv.block_size) as usize;

                    for (p, trace) in traces.iter().enumerate() {
                        let dx = p % bs;
                        let dy = p / bs;
                        let x = x0 + dx;
                        let y = y0 + dy;

                        if x < w && y < h {
                            stats.pixels_decoded += 1;
                            let pixel_idx = y * w + x;
                            for (t, &color) in trace.iter().enumerate() {
                                if t < r {
                                    frames[t][pixel_idx] = color;
                                }
                            }
                        }
                    }
                }
            }
        }

        stats.frames_reconstructed = r as u32;
        stats.bytes_read = self.ppv.block_data.iter().map(|b| b.len()).sum();

        DecodedVideo {
            width: self.ppv.width,
            height: self.ppv.height,
            frames,
            stats,
        }
    }

    /// Decode a single frame at time index t.
    /// More efficient than decode_all when only one frame is needed —
    /// still decodes all blocks but only extracts frame t.
    pub fn decode_frame(&self, t: u32) -> Option<Vec<u32>> {
        if t >= self.ppv.frames {
            return None;
        }
        let w = self.ppv.width as usize;
        let h = self.ppv.height as usize;
        let bs = self.ppv.block_size as usize;
        let mut frame = vec![0u32; w * h];

        for by in 0..self.blocks_y {
            for bx in 0..self.blocks_x {
                if let Some(traces) = self.decode_block(bx, by) {
                    let x0 = (bx * self.ppv.block_size) as usize;
                    let y0 = (by * self.ppv.block_size) as usize;

                    for (p, trace) in traces.iter().enumerate() {
                        let dx = p % bs;
                        let dy = p / bs;
                        let x = x0 + dx;
                        let y = y0 + dy;
                        if x < w && y < h && (t as usize) < trace.len() {
                            frame[y * w + x] = trace[t as usize];
                        }
                    }
                }
            }
        }

        Some(frame)
    }

    /// Decode a range of frames [t_start, t_end).
    pub fn decode_frame_range(&self, t_start: u32, t_end: u32) -> Vec<Vec<u32>> {
        let t_end = t_end.min(self.ppv.frames);
        let w = self.ppv.width as usize;
        let h = self.ppv.height as usize;
        let bs = self.ppv.block_size as usize;
        let count = (t_end.saturating_sub(t_start)) as usize;

        let mut frames: Vec<Vec<u32>> = (0..count).map(|_| vec![0u32; w * h]).collect();

        for by in 0..self.blocks_y {
            for bx in 0..self.blocks_x {
                if let Some(traces) = self.decode_block(bx, by) {
                    let x0 = (bx * self.ppv.block_size) as usize;
                    let y0 = (by * self.ppv.block_size) as usize;

                    for (p, trace) in traces.iter().enumerate() {
                        let dx = p % bs;
                        let dy = p / bs;
                        let x = x0 + dx;
                        let y = y0 + dy;
                        if x < w && y < h {
                            for t in t_start..t_end {
                                let fi = (t - t_start) as usize;
                                if (t as usize) < trace.len() {
                                    frames[fi][y * w + x] = trace[t as usize];
                                }
                            }
                        }
                    }
                }
            }
        }

        frames
    }

    /// Get compression ratio (raw_size / compressed_size).
    pub fn compression_ratio(&self) -> f64 {
        let raw_bits = self.ppv.width as f64
            * self.ppv.height as f64
            * self.ppv.frames as f64
            * (self.ppv.palette_size as f64).log2().ceil().max(1.0);
        let compressed_bits = self.compressed_size() as f64 * 8.0;
        if compressed_bits > 0.0 { raw_bits / compressed_bits } else { 0.0 }
    }

    /// Get bits per pixel (across all frames).
    pub fn bpp(&self) -> f64 {
        let total_pixels = self.ppv.width as f64 * self.ppv.height as f64 * self.ppv.frames as f64;
        let total_bits = self.compressed_size() as f64 * 8.0;
        if total_pixels > 0.0 { total_bits / total_pixels } else { 0.0 }
    }
}

// ─── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::encoder::encode_video;

    /// Generate a surveillance-style video: mostly static background with activity bursts.
    fn gen_surveillance(w: u32, h: u32, r: u32, m: u32, activity_pct: f64) -> Vec<Vec<u32>> {
        (0..r as usize).map(|t| {
            (0..(w * h) as usize).map(|p| {
                let is_active = ((p * 137 + t * 31) % 1000) < (activity_pct * 1000.0) as usize;
                let in_burst = t >= (r as usize / 4) && t <= (3 * r as usize / 4);
                if is_active && in_burst {
                    ((p * 7 + t * 3) % m as usize) as u32
                } else {
                    0u32 // static background
                }
            }).collect()
        }).collect()
    }

    #[test]
    fn random_access_single_block() {
        let w = 16u32; let h = 16; let r = 32; let m = 4; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.1);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        // Decode block (0,0) only
        let traces = decoder.decode_block(0, 0).expect("decode block failed");
        assert_eq!(traces.len(), (bs * bs) as usize);

        // Verify traces match original
        for (p, trace) in traces.iter().enumerate() {
            let dx = p % bs as usize;
            let dy = p / bs as usize;
            for t in 0..r as usize {
                let expected = frames[t][dy * w as usize + dx];
                assert_eq!(trace[t], expected,
                    "block(0,0) pixel ({},{}) frame {} mismatch", dx, dy, t);
            }
        }
    }

    #[test]
    fn random_access_single_pixel() {
        let w = 24u32; let h = 24; let r = 16; let m = 8; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.15);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        // Decode pixel (12, 18)
        let trace = decoder.decode_pixel(12, 18).expect("decode pixel failed");
        assert_eq!(trace.len(), r as usize);

        let pixel_idx = 18 * w as usize + 12;
        for t in 0..r as usize {
            assert_eq!(trace[t], frames[t][pixel_idx],
                "pixel (12,18) frame {} mismatch", t);
        }
    }

    #[test]
    fn decode_single_frame() {
        let w = 16u32; let h = 16; let r = 64; let m = 4; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.2);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        // Decode frame 30
        let frame30 = decoder.decode_frame(30).expect("decode frame failed");
        assert_eq!(frame30, frames[30]);

        // First frame
        let frame0 = decoder.decode_frame(0).expect("decode frame 0 failed");
        assert_eq!(frame0, frames[0]);

        // Last frame
        let last = decoder.decode_frame(r - 1).expect("decode last frame failed");
        assert_eq!(last, frames[(r - 1) as usize]);
    }

    #[test]
    fn decode_frame_range() {
        let w = 16u32; let h = 16; let r = 32; let m = 4; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.1);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        let range = decoder.decode_frame_range(10, 20);
        assert_eq!(range.len(), 10);
        for (i, frame) in range.iter().enumerate() {
            assert_eq!(*frame, frames[10 + i],
                "frame range mismatch at offset {}", i);
        }
    }

    #[test]
    fn full_decode_matches_original() {
        let w = 32u32; let h = 24; let r = 64; let m = 8; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.1);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");
        let decoded = decoder.decode_all();

        assert_eq!(decoded.frames.len(), r as usize);
        for t in 0..r as usize {
            assert_eq!(decoded.frames[t], frames[t],
                "full decode mismatch at frame {}", t);
        }

        eprintln!("Full decode: {}×{} × {} frames, {} colors",
            w, h, r, m);
        eprintln!("  Blocks decoded: {}", decoded.stats.blocks_decoded);
        eprintln!("  Pixels decoded: {}", decoded.stats.pixels_decoded);
        eprintln!("  Compressed: {} bytes", decoded.stats.bytes_read);
        eprintln!("  Ratio: {:.1}:1", decoder.compression_ratio());
        eprintln!("  BPP: {:.3}", decoder.bpp());
    }

    #[test]
    fn out_of_bounds_returns_none() {
        let w = 8u32; let h = 8; let r = 4; let m = 2; let bs = 4;
        let frames: Vec<Vec<u32>> = (0..r as usize).map(|_| vec![0u32; (w*h) as usize]).collect();
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        assert!(decoder.decode_block(10, 10).is_none());
        assert!(decoder.decode_pixel(100, 100).is_none());
        assert!(decoder.decode_frame(999).is_none());
    }

    #[test]
    fn compression_metrics() {
        let w = 32u32; let h = 32; let r = 128; let m = 8; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.05); // Very sparse: 5% activity
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");

        let ratio = decoder.compression_ratio();
        let bpp = decoder.bpp();

        eprintln!("Compression metrics (5% activity):");
        eprintln!("  Size: {}×{} × {} frames, {} palette", w, h, r, m);
        eprintln!("  Raw: {} bits", w * h * r * 3);
        eprintln!("  Compressed: {} bytes", bytes.len());
        eprintln!("  Ratio: {:.1}:1", ratio);
        eprintln!("  BPP: {:.4}", bpp);

        assert!(ratio > 1.5, "5% activity should compress at least 1.5:1, got {:.1}:1", ratio);
    }

    #[test]
    fn large_video_roundtrip() {
        // 64×64 × 128 frames, 16 colors — largest test
        let w = 64u32; let h = 64; let r = 128; let m = 16; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.08);
        
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();
        
        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");
        let decoded = decoder.decode_all();
        
        for t in 0..r as usize {
            assert_eq!(decoded.frames[t], frames[t],
                "large video roundtrip failed at frame {}", t);
        }
        
        let ratio = decoder.compression_ratio();
        let raw_kb = (w * h * r * 4) as f64 / 1024.0;
        let comp_kb = bytes.len() as f64 / 1024.0;
        
        eprintln!("Large video (64×64×128, 16 colors, 8% activity):");
        eprintln!("  Raw: {:.0} KB", raw_kb);
        eprintln!("  Compressed: {:.0} KB", comp_kb);
        eprintln!("  Ratio: {:.1}:1", ratio);
        eprintln!("  Blocks: {}", decoder.num_blocks());
    }

    #[test]
    fn random_access_performance_simulation() {
        // Simulate random access pattern: decode 10 random blocks out of many
        let w = 64u32; let h = 64; let r = 32; let m = 4; let bs = 8;
        let frames = gen_surveillance(w, h, r, m, 0.1);
        let ppv = encode_video(&frames, w, h, bs, m);
        let bytes = ppv.serialize();

        let decoder = PpvDecoder::from_bytes(&bytes).expect("open failed");
        let total_blocks = decoder.num_blocks();

        // Decode 10 random blocks
        let test_blocks: Vec<(u32, u32)> = (0..10).map(|i| {
            let bx = (i * 3 + 1) % decoder.blocks_x();
            let by = (i * 2 + 1) % decoder.blocks_y();
            (bx, by)
        }).collect();

        for &(bx, by) in &test_blocks {
            let traces = decoder.decode_block(bx, by).expect("decode failed");
            let x0 = (bx * bs) as usize;
            let y0 = (by * bs) as usize;

            for (p, trace) in traces.iter().enumerate() {
                let dx = p % bs as usize;
                let dy = p / bs as usize;
                let x = x0 + dx;
                let y = y0 + dy;
                if x < w as usize && y < h as usize {
                    for t in 0..r as usize {
                        assert_eq!(trace[t], frames[t][y * w as usize + x],
                            "random access mismatch block({},{}) pixel({},{}) frame {}",
                            bx, by, dx, dy, t);
                    }
                }
            }
        }

        eprintln!("Random access: decoded {}/{}  blocks successfully", test_blocks.len(), total_blocks);
    }

    #[test]
    fn invalid_ppv_data() {
        assert!(PpvDecoder::from_bytes(&[]).is_none());
        assert!(PpvDecoder::from_bytes(&[0, 0, 0, 0]).is_none());
        assert!(PpvDecoder::from_bytes(b"PPV\x02garbage").is_none());
    }
}
