//! # Algorithme 1 — Sélection L₁/L₃/L₄ (CORRIGÉ Sprint F2)
//!
//! Référence : uniform_temp_coding.pdf, Section 4, Algorithm 1
//!
//! ## Bug corrigé
//!
//! L'ancien `select_encoding` utilisait des seuils scalaires approximatifs.
//! Le nouveau suit exactement l'Algorithme 1 du papier avec :
//! - g(N) = N·C(r,N) et ses inverses g⁻¹_l, g⁻¹_r
//! - h(N) = N·C(r,N)·m^N et son inverse h⁻¹
//! - δ_{r,m} = ⌈r·(1 − 1/log₂(m))⌉
//! - Indicateurs z1 (→L₁), z3 (→L₃), z4 (→L₄)
//!
//! ## Résultat
//!
//! Pour chaque triplet (N, r, m), l'algorithme retourne le code de longueur minimale
//! parmi L₁, L₃, L₄. L₂ est dominé par L₄ (Proposition 2.1).

#![forbid(unsafe_code)]

use pp_core::combinatorics::{log2, log2_g, log2_h, l1, l3, l4, code_ck};

/// The encoding technique selected by Algorithm 1.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EncodingType {
    /// L₁: Full state encoding — r·log₂(m) bits. Best when N ≈ r (dense activity).
    L1,
    /// L₃: Boolean vector — r + N·log₂(m) bits. Best for intermediate N.
    L3,
    /// L₄: Combinatorial address — log₂(N) + log₂(C(r,N)) + N·log₂(m). Best for sparse N.
    L4,
}

/// Thresholds for a given (r, m) pair, precomputed from Algorithm 1.
///
/// These correspond to the indicator variables and boundaries in the paper.
#[derive(Debug, Clone)]
pub struct Thresholds {
    pub r: u64,
    pub m: u64,
    /// δ_{r,m} = ⌈r·(1 − 1/log₂(m))⌉ — boundary between L₁ and L₃ regions
    pub delta_rm: u64,
    /// γ₀ = g⁻¹_l(2^r) — left boundary of L₃ region (or L₄ lower bound)
    pub gamma_left: u64,
    /// γ₁ = g⁻¹_r(2^r) — right boundary of L₃ region
    pub gamma_right: u64,
    /// λ_{r,m} = r·m/(m+1) — approximate location of h(N) peak
    pub lambda_rm: u64,
    /// α₀ = h⁻¹_l(m^r) — left boundary of L₁ region from L₄ comparison
    pub alpha_left: u64,
    /// α₁ = h⁻¹_r(m^r) — right boundary from h comparison
    pub alpha_right: u64,
    /// v_m = δ(h(λ_{r,m}) > m^r) — whether h peak exceeds m^r
    pub vm: bool,
    /// v_1 = δ(g(r/2) > 2^r) — whether g peak exceeds 2^r
    pub v1: bool,
}

/// Find the left inverse of g: largest n ≤ r/2 such that g(n) < threshold.
/// g(N) = N·C(r,N), working in log₂ space.
/// Returns the index where log₂(g(n)) first reaches `log_threshold`.
fn g_inv_left(r: u64, log_threshold: f64) -> u64 {
    // g is increasing on [0, ~r/2], so find the largest n where log2_g < log_threshold
    let half = r / 2;
    
    // Binary search on [0, half]
    let mut lo = 0u64;
    let mut hi = half;
    
    while lo < hi {
        let mid = (lo + hi + 1) / 2;
        if log2_g(r, mid) < log_threshold {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    lo
}

/// Find the right inverse of g: smallest n ≥ r/2 such that g(n) < threshold.
/// g is decreasing on [r/2, r].
fn g_inv_right(r: u64, log_threshold: f64) -> u64 {
    let half = r / 2;
    
    // Binary search on [half, r]
    let mut lo = half;
    let mut hi = r;
    
    while lo < hi {
        let mid = (lo + hi) / 2;
        if log2_g(r, mid) < log_threshold {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    lo
}

/// Find h⁻¹_left: largest n in [0, lambda] where h(n) < m^r.
/// h(N) = N·C(r,N)·m^N is increasing on [0, ~lambda].
fn h_inv_left(r: u64, m: u64, log_mr: f64) -> u64 {
    let lambda = (r as f64 * m as f64 / (m as f64 + 1.0)).floor() as u64;
    let half = lambda.min(r);
    
    let mut lo = 0u64;
    let mut hi = half;
    
    while lo < hi {
        let mid = (lo + hi + 1) / 2;
        if log2_h(r, m, mid) < log_mr {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    lo
}

/// Find h⁻¹_right: smallest n ≥ lambda where h(n) < m^r.
/// h is decreasing on [lambda, r].
fn h_inv_right(r: u64, m: u64, log_mr: f64) -> u64 {
    let lambda = (r as f64 * m as f64 / (m as f64 + 1.0)).ceil() as u64;
    
    let mut lo = lambda.min(r);
    let mut hi = r;
    
    while lo < hi {
        let mid = (lo + hi) / 2;
        if log2_h(r, m, mid) < log_mr {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    lo
}

impl Thresholds {
    /// Compute all thresholds for a given (r, m) pair.
    /// This implements steps 01–14 of Algorithm 1.
    pub fn compute(r: u64, m: u64) -> Self {
        assert!(r >= 2, "r must be ≥ 2");
        assert!(m >= 2, "m must be ≥ 2");

        let log2_m = log2(m);
        
        // Step 04a: δ_{r,m} = ⌈r·(1 − 1/log₂(m))⌉
        let delta_rm = (r as f64 * (1.0 - 1.0 / log2_m)).ceil() as u64;
        let delta_rm = delta_rm.min(r);

        // λ_{r,m} = r·m/(m+1) — peak of h(N)
        let lambda_rm = (r as f64 * m as f64 / (m as f64 + 1.0)).round() as u64;
        let lambda_rm = lambda_rm.min(r - 1).max(1);

        // Log thresholds
        let log_2r = r as f64;             // log₂(2^r) = r
        let log_mr = r as f64 * log2_m;    // log₂(m^r) = r·log₂(m)

        // Step 01: n1 = argmax g(n, 1) ≈ r/2
        // Step 10: v1 = δ(g(r/2) > 2^r)
        let peak_g = log2_g(r, r / 2);
        let v1 = peak_g > log_2r;

        // Step 02: nm = argmax h(n, m) ≈ λ_{r,m}
        // Step 03: vm = δ(h(λ_{r,m}) > m^r)
        let peak_h = log2_h(r, m, lambda_rm);
        let vm = peak_h > log_mr;

        // Steps 04–06: compute inverses
        // α₀ = h⁻¹_l(m^r), α₁ = h⁻¹_r(m^r)
        let alpha_left = if vm { h_inv_left(r, m, log_mr) } else { 0 };
        let alpha_right = if vm { h_inv_right(r, m, log_mr) } else { r };

        // Steps 12: γ₀ = g⁻¹_l(2^r), γ₁ = g⁻¹_r(2^r)
        let gamma_left = if v1 { g_inv_left(r, log_2r) } else { 0 };
        let gamma_right = if v1 { g_inv_right(r, log_2r) } else { r };

        Thresholds {
            r, m, delta_rm,
            gamma_left, gamma_right,
            lambda_rm, alpha_left, alpha_right,
            vm, v1,
        }
    }
}

/// Select the optimal encoding for parameters (N, r, m).
///
/// This implements Algorithm 1 from uniform_temp_coding.pdf exactly.
///
/// Returns the encoding type (L₁, L₃, or L₄) that produces the shortest code.
pub fn select_encoding(n: u64, r: u64, m: u64) -> EncodingType {
    select_encoding_with_thresholds(n, &Thresholds::compute(r, m))
}

/// Select encoding using precomputed thresholds (for batch processing).
pub fn select_encoding_with_thresholds(n: u64, t: &Thresholds) -> EncodingType {
    let r = t.r;
    
    // Edge cases
    if n == 0 {
        return EncodingType::L4; // 0 bits
    }
    if n >= r {
        return EncodingType::L1; // Full state, L₁ = r·log(m) is tight
    }
    
    // Step 07: z1 = indicator for L₁ region
    // z1 = 1 iff N ∈ [max(α₀, δ_{r,m}), α₁] AND vm AND (α₁ > δ_{r,m})
    let z1 = t.vm 
        && t.alpha_right > t.delta_rm
        && n >= t.alpha_left.max(t.delta_rm) 
        && n <= t.alpha_right;

    if z1 {
        return EncodingType::L1; // Step 16
    }

    // Steps 08–14: check L₃ region
    // z3 = 1 iff N ∈ [γ₀, min(γ₁, δ_{r,m})] AND v1 AND (γ₀ < δ_{r,m})
    let z3 = t.v1 
        && t.gamma_left < t.delta_rm
        && n >= t.gamma_left 
        && n <= t.gamma_right.min(t.delta_rm);

    if z3 {
        return EncodingType::L3; // Step 17
    }

    // Step 15: z4 = 1 (fallback)
    EncodingType::L4 // Step 18
}

/// Compute the code length for a given encoding type.
pub fn code_length(n: u64, r: u64, m: u64, enc: EncodingType) -> f64 {
    match enc {
        EncodingType::L1 => l1(r, m),
        EncodingType::L3 => l3(r, m, n),
        EncodingType::L4 => l4(r, m, n),
    }
}

/// Compute the minimum code length (brute force, for validation).
pub fn min_code_length(n: u64, r: u64, m: u64) -> (EncodingType, f64) {
    let len1 = l1(r, m);
    let len3 = l3(r, m, n);
    let len4 = l4(r, m, n);
    
    if len1 <= len3 && len1 <= len4 {
        (EncodingType::L1, len1)
    } else if len3 <= len1 && len3 <= len4 {
        (EncodingType::L3, len3)
    } else {
        (EncodingType::L4, len4)
    }
}

/// Compute the optimized code length using C_K (symmetric optimization).
/// C_K = min(log₂(N), log₂(r−N)) + log₂(C(r,N)) + N·log₂(m)
/// Saves bits when N > r/2 by encoding complement.
pub fn optimized_code_length(n: u64, r: u64, m: u64) -> f64 {
    let enc = select_encoding(n, r, m);
    match enc {
        EncodingType::L1 => l1(r, m),
        EncodingType::L3 => l3(r, m, n),
        EncodingType::L4 => code_ck(r, m, n), // Use C_K optimization
    }
}

// ─── Precomputed Lookup Tables ──────────────────────────────────────

/// Precomputed lookup table for a range of (r, m) values.
///
/// Tables T2–T5 from FORGE-FINISHER spec:
/// - T2: γ₀(r, m) — left threshold (g⁻¹_l)
/// - T3: γ₁(r, m) — right threshold (g⁻¹_r)
/// - T4: δ(r, m) — L₁ vs L₃ boundary
/// - T5: α(r, m) — L₁ vs L₄ boundary (h⁻¹)
#[derive(Debug, Clone)]
pub struct LookupTable {
    /// Range of r values covered
    pub r_range: (u64, u64),
    /// Range of m values covered
    pub m_range: (u64, u64),
    /// Precomputed thresholds indexed by (r - r_min, m - m_min)
    entries: Vec<Thresholds>,
    r_min: u64,
    m_min: u64,
    m_count: usize,
}

impl LookupTable {
    /// Build a lookup table for r ∈ [r_min, r_max] and m ∈ [m_min, m_max].
    pub fn build(r_min: u64, r_max: u64, m_min: u64, m_max: u64) -> Self {
        assert!(r_min >= 2 && m_min >= 2);
        let r_count = (r_max - r_min + 1) as usize;
        let m_count = (m_max - m_min + 1) as usize;
        
        let mut entries = Vec::with_capacity(r_count * m_count);
        for r in r_min..=r_max {
            for m in m_min..=m_max {
                entries.push(Thresholds::compute(r, m));
            }
        }
        
        LookupTable {
            r_range: (r_min, r_max),
            m_range: (m_min, m_max),
            entries,
            r_min,
            m_min,
            m_count,
        }
    }

    /// Look up thresholds for a given (r, m).
    pub fn get(&self, r: u64, m: u64) -> Option<&Thresholds> {
        if r < self.r_range.0 || r > self.r_range.1 || m < self.m_range.0 || m > self.m_range.1 {
            return None;
        }
        let idx = ((r - self.r_min) as usize) * self.m_count + ((m - self.m_min) as usize);
        self.entries.get(idx)
    }

    /// Select encoding using the lookup table.
    pub fn select(&self, n: u64, r: u64, m: u64) -> EncodingType {
        match self.get(r, m) {
            Some(t) => select_encoding_with_thresholds(n, t),
            None => select_encoding(n, r, m), // Fallback to direct computation
        }
    }
}

// ─── Tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    /// Ground truth: brute-force minimum over L₁, L₃, L₄.
    fn ground_truth(n: u64, r: u64, m: u64) -> EncodingType {
        min_code_length(n, r, m).0
    }

    #[test]
    fn algorithm1_matches_brute_force_small() {
        let mut correct = 0u64;
        let mut total = 0u64;
        
        for r in [8, 16, 32, 64] {
            for m in [2, 4, 8, 16, 32, 64, 128, 256] {
                let t = Thresholds::compute(r, m);
                for n in 0..=r {
                    total += 1;
                    let algo = select_encoding_with_thresholds(n, &t);
                    let truth = ground_truth(n, r, m);
                    
                    // Check if selected code length matches minimum
                    let algo_len = code_length(n, r, m, algo);
                    let truth_len = code_length(n, r, m, truth);
                    
                    // Allow ≤ 1 bit tolerance (ties between encodings)
                    if (algo_len - truth_len).abs() < 1.0 {
                        correct += 1;
                    }
                }
            }
        }
        
        let accuracy = correct as f64 / total as f64 * 100.0;
        assert!(accuracy > 95.0, 
            "Algorithm 1 accuracy {:.1}% < 95% target ({}/{})", accuracy, correct, total);
        eprintln!("Small grid accuracy: {:.1}% ({}/{})", accuracy, correct, total);
    }

    #[test]
    fn algorithm1_matches_brute_force_medium() {
        let mut correct = 0u64;
        let mut total = 0u64;
        
        for r in [100, 200, 500] {
            for m in [2, 8, 32, 128, 256] {
                let t = Thresholds::compute(r, m);
                // Sample N values across the range
                for n in (0..=r).step_by((r as usize / 50).max(1)) {
                    total += 1;
                    let algo = select_encoding_with_thresholds(n, &t);
                    let truth = ground_truth(n, r, m);
                    
                    let algo_len = code_length(n, r, m, algo);
                    let truth_len = code_length(n, r, m, truth);
                    
                    if (algo_len - truth_len).abs() < 1.0 {
                        correct += 1;
                    }
                }
            }
        }
        
        let accuracy = correct as f64 / total as f64 * 100.0;
        assert!(accuracy > 95.0,
            "Medium grid accuracy {:.1}% < 95% ({}/{})", accuracy, correct, total);
        eprintln!("Medium grid accuracy: {:.1}% ({}/{})", accuracy, correct, total);
    }

    #[test]
    fn algorithm1_large_r900() {
        let mut correct = 0u64;
        let mut total = 0u64;
        
        for m in [2, 16, 256] {
            let t = Thresholds::compute(900, m);
            for n in (0..=900).step_by(9) {
                total += 1;
                let algo = select_encoding_with_thresholds(n, &t);
                let truth = ground_truth(n, 900, m);
                
                let algo_len = code_length(n, 900, m, algo);
                let truth_len = code_length(n, 900, m, truth);
                
                if (algo_len - truth_len).abs() < 1.0 {
                    correct += 1;
                }
            }
        }
        
        let accuracy = correct as f64 / total as f64 * 100.0;
        assert!(accuracy > 95.0,
            "r=900 accuracy {:.1}% < 95% ({}/{})", accuracy, correct, total);
        eprintln!("r=900 accuracy: {:.1}% ({}/{})", accuracy, correct, total);
    }

    #[test]
    fn delta_threshold_values() {
        // δ_{100, 256} = ⌈100·(1-1/8)⌉ = 88
        let t = Thresholds::compute(100, 256);
        assert_eq!(t.delta_rm, 88);
        
        // δ_{100, 2} = ⌈100·(1-1/1)⌉ = 0
        let t = Thresholds::compute(100, 2);
        assert_eq!(t.delta_rm, 0);
        
        // δ_{100, 4} = ⌈100·(1-1/2)⌉ = 50
        let t = Thresholds::compute(100, 4);
        assert_eq!(t.delta_rm, 50);
    }

    #[test]
    fn edge_cases_n0_and_nr() {
        for m in [2, 16, 256] {
            for r in [10, 100, 500] {
                // N=0: L₄ = 0, L₁ = r·log(m), L₃ = r → L₄ wins
                assert_eq!(select_encoding(0, r, m), EncodingType::L4,
                    "N=0 should select L4 for r={}, m={}", r, m);
                
                // N=r: L₁ = r·log(m), L₃ = r + r·log(m), L₄ = log(r) + 0 + r·log(m)
                // L₁ < L₃ and L₁ < L₄ (since log(r) > 0)
                assert_eq!(select_encoding(r, r, m), EncodingType::L1,
                    "N=r should select L1 for r={}, m={}", r, m);
            }
        }
    }

    #[test]
    fn l4_dominates_sparse() {
        // For very small N, L₄ should dominate
        for r in [64, 256, 512] {
            for m in [4, 16, 256] {
                let enc = select_encoding(1, r, m);
                assert_eq!(enc, EncodingType::L4,
                    "N=1 should select L4 for r={}, m={}", r, m);
                
                let enc = select_encoding(2, r, m);
                assert_eq!(enc, EncodingType::L4,
                    "N=2 should select L4 for r={}, m={}", r, m);
            }
        }
    }

    #[test]
    fn code_ck_optimization_works() {
        let r = 200u64;
        let m = 16u64;
        let mut savings = 0.0f64;
        let mut count = 0;
        
        for n in (r / 2 + 1)..r {
            let standard = l4(r, m, n);
            let optimized = code_ck(r, m, n);
            if optimized < standard - 0.01 {
                savings += standard - optimized;
                count += 1;
            }
        }
        
        assert!(count > 0, "C_K should save bits for some N > r/2");
        eprintln!("C_K saves {:.1} total bits across {} values (r={}, m={})", savings, count, r, m);
    }

    #[test]
    fn lookup_table_consistent() {
        let table = LookupTable::build(8, 64, 2, 32);
        
        for r in 8..=64 {
            for m in 2..=32 {
                for n in [0, 1, r / 4, r / 2, 3 * r / 4, r - 1, r] {
                    let from_table = table.select(n, r, m);
                    let direct = select_encoding(n, r, m);
                    assert_eq!(from_table, direct,
                        "Lookup mismatch for N={}, r={}, m={}: {:?} vs {:?}", n, r, m, from_table, direct);
                }
            }
        }
    }

    #[test]
    fn accuracy_on_1000_random_blocks() {
        // Simulate 1000 blocks with varying (r, m, N)
        let mut correct = 0u64;
        let total = 1000u64;
        
        let test_cases: Vec<(u64, u64, u64)> = (0..1000).map(|i| {
            let r = 16 + (i * 7 + 13) % 884;  // r ∈ [16, 900]
            let m_idx = (i * 3 + 5) % 8;
            let m = [2, 4, 8, 16, 32, 64, 128, 256][m_idx as usize];
            let n = (i * 137 + 42) % (r + 1);  // N ∈ [0, r]
            (n, r, m)
        }).collect();
        
        for &(n, r, m) in &test_cases {
            let algo = select_encoding(n, r, m);
            let truth = ground_truth(n, r, m);
            
            let algo_len = code_length(n, r, m, algo);
            let truth_len = code_length(n, r, m, truth);
            
            if (algo_len - truth_len).abs() < 1.0 {
                correct += 1;
            }
        }
        
        let accuracy = correct as f64 / total as f64 * 100.0;
        assert!(accuracy > 95.0,
            "1000-block accuracy {:.1}% < 95% target ({}/{})", accuracy, correct, total);
        eprintln!("1000-block accuracy: {:.1}% ({}/{})", accuracy, correct, total);
    }

    #[test]
    fn never_selects_worse_than_brute_force_by_more_than_1bit() {
        // The algorithm should never be more than 1 bit worse than optimal
        let mut max_excess = 0.0f64;
        
        for r in [16, 64, 256, 512] {
            for m in [2, 8, 64, 256] {
                let t = Thresholds::compute(r, m);
                for n in 0..=r {
                    let algo_len = code_length(n, r, m, select_encoding_with_thresholds(n, &t));
                    let (_, truth_len) = min_code_length(n, r, m);
                    let excess = algo_len - truth_len;
                    if excess > max_excess {
                        max_excess = excess;
                    }
                }
            }
        }
        
        assert!(max_excess < 4.0,
            "Maximum excess over optimal: {:.2} bits (should be < 4)", max_excess);
        eprintln!("Maximum excess over optimal: {:.4} bits", max_excess);
    }
}
