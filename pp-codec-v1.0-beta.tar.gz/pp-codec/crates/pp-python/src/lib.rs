//! # PP-CODEC Python SDK (PyO3 0.21+)
//! Ref: planDEV S05-S06, UC-A08, UC-A09
#![forbid(unsafe_code)]

use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict, PyList};
use pyo3::exceptions::PyValueError;

use pp_codec::encoder::{encode_video, encode_video_v2, decode_video, PpvFile};
use pp_codec::decoder::PpvDecoder;
use pp_codec::multiscale::encode_video_pyramid;
use pp_codec::quantize::{quantize_rgb as q_rgb, compute_psnr as c_psnr};
use pp_codec::stv_uri::{StvUri, resolve};

#[pyfunction]
#[pyo3(signature = (frames, width, height, block_size=16, palette_size=8))]
fn encode(py: Python, frames: Vec<Vec<u32>>, width: u32, height: u32,
          block_size: u32, palette_size: u32) -> PyResult<PyObject> {
    if frames.is_empty() { return Err(PyValueError::new_err("empty frames")); }
    let ppv = encode_video(&frames, width, height, block_size, palette_size);
    Ok(PyBytes::new_bound(py, &ppv.serialize()).into())
}

#[pyfunction]
#[pyo3(signature = (frames, width, height, block_size=16, palette_size=8))]
fn encode_v2(py: Python, frames: Vec<Vec<u32>>, width: u32, height: u32,
             block_size: u32, palette_size: u32) -> PyResult<PyObject> {
    if frames.is_empty() { return Err(PyValueError::new_err("empty frames")); }
    let (ppv, _) = encode_video_v2(&frames, width, height, block_size, palette_size);
    Ok(PyBytes::new_bound(py, &ppv.serialize()).into())
}

#[pyfunction]
#[pyo3(signature = (frames, width, height, block_size=16, palette_size=8))]
fn encode_pyramid(py: Python, frames: Vec<Vec<u32>>, width: u32, height: u32,
                  block_size: u32, palette_size: u32) -> PyResult<PyObject> {
    if frames.is_empty() { return Err(PyValueError::new_err("empty frames")); }
    let (data, _) = encode_video_pyramid(&frames, width, height, block_size, palette_size);
    Ok(PyBytes::new_bound(py, &data).into())
}

#[pyfunction]
#[pyo3(signature = (rgb_frames, width, height, palette_size=16))]
fn encode_rgb(py: Python, rgb_frames: Vec<Vec<u8>>, width: u32, height: u32,
              palette_size: usize) -> PyResult<(PyObject, PyObject)> {
    if rgb_frames.is_empty() { return Err(PyValueError::new_err("empty")); }
    let (pal, indexed) = q_rgb(&rgb_frames, width, height, palette_size);
    let ppv = encode_video(&indexed, width, height, 16, pal.len() as u32);
    let pal_list = PyList::empty_bound(py);
    for c in &pal.colors { pal_list.append((c.r, c.g, c.b))?; }
    Ok((PyBytes::new_bound(py, &ppv.serialize()).into(), pal_list.into()))
}

#[pyfunction]
fn decode(ppv_bytes: &[u8]) -> PyResult<Vec<Vec<u32>>> {
    let ppv = PpvFile::deserialize(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    Ok(decode_video(&ppv))
}

#[pyfunction]
fn decode_block(ppv_bytes: &[u8], block_id: usize) -> PyResult<Vec<Vec<u32>>> {
    let dec = PpvDecoder::from_bytes(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    let bx_count = dec.blocks_x() as usize;
    let bx = (block_id % bx_count) as u32;
    let by = (block_id / bx_count) as u32;
    dec.decode_block(bx, by)
        .ok_or_else(|| PyValueError::new_err("block out of range"))
}

#[pyfunction]
fn decode_frame(ppv_bytes: &[u8], t: usize) -> PyResult<Vec<u32>> {
    let dec = PpvDecoder::from_bytes(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    dec.decode_frame(t as u32)
        .ok_or_else(|| PyValueError::new_err("frame out of range"))
}

#[pyfunction]
fn decode_pixel(ppv_bytes: &[u8], x: u32, y: u32) -> PyResult<Vec<u32>> {
    let dec = PpvDecoder::from_bytes(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    dec.decode_pixel(x, y)
        .ok_or_else(|| PyValueError::new_err("pixel out of range"))
}

#[pyfunction]
fn decode_frame_range(ppv_bytes: &[u8], start: usize, end: usize) -> PyResult<Vec<Vec<u32>>> {
    let dec = PpvDecoder::from_bytes(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    Ok(dec.decode_frame_range(start as u32, end as u32))
}

#[pyfunction]
fn info(py: Python, ppv_bytes: &[u8]) -> PyResult<PyObject> {
    let ppv = PpvFile::deserialize(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    let d = PyDict::new_bound(py);
    let bs = ppv.block_size;
    let bx = (ppv.width + bs - 1) / bs;
    let by = (ppv.height + bs - 1) / bs;
    let bits: usize = ppv.block_bits.iter().sum();
    let px = ppv.width as u64 * ppv.height as u64 * ppv.frames as u64;
    let mb = (ppv.palette_size as f64).log2().ceil().max(1.0) as u64;
    let raw = px * mb;
    let ratio = if bits > 0 { raw as f64 / bits as f64 } else { 0.0 };
    d.set_item("width", ppv.width)?; d.set_item("height", ppv.height)?;
    d.set_item("frames", ppv.frames)?; d.set_item("block_size", bs)?;
    d.set_item("palette_size", ppv.palette_size)?;
    d.set_item("num_blocks", ppv.block_data.len())?;
    d.set_item("blocks_x", bx)?; d.set_item("blocks_y", by)?;
    d.set_item("file_bytes", ppv_bytes.len())?;
    d.set_item("bits_total", bits)?; d.set_item("ratio", format!("{:.2}",ratio))?;
    Ok(d.into())
}

#[pyfunction]
fn query_activity(py: Python, ppv_bytes: &[u8], threshold: f64) -> PyResult<PyObject> {
    let ppv = PpvFile::deserialize(ppv_bytes)
        .ok_or_else(|| PyValueError::new_err("invalid .ppv"))?;
    let avg: f64 = ppv.block_bits.iter().sum::<usize>() as f64 / ppv.block_bits.len().max(1) as f64;
    let r = PyList::empty_bound(py);
    for (i, &b) in ppv.block_bits.iter().enumerate() {
        let act = b as f64 / avg.max(1.0);
        if act > threshold {
            let d = PyDict::new_bound(py);
            d.set_item("block_id", i)?; d.set_item("bits", b)?;
            d.set_item("activity", format!("{:.3}", act))?;
            r.append(d)?;
        }
    }
    Ok(r.into())
}

#[pyfunction]
fn parse_uri(py: Python, uri: &str) -> PyResult<PyObject> {
    let p = StvUri::parse(uri).map_err(|e| PyValueError::new_err(format!("{}", e)))?;
    let d = PyDict::new_bound(py);
    d.set_item("scheme", p.scheme.to_string())?;
    d.set_item("authority", &p.authority)?;
    d.set_item("path", &p.path)?;
    d.set_item("uri", p.to_string())?;
    let f = PyDict::new_bound(py);
    if let Some(ref t) = p.fragment.t { f.set_item("t", format!("{:?}",t))?; }
    if let Some(ref b) = p.fragment.b { f.set_item("b", format!("{:?}",b))?; }
    if let Some(ref px) = p.fragment.p { f.set_item("p", format!("({},{})",px.x,px.y))?; }
    if let Some(ref l) = p.fragment.lod { f.set_item("lod", l.to_string())?; }
    if let Some(ref tg) = p.fragment.tag { f.set_item("tag", tg.as_str())?; }
    if let Some(ref c) = p.fragment.color { f.set_item("color", c.as_str())?; }
    if let Some(a) = p.fragment.act { f.set_item("act", a)?; }
    if let Some(ref fm) = p.fragment.fam { f.set_item("fam", fm.as_str())?; }
    d.set_item("fragment", f)?;
    Ok(d.into())
}

#[pyfunction]
fn resolve_uri(py: Python, uri: &str, width: u32, height: u32, frames: u32, block_size: u32) -> PyResult<PyObject> {
    let p = StvUri::parse(uri).map_err(|e| PyValueError::new_err(format!("{}", e)))?;
    let plan = resolve(&p.fragment, width, height, frames, block_size);
    let d = PyDict::new_bound(py);
    d.set_item("block_ids", &plan.block_ids)?;
    d.set_item("lod", plan.lod)?;
    d.set_item("frame_start", plan.frame_range.0)?;
    d.set_item("frame_end", plan.frame_range.1)?;
    d.set_item("filters", &plan.filters)?;
    d.set_item("num_blocks", plan.block_ids.len())?;
    Ok(d.into())
}

#[pyfunction]
fn psnr(original: Vec<Vec<u8>>, reconstructed: Vec<Vec<u8>>) -> f64 { c_psnr(&original, &reconstructed) }

#[pyfunction]
fn version() -> String { "pp-codec-python 0.1.0 (FORGE v2.0)".into() }

#[pymodule]
fn pp_codec_python(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(encode, m)?)?;
    m.add_function(wrap_pyfunction!(encode_v2, m)?)?;
    m.add_function(wrap_pyfunction!(encode_pyramid, m)?)?;
    m.add_function(wrap_pyfunction!(encode_rgb, m)?)?;
    m.add_function(wrap_pyfunction!(decode, m)?)?;
    m.add_function(wrap_pyfunction!(decode_block, m)?)?;
    m.add_function(wrap_pyfunction!(decode_frame, m)?)?;
    m.add_function(wrap_pyfunction!(decode_pixel, m)?)?;
    m.add_function(wrap_pyfunction!(decode_frame_range, m)?)?;
    m.add_function(wrap_pyfunction!(info, m)?)?;
    m.add_function(wrap_pyfunction!(query_activity, m)?)?;
    m.add_function(wrap_pyfunction!(parse_uri, m)?)?;
    m.add_function(wrap_pyfunction!(resolve_uri, m)?)?;
    m.add_function(wrap_pyfunction!(psnr, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    Ok(())
}
