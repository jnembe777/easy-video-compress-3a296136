//! # AppState — Single Source of Truth
//! Ref: modMVC §3.1, SFD-PLY-001..006
#![forbid(unsafe_code)]

use std::collections::HashMap;

/// Palette rendering mode (SFD-PLY-001 toolbar.palette).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PaletteMode {
    Original,
    Grayscale,
    Heatmap,
    FalseColor,
}

impl Default for PaletteMode {
    fn default() -> Self { Self::Original }
}

/// Export format for query results.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExportFormat {
    Csv,
    Json,
}

/// Rectangular region (normalized [0,1]).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rect {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

impl Default for Rect {
    fn default() -> Self { Rect { x: 0.0, y: 0.0, w: 1.0, h: 1.0 } }
}

/// Zoom state (SFD-PLY-002).
#[derive(Debug, Clone, PartialEq)]
pub struct ZoomState {
    pub active: bool,
    pub region: Rect,
    pub factor: u32,
    pub lod_override: Option<u8>,
    pub smooth: bool,
}

impl Default for ZoomState {
    fn default() -> Self {
        ZoomState { active: false, region: Rect::default(), factor: 1, lod_override: None, smooth: true }
    }
}

/// Header information from a loaded .ppv file.
#[derive(Debug, Clone, Default)]
pub struct PpvHeader {
    pub width: u32,
    pub height: u32,
    pub frames: u32,
    pub block_size: u32,
    pub palette_size: u32,
    pub num_blocks: u32,
    pub blocks_x: u32,
    pub blocks_y: u32,
}

/// Encoding parameters (SFD-PLY-006).
#[derive(Debug, Clone)]
pub struct EncodeParams {
    pub source_path: String,
    pub output_path: String,
    pub block_size: u32,
    pub palette_size: u32,
    pub enable_pyramid: bool,
    pub enable_parallel: bool,
}

/// Query expression for compressed-domain search (SFD-PLY-005).
#[derive(Debug, Clone)]
pub struct QueryExpr {
    pub select_type: String,     // "blocks", "frames", "pixels"
    pub act_threshold: Option<f64>,
    pub t_start: Option<u32>,
    pub t_end: Option<u32>,
    pub color_filter: Option<String>,
    pub family_filter: Option<String>,
}

impl std::fmt::Display for QueryExpr {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        let mut parts = Vec::new();
        parts.push(format!("SELECT {}", self.select_type));
        if let Some(a) = self.act_threshold { parts.push(format!("act>{:.3}", a)); }
        if let Some(t) = self.t_start { parts.push(format!("t>={}", t)); }
        if let Some(t) = self.t_end { parts.push(format!("t<={}", t)); }
        if let Some(ref c) = self.color_filter { parts.push(format!("color={}", c)); }
        if let Some(ref f2) = self.family_filter { parts.push(format!("fam={}", f2)); }
        write!(f, "{}", parts.join(" AND "))
    }
}

/// Encoding progress.
#[derive(Debug, Clone)]
pub struct EncodeProgress {
    pub percent: f32,
    pub ratio: f64,
    pub blocks_done: u32,
    pub blocks_total: u32,
}

/// Encoding summary.
#[derive(Debug, Clone)]
pub struct EncodeSummary {
    pub output_path: String,
    pub ratio: f64,
    pub duration_ms: f64,
    pub file_bytes: usize,
}

/// Transmission history entry (streaming).
#[derive(Debug, Clone)]
pub struct TxEntry {
    pub block_id: usize,
    pub lod: u8,
    pub bytes: usize,
    pub timestamp_ms: f64,
}

/// Global application state — the single source of truth.
/// All Views read from it, only Controllers mutate it.
/// Ref: modMVC §3.1 (15 fields)
#[derive(Debug, Clone)]
pub struct AppState {
    // File & decoder
    pub file_loaded: bool,
    pub file_path: Option<String>,
    pub header: Option<PpvHeader>,
    pub ppv_bytes: Option<Vec<u8>>,       // loaded .ppv data

    // Playback
    pub playing: bool,
    pub current_frame: u32,
    pub playback_speed: f64,

    // View
    pub zoom: ZoomState,
    pub palette_mode: PaletteMode,
    pub lod_current: u8,

    // Panels
    pub selected_block: Option<usize>,
    pub intensity_overlay: bool,

    // Query
    pub query_results: Option<QueryResultState>,

    // Streaming
    pub ppsp_connected: bool,
    pub session_id: Option<u64>,
    pub tx_history: Vec<TxEntry>,
}

/// Query results stored in state (SFD-PLY-005).
#[derive(Debug, Clone)]
pub struct QueryResultState {
    pub matches: Vec<BlockMatchRow>,
    pub total_count: usize,
    pub exec_ms: f64,
    pub expression: String,
}

/// A single match row in query results.
#[derive(Debug, Clone)]
pub struct BlockMatchRow {
    pub block_id: usize,
    pub bx: u32,
    pub by: u32,
    pub n_total: u32,
    pub family: String,
    pub activity: f64,
}

impl Default for AppState {
    fn default() -> Self {
        AppState {
            file_loaded: false,
            file_path: None,
            header: None,
            ppv_bytes: None,
            playing: false,
            current_frame: 0,
            playback_speed: 1.0,
            zoom: ZoomState::default(),
            palette_mode: PaletteMode::default(),
            lod_current: 0,
            selected_block: None,
            intensity_overlay: false,
            query_results: None,
            ppsp_connected: false,
            session_id: None,
            tx_history: Vec::new(),
        }
    }
}

impl AppState {
    /// Total frames from header, or 0.
    pub fn total_frames(&self) -> u32 {
        self.header.as_ref().map_or(0, |h| h.frames)
    }

    /// Dimensions string (e.g. "1920×1080").
    pub fn resolution_str(&self) -> String {
        self.header.as_ref().map_or("—".into(), |h| format!("{}×{}", h.width, h.height))
    }

    /// Current STV-URI fragment.
    pub fn current_uri_fragment(&self) -> String {
        let mut parts = Vec::new();
        parts.push(format!("t={}", self.current_frame));
        if self.zoom.active {
            parts.push(format!("lod=N{}", self.lod_current));
        }
        if let Some(bid) = self.selected_block {
            if let Some(ref h) = self.header {
                let bx = bid as u32 % h.blocks_x;
                let by = bid as u32 / h.blocks_x;
                parts.push(format!("b={},{}", bx, by));
            }
        }
        parts.join("&")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_state() {
        let s = AppState::default();
        assert!(!s.file_loaded);
        assert!(!s.playing);
        assert_eq!(s.playback_speed, 1.0);
        assert_eq!(s.current_frame, 0);
        assert!(!s.zoom.active);
    }

    #[test]
    fn test_uri_fragment() {
        let mut s = AppState::default();
        s.current_frame = 42;
        assert_eq!(s.current_uri_fragment(), "t=42");

        s.zoom.active = true;
        s.lod_current = 2;
        assert!(s.current_uri_fragment().contains("lod=N2"));
    }

    #[test]
    fn test_query_expr_display() {
        let q = QueryExpr {
            select_type: "blocks".into(),
            act_threshold: Some(0.1),
            t_start: Some(100),
            t_end: Some(200),
            color_filter: None,
            family_filter: Some("bspline".into()),
        };
        let s = q.to_string();
        assert!(s.contains("SELECT blocks"));
        assert!(s.contains("act>0.100"));
        assert!(s.contains("fam=bspline"));
    }
}
