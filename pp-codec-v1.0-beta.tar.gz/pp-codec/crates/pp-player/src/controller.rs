//! # Controllers — Intent dispatch and state mutation
//! Ref: modMVC §3.3-3.6 (8 controllers + RootController)
#![forbid(unsafe_code)]

use std::time::Instant;
use pp_codec::encoder::{encode_video, decode_video, PpvFile};
use pp_codec::decoder::PpvDecoder;
use pp_codec::stv_uri::StvUri;

use crate::state::*;
use crate::intent::Intent;
use crate::view::*;
use crate::adapter;

// ═══════════════════════════════════════════════
// ROOT CONTROLLER
// ═══════════════════════════════════════════════

/// Routes each Intent to the appropriate specialized controller.
pub struct RootController;

impl RootController {
    pub fn dispatch(state: &mut AppState, intent: Intent) -> Vec<ViewUpdate> {
        match intent {
            // File
            Intent::OpenFile(path) => FileController::open_file(state, &path),
            Intent::OpenUri(uri) => FileController::open_uri(state, &uri),
            Intent::CloseFile => FileController::close(state),

            // Playback
            Intent::Play => PlaybackController::play(state),
            Intent::Pause => PlaybackController::pause(state),
            Intent::TogglePlay => PlaybackController::toggle(state),
            Intent::Seek(t) => PlaybackController::seek(state, t),
            Intent::SetSpeed(s) => PlaybackController::set_speed(state, s),

            // Zoom
            Intent::ZoomToRegion(rect) => ZoomController::zoom_to(state, rect),
            Intent::SetZoomFactor(f) => ZoomController::set_factor(state, f),
            Intent::ResetZoom => ZoomController::reset(state),

            // Palette
            Intent::SetPaletteMode(m) => PaletteController::set_mode(state, m),

            // Selection
            Intent::SelectBlock(id) => SelectionController::select(state, id),
            Intent::DeselectBlock => SelectionController::deselect(state),
            Intent::ToggleIntensityOverlay => SelectionController::toggle_overlay(state),

            // Query
            Intent::ExecuteQuery(expr) => QueryController::execute(state, expr),
            Intent::ClearQueryResults => QueryController::clear(state),
            Intent::ExportResults(fmt) => QueryController::export(state, fmt),

            // Encode
            Intent::StartEncode(params) => EncodeController::start(state, params),
            Intent::CancelEncode => vec![ViewUpdate::Notification("Encode cancelled".into())],

            // Navigation
            Intent::CopyCurrentUri => NavigationController::copy_uri(state),
            Intent::NavigateToUri(uri) => NavigationController::navigate(state, &uri),
        }
    }
}

// ═══════════════════════════════════════════════
// FILE CONTROLLER
// ═══════════════════════════════════════════════

struct FileController;

impl FileController {
    fn open_file(state: &mut AppState, path: &str) -> Vec<ViewUpdate> {
        let data = match std::fs::read(path) {
            Ok(d) => d,
            Err(e) => return vec![ViewUpdate::Notification(format!("Error: {}", e))],
        };
        let ppv = match PpvFile::deserialize(&data) {
            Some(p) => p,
            None => return vec![ViewUpdate::Notification("Invalid .ppv file".into())],
        };

        let bs = ppv.block_size;
        let bx = (ppv.width + bs - 1) / bs;
        let by = (ppv.height + bs - 1) / bs;

        state.file_loaded = true;
        state.file_path = Some(path.to_string());
        state.header = Some(PpvHeader {
            width: ppv.width, height: ppv.height, frames: ppv.frames,
            block_size: bs, palette_size: ppv.palette_size,
            num_blocks: bx * by, blocks_x: bx, blocks_y: by,
        });
        state.ppv_bytes = Some(data);
        state.current_frame = 0;
        state.playing = false;

        // Decode first frame for immediate display
        let frame_vm = adapter::decode_frame_vm(state, 0);
        let status_vm = adapter::build_status(state);

        let mut updates = vec![
            ViewUpdate::StatusBar(status_vm),
            ViewUpdate::Notification(format!("Opened: {} ({}×{}, {} frames)",
                path, ppv.width, ppv.height, ppv.frames)),
        ];
        if let Some(fvm) = frame_vm {
            updates.insert(0, ViewUpdate::Frame(fvm));
        }
        updates
    }

    fn open_uri(state: &mut AppState, uri_str: &str) -> Vec<ViewUpdate> {
        match StvUri::parse(uri_str) {
            Ok(uri) => {
                // Extract file path from URI and open
                let path = uri.path.clone();
                let mut updates = Self::open_file(state, &path);
                // Apply fragment (seek to t, zoom, etc.)
                if let Some(ref t) = uri.fragment.t {
                    match t {
                        pp_codec::stv_uri::FrameRange::Single(frame) => {
                            let seek_updates = PlaybackController::seek(state, *frame as u32);
                            updates.extend(seek_updates);
                        }
                        pp_codec::stv_uri::FrameRange::Interval(start, _) => {
                            let seek_updates = PlaybackController::seek(state, *start as u32);
                            updates.extend(seek_updates);
                        }
                    }
                }
                updates
            }
            Err(e) => vec![ViewUpdate::Notification(format!("Invalid URI: {}", e))],
        }
    }

    fn close(state: &mut AppState) -> Vec<ViewUpdate> {
        *state = AppState::default();
        vec![
            ViewUpdate::FullFrameRedraw,
            ViewUpdate::StatusBar(adapter::build_status(state)),
            ViewUpdate::Notification("File closed".into()),
        ]
    }
}

// ═══════════════════════════════════════════════
// PLAYBACK CONTROLLER (modMVC §3.4)
// ═══════════════════════════════════════════════

struct PlaybackController;

impl PlaybackController {
    fn play(state: &mut AppState) -> Vec<ViewUpdate> {
        state.playing = true;
        vec![ViewUpdate::PlaybackState(true)]
    }

    fn pause(state: &mut AppState) -> Vec<ViewUpdate> {
        state.playing = false;
        vec![ViewUpdate::PlaybackState(false)]
    }

    fn toggle(state: &mut AppState) -> Vec<ViewUpdate> {
        state.playing = !state.playing;
        vec![ViewUpdate::PlaybackState(state.playing)]
    }

    /// Seek to frame t with O(1) random access (T9).
    fn seek(state: &mut AppState, t: u32) -> Vec<ViewUpdate> {
        let max_t = state.total_frames().saturating_sub(1);
        state.current_frame = t.min(max_t);

        let mut updates = vec![
            ViewUpdate::TimelineCursor(state.current_frame),
            ViewUpdate::StatusBar(adapter::build_status(state)),
        ];

        if let Some(fvm) = adapter::decode_frame_vm(state, state.current_frame) {
            updates.insert(0, ViewUpdate::Frame(fvm));
        }
        updates
    }

    fn set_speed(state: &mut AppState, speed: f64) -> Vec<ViewUpdate> {
        state.playback_speed = speed.clamp(0.25, 8.0);
        vec![ViewUpdate::SpeedLabel(state.playback_speed)]
    }
}

// ═══════════════════════════════════════════════
// ZOOM CONTROLLER (modMVC §3.5)
// ═══════════════════════════════════════════════

struct ZoomController;

impl ZoomController {
    fn zoom_to(state: &mut AppState, rect: Rect) -> Vec<ViewUpdate> {
        state.zoom.active = true;
        state.zoom.region = rect;
        state.lod_current = (state.zoom.factor as f64).log2().ceil() as u8;
        vec![
            ViewUpdate::ZoomPanel(state.zoom.clone()),
            ViewUpdate::StatusBar(adapter::build_status(state)),
        ]
    }

    fn set_factor(state: &mut AppState, factor: u32) -> Vec<ViewUpdate> {
        state.zoom.factor = factor.clamp(1, 16);
        state.lod_current = (state.zoom.factor as f64).log2().ceil() as u8;
        if state.zoom.factor == 1 {
            state.zoom.active = false;
        }
        vec![
            ViewUpdate::ZoomPanel(state.zoom.clone()),
            ViewUpdate::StatusBar(adapter::build_status(state)),
        ]
    }

    fn reset(state: &mut AppState) -> Vec<ViewUpdate> {
        state.zoom = ZoomState::default();
        state.lod_current = 0;
        vec![
            ViewUpdate::ZoomPanel(state.zoom.clone()),
            ViewUpdate::FullFrameRedraw,
            ViewUpdate::StatusBar(adapter::build_status(state)),
        ]
    }
}

// ═══════════════════════════════════════════════
// PALETTE CONTROLLER
// ═══════════════════════════════════════════════

struct PaletteController;

impl PaletteController {
    fn set_mode(state: &mut AppState, mode: PaletteMode) -> Vec<ViewUpdate> {
        state.palette_mode = mode;
        // Re-render current frame with new palette
        let mut updates = vec![ViewUpdate::StatusBar(adapter::build_status(state))];
        if let Some(fvm) = adapter::decode_frame_vm(state, state.current_frame) {
            updates.insert(0, ViewUpdate::Frame(fvm));
        }
        updates
    }
}

// ═══════════════════════════════════════════════
// SELECTION CONTROLLER
// ═══════════════════════════════════════════════

struct SelectionController;

impl SelectionController {
    fn select(state: &mut AppState, block_id: usize) -> Vec<ViewUpdate> {
        state.selected_block = Some(block_id);
        let mut updates = Vec::new();
        if let Some(info_vm) = adapter::build_block_info(state, block_id) {
            updates.push(ViewUpdate::BlockInfo(info_vm));
        }
        updates.push(ViewUpdate::StatusBar(adapter::build_status(state)));
        updates
    }

    fn deselect(state: &mut AppState) -> Vec<ViewUpdate> {
        state.selected_block = None;
        state.intensity_overlay = false;
        vec![ViewUpdate::ClearHighlights]
    }

    fn toggle_overlay(state: &mut AppState) -> Vec<ViewUpdate> {
        state.intensity_overlay = !state.intensity_overlay;
        if state.intensity_overlay {
            if let Some(bid) = state.selected_block {
                let curve = adapter::build_intensity_curve(state, bid);
                return vec![ViewUpdate::IntensityOverlay(curve)];
            }
        }
        vec![ViewUpdate::ClearHighlights]
    }
}

// ═══════════════════════════════════════════════
// QUERY CONTROLLER (modMVC §3.6)
// ═══════════════════════════════════════════════

struct QueryController;

impl QueryController {
    fn execute(state: &mut AppState, expr: QueryExpr) -> Vec<ViewUpdate> {
        let start = Instant::now();

        let ppv = match state.ppv_bytes.as_ref().and_then(|b| PpvFile::deserialize(b)) {
            Some(p) => p,
            None => return vec![ViewUpdate::Notification("No file loaded".into())],
        };

        // Evaluate query on block metadata (T15: compressed-domain)
        let header = state.header.as_ref().unwrap();
        let avg_bits: f64 = ppv.block_bits.iter().sum::<usize>() as f64
            / ppv.block_bits.len().max(1) as f64;

        let mut matches = Vec::new();
        for (i, &bits) in ppv.block_bits.iter().enumerate() {
            let activity = bits as f64 / avg_bits.max(1.0);
            let bx = i as u32 % header.blocks_x;
            let by = i as u32 / header.blocks_x;

            let mut pass = true;
            if let Some(thr) = expr.act_threshold {
                if activity < thr { pass = false; }
            }
            if let Some(t_start) = expr.t_start {
                // Block-level temporal filtering would need block headers
                // For now, all blocks pass temporal filters
                let _ = t_start;
            }
            if pass {
                matches.push(BlockMatchRow {
                    block_id: i, bx, by,
                    n_total: bits as u32,
                    family: "bspline".into(),
                    activity,
                });
            }
        }

        let exec_ms = start.elapsed().as_secs_f64() * 1000.0;
        let block_ids: Vec<usize> = matches.iter().map(|m| m.block_id).collect();

        let qr = QueryResultState {
            matches: matches.clone(),
            total_count: matches.len(),
            exec_ms,
            expression: expr.to_string(),
        };
        state.query_results = Some(qr);

        let vm = QueryResultViewModel {
            matches,
            total_count: block_ids.len(),
            exec_ms,
            expression_text: expr.to_string(),
        };

        vec![
            ViewUpdate::QueryResults(vm),
            ViewUpdate::HighlightBlocks(block_ids),
        ]
    }

    fn clear(state: &mut AppState) -> Vec<ViewUpdate> {
        state.query_results = None;
        vec![ViewUpdate::ClearHighlights]
    }

    fn export(state: &mut AppState, fmt: ExportFormat) -> Vec<ViewUpdate> {
        if let Some(ref qr) = state.query_results {
            let data = match fmt {
                ExportFormat::Csv => {
                    let mut csv = "block_id,bx,by,n_total,family,activity\n".to_string();
                    for m in &qr.matches {
                        csv += &format!("{},{},{},{},{},{:.4}\n",
                            m.block_id, m.bx, m.by, m.n_total, m.family, m.activity);
                    }
                    csv
                }
                ExportFormat::Json => {
                    format!("{{\"count\":{},\"matches\":[{}]}}",
                        qr.total_count,
                        qr.matches.iter().map(|m| format!(
                            "{{\"id\":{},\"bx\":{},\"by\":{},\"n\":{},\"act\":{:.4}}}",
                            m.block_id, m.bx, m.by, m.n_total, m.activity
                        )).collect::<Vec<_>>().join(","))
                }
            };
            vec![ViewUpdate::Notification(format!("Exported {} results ({} bytes)",
                qr.total_count, data.len()))]
        } else {
            vec![ViewUpdate::Notification("No results to export".into())]
        }
    }
}

// ═══════════════════════════════════════════════
// ENCODE CONTROLLER
// ═══════════════════════════════════════════════

struct EncodeController;

impl EncodeController {
    fn start(_state: &mut AppState, params: EncodeParams) -> Vec<ViewUpdate> {
        // In the real implementation, this would spawn an async task.
        // For now, return a notification.
        vec![ViewUpdate::Notification(format!(
            "Encoding started: {} → {} ({}×{}, palette {})",
            params.source_path, params.output_path,
            params.block_size, params.block_size, params.palette_size
        ))]
    }
}

// ═══════════════════════════════════════════════
// NAVIGATION CONTROLLER
// ═══════════════════════════════════════════════

struct NavigationController;

impl NavigationController {
    fn copy_uri(state: &AppState) -> Vec<ViewUpdate> {
        let frag = state.current_uri_fragment();
        let uri = if let Some(ref path) = state.file_path {
            format!("ppv://local{}#{}", path, frag)
        } else {
            format!("ppv://local/unknown#{}", frag)
        };
        vec![ViewUpdate::CopyToClipboard(uri)]
    }

    fn navigate(state: &mut AppState, uri_str: &str) -> Vec<ViewUpdate> {
        match StvUri::parse(uri_str) {
            Ok(uri) => {
                let mut updates = Vec::new();
                if let Some(ref t) = uri.fragment.t {
                    match t {
                        pp_codec::stv_uri::FrameRange::Single(frame) => {
                            updates.extend(PlaybackController::seek(state, *frame as u32));
                        }
                        pp_codec::stv_uri::FrameRange::Interval(start, _) => {
                            updates.extend(PlaybackController::seek(state, *start as u32));
                        }
                    }
                }
                if let Some(ref b) = uri.fragment.b {
                    if let pp_codec::stv_uri::BlockRegion::Single(bx, by) = b {
                        if let Some(ref h) = state.header {
                            let bid = (*by * h.blocks_x + *bx) as usize;
                            updates.extend(SelectionController::select(state, bid));
                        }
                    }
                }
                updates
            }
            Err(e) => vec![ViewUpdate::Notification(format!("Invalid URI: {}", e))],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_test_state() -> AppState {
        // Create a small .ppv file and load it into state
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();

        let mut state = AppState::default();
        state.file_loaded = true;
        state.file_path = Some("/test.ppv".into());
        state.header = Some(PpvHeader {
            width: 8, height: 8, frames: 16, block_size: 8,
            palette_size: 4, num_blocks: 1, blocks_x: 1, blocks_y: 1,
        });
        state.ppv_bytes = Some(bytes);
        state
    }

    #[test]
    fn test_play_pause_toggle() {
        let mut s = make_test_state();
        assert!(!s.playing);

        let u = RootController::dispatch(&mut s, Intent::Play);
        assert!(s.playing);
        assert!(matches!(u[0], ViewUpdate::PlaybackState(true)));

        let u = RootController::dispatch(&mut s, Intent::Pause);
        assert!(!s.playing);
        assert!(matches!(u[0], ViewUpdate::PlaybackState(false)));

        let u = RootController::dispatch(&mut s, Intent::TogglePlay);
        assert!(s.playing);
    }

    #[test]
    fn test_seek() {
        let mut s = make_test_state();
        let u = RootController::dispatch(&mut s, Intent::Seek(5));
        assert_eq!(s.current_frame, 5);
        // Should have Frame + TimelineCursor + StatusBar
        assert!(u.iter().any(|v| matches!(v, ViewUpdate::TimelineCursor(5))));
        assert!(u.iter().any(|v| matches!(v, ViewUpdate::StatusBar(_))));
    }

    #[test]
    fn test_seek_clamp() {
        let mut s = make_test_state();
        RootController::dispatch(&mut s, Intent::Seek(9999));
        assert_eq!(s.current_frame, 15); // clamped to max
    }

    #[test]
    fn test_speed() {
        let mut s = make_test_state();
        RootController::dispatch(&mut s, Intent::SetSpeed(4.0));
        assert_eq!(s.playback_speed, 4.0);

        RootController::dispatch(&mut s, Intent::SetSpeed(100.0));
        assert_eq!(s.playback_speed, 8.0); // clamped
    }

    #[test]
    fn test_zoom() {
        let mut s = make_test_state();
        let r = Rect { x: 0.1, y: 0.2, w: 0.5, h: 0.3 };
        RootController::dispatch(&mut s, Intent::ZoomToRegion(r));
        assert!(s.zoom.active);
        assert_eq!(s.zoom.region.x, 0.1);

        RootController::dispatch(&mut s, Intent::SetZoomFactor(4));
        assert_eq!(s.zoom.factor, 4);
        assert_eq!(s.lod_current, 2); // ceil(log2(4))

        RootController::dispatch(&mut s, Intent::ResetZoom);
        assert!(!s.zoom.active);
        assert_eq!(s.zoom.factor, 1);
    }

    #[test]
    fn test_palette() {
        let mut s = make_test_state();
        RootController::dispatch(&mut s, Intent::SetPaletteMode(PaletteMode::Heatmap));
        assert_eq!(s.palette_mode, PaletteMode::Heatmap);
    }

    #[test]
    fn test_select_deselect() {
        let mut s = make_test_state();
        RootController::dispatch(&mut s, Intent::SelectBlock(0));
        assert_eq!(s.selected_block, Some(0));

        RootController::dispatch(&mut s, Intent::DeselectBlock);
        assert_eq!(s.selected_block, None);
    }

    #[test]
    fn test_query() {
        let mut s = make_test_state();
        let expr = QueryExpr {
            select_type: "blocks".into(),
            act_threshold: Some(0.0),
            t_start: None, t_end: None,
            color_filter: None, family_filter: None,
        };
        let u = RootController::dispatch(&mut s, Intent::ExecuteQuery(expr));
        assert!(u.iter().any(|v| matches!(v, ViewUpdate::QueryResults(_))));
        assert!(u.iter().any(|v| matches!(v, ViewUpdate::HighlightBlocks(_))));
        assert!(s.query_results.is_some());
    }

    #[test]
    fn test_query_export_csv() {
        let mut s = make_test_state();
        let expr = QueryExpr {
            select_type: "blocks".into(), act_threshold: Some(0.0),
            t_start: None, t_end: None, color_filter: None, family_filter: None,
        };
        RootController::dispatch(&mut s, Intent::ExecuteQuery(expr));

        let u = RootController::dispatch(&mut s, Intent::ExportResults(ExportFormat::Csv));
        assert!(u.iter().any(|v| matches!(v, ViewUpdate::Notification(_))));
    }

    #[test]
    fn test_copy_uri() {
        let mut s = make_test_state();
        s.current_frame = 42;
        let u = RootController::dispatch(&mut s, Intent::CopyCurrentUri);
        if let ViewUpdate::CopyToClipboard(uri) = &u[0] {
            assert!(uri.contains("t=42"));
        } else { panic!("expected CopyToClipboard"); }
    }

    #[test]
    fn test_close_resets() {
        let mut s = make_test_state();
        s.current_frame = 10;
        s.playing = true;
        RootController::dispatch(&mut s, Intent::CloseFile);
        assert!(!s.file_loaded);
        assert_eq!(s.current_frame, 0);
        assert!(!s.playing);
    }

    #[test]
    fn test_full_lifecycle() {
        let mut s = AppState::default();
        // Can't open real file in test, but we can test with pre-loaded state
        let mut s = make_test_state();

        RootController::dispatch(&mut s, Intent::Play);
        assert!(s.playing);

        RootController::dispatch(&mut s, Intent::Seek(5));
        assert_eq!(s.current_frame, 5);

        RootController::dispatch(&mut s, Intent::SetSpeed(2.0));
        assert_eq!(s.playback_speed, 2.0);

        RootController::dispatch(&mut s, Intent::ZoomToRegion(Rect { x: 0.0, y: 0.0, w: 0.5, h: 0.5 }));
        assert!(s.zoom.active);

        RootController::dispatch(&mut s, Intent::SelectBlock(0));
        assert_eq!(s.selected_block, Some(0));

        RootController::dispatch(&mut s, Intent::ExecuteQuery(QueryExpr {
            select_type: "blocks".into(), act_threshold: Some(0.5),
            t_start: None, t_end: None, color_filter: None, family_filter: None,
        }));
        assert!(s.query_results.is_some());

        RootController::dispatch(&mut s, Intent::ResetZoom);
        assert!(!s.zoom.active);

        RootController::dispatch(&mut s, Intent::CloseFile);
        assert!(!s.file_loaded);
    }
}
