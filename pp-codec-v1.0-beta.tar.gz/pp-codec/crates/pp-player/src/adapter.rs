//! # Data Adapters — Model → ViewModel transformations
//! Pure functions, no side effects. Ref: modMVC §5, DA-01 to DA-07
#![forbid(unsafe_code)]

use pp_codec::encoder::{decode_video, PpvFile};
use pp_codec::decoder::PpvDecoder;

use crate::state::*;
use crate::view::*;

/// DA-01: FrameAdapter — decode frame t and apply palette mode.
/// Produces RGBA pixels ready for GPU upload.
pub fn decode_frame_vm(state: &AppState, t: u32) -> Option<FrameViewModel> {
    let ppv_bytes = state.ppv_bytes.as_ref()?;
    let header = state.header.as_ref()?;
    let ppv = PpvFile::deserialize(ppv_bytes)?;
    let decoder = PpvDecoder::from_bytes(ppv_bytes)?;

    let frame_data = decoder.decode_frame(t)?;
    let w = header.width;
    let h = header.height;
    let npx = (w * h) as usize;

    // Convert palette indices to RGBA using palette mode
    let mut pixels = Vec::with_capacity(npx * 4);
    for &idx in frame_data.iter().take(npx) {
        let (r, g, b) = match state.palette_mode {
            PaletteMode::Original => palette_index_to_rgb(idx, header.palette_size),
            PaletteMode::Grayscale => {
                let (r, g, b) = palette_index_to_rgb(idx, header.palette_size);
                let gray = ((r as u16 * 30 + g as u16 * 59 + b as u16 * 11) / 100) as u8;
                (gray, gray, gray)
            }
            PaletteMode::Heatmap => {
                let ratio = idx as f64 / header.palette_size.max(1) as f64;
                heatmap_color(ratio)
            }
            PaletteMode::FalseColor => {
                let hue = (idx as f64 / header.palette_size.max(1) as f64) * 360.0;
                hsv_to_rgb(hue, 0.8, 0.9)
            }
        };
        pixels.push(r);
        pixels.push(g);
        pixels.push(b);
        pixels.push(255); // alpha
    }

    Some(FrameViewModel {
        pixels,
        width: w,
        height: h,
        frame_index: t,
        updated_regions: vec![], // full frame for now
    })
}

/// DA-02: BlockInfoAdapter — build block info panel data.
pub fn build_block_info(state: &AppState, block_id: usize) -> Option<BlockInfoViewModel> {
    let ppv_bytes = state.ppv_bytes.as_ref()?;
    let header = state.header.as_ref()?;
    let ppv = PpvFile::deserialize(ppv_bytes)?;

    if block_id >= ppv.block_data.len() { return None; }

    let bx = block_id as u32 % header.blocks_x;
    let by = block_id as u32 / header.blocks_x;
    let bits = ppv.block_bits[block_id];
    let avg_bits: f64 = ppv.block_bits.iter().sum::<usize>() as f64
        / ppv.block_bits.len().max(1) as f64;
    let activity = bits as f64 / avg_bits.max(1.0);

    // Build synthetic palette colors for display
    let k = header.palette_size.min(16);
    let palette_colors: Vec<Color> = (0..k).map(|i| {
        let (r, g, b) = palette_index_to_rgb(i, k);
        Color::rgb(r, g, b)
    }).collect();

    // Synthetic intensity curve (in production, decoded from coefficients)
    let r = header.frames as usize;
    let intensity_curve: Vec<f64> = (0..r).map(|t| {
        let phase = t as f64 / r as f64 * std::f64::consts::PI * 2.0;
        (activity * (1.0 + 0.3 * phase.sin())) / 2.0
    }).collect();

    Some(BlockInfoViewModel {
        block_id,
        bx, by,
        n_total: bits as u32,
        k_colors: k,
        activity_ratio: activity,
        family_name: "bspline_K6".into(),
        framework_name: "Vector".into(),
        palette_colors,
        intensity_curve,
    })
}

/// DA-03: TimelineAdapter — build heatmap data.
/// Returns matrix [block_id][frame] of activity values.
pub fn build_timeline_heatmap(state: &AppState) -> Option<Vec<Vec<f32>>> {
    let ppv_bytes = state.ppv_bytes.as_ref()?;
    let header = state.header.as_ref()?;
    let ppv = PpvFile::deserialize(ppv_bytes)?;

    let nb = ppv.block_data.len();
    let r = header.frames as usize;
    let avg_bits: f64 = ppv.block_bits.iter().sum::<usize>() as f64
        / nb.max(1) as f64;

    let heatmap: Vec<Vec<f32>> = (0..nb).map(|bid| {
        let activity = ppv.block_bits[bid] as f64 / avg_bits.max(1.0);
        // Distribute activity across frames (synthetic)
        (0..r).map(|_t| activity as f32).collect()
    }).collect();

    Some(heatmap)
}

/// DA-05: Build intensity curve for a block (overlay).
pub fn build_intensity_curve(state: &AppState, block_id: usize) -> Vec<f64> {
    let r = state.total_frames() as usize;
    if r == 0 { return vec![]; }
    // Synthetic curve (in production: reconstruct α̂(t) from MDL coefficients)
    (0..r).map(|t| {
        let phase = t as f64 / r as f64 * std::f64::consts::PI * 2.0;
        0.5 + 0.3 * phase.sin()
    }).collect()
}

/// DA-07: StatusAdapter — compose status bar labels.
pub fn build_status(state: &AppState) -> StatusViewModel {
    let total = state.total_frames();
    StatusViewModel {
        frame_str: if total > 0 { format!("{} / {}", state.current_frame, total) } else { "—".into() },
        ratio_str: "—".into(), // computed from actual compression in production
        lod_str: format!("N{}", state.lod_current),
        lod_level: state.lod_current,
        uri_str: if state.file_loaded {
            format!("ppv://local{}#{}",
                state.file_path.as_deref().unwrap_or("/"),
                state.current_uri_fragment())
        } else { "—".into() },
        resolution_str: state.resolution_str(),
        palette_mode: state.palette_mode,
        speed: state.playback_speed,
    }
}

// ═══ Color conversion helpers ═══

/// Map palette index to RGB (deterministic rainbow-ish mapping).
fn palette_index_to_rgb(idx: u32, m: u32) -> (u8, u8, u8) {
    if m <= 1 { return (128, 128, 128); }
    if idx == 0 { return (0, 0, 0); } // index 0 = black (background)
    let hue = (idx as f64 / m as f64) * 300.0 + 30.0; // avoid pure red
    hsv_to_rgb(hue, 0.85, 0.95)
}

/// HSV to RGB conversion.
fn hsv_to_rgb(h: f64, s: f64, v: f64) -> (u8, u8, u8) {
    let c = v * s;
    let x = c * (1.0 - ((h / 60.0) % 2.0 - 1.0).abs());
    let m = v - c;
    let (r, g, b) = if h < 60.0 { (c, x, 0.0) }
        else if h < 120.0 { (x, c, 0.0) }
        else if h < 180.0 { (0.0, c, x) }
        else if h < 240.0 { (0.0, x, c) }
        else if h < 300.0 { (x, 0.0, c) }
        else { (c, 0.0, x) };
    (((r + m) * 255.0) as u8, ((g + m) * 255.0) as u8, ((b + m) * 255.0) as u8)
}

/// Heatmap color: 0.0 = blue, 0.5 = green, 1.0 = red.
fn heatmap_color(ratio: f64) -> (u8, u8, u8) {
    let r = ratio.clamp(0.0, 1.0);
    if r < 0.5 {
        let t = r * 2.0;
        (0, (t * 255.0) as u8, ((1.0 - t) * 255.0) as u8)
    } else {
        let t = (r - 0.5) * 2.0;
        ((t * 255.0) as u8, ((1.0 - t) * 255.0) as u8, 0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pp_codec::encoder::encode_video;

    fn make_state() -> AppState {
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let mut s = AppState::default();
        s.file_loaded = true;
        s.header = Some(PpvHeader {
            width: 8, height: 8, frames: 16, block_size: 8,
            palette_size: 4, num_blocks: 1, blocks_x: 1, blocks_y: 1,
        });
        s.ppv_bytes = Some(bytes);
        s
    }

    #[test]
    fn test_decode_frame_vm() {
        let s = make_state();
        let vm = decode_frame_vm(&s, 0).unwrap();
        assert_eq!(vm.width, 8);
        assert_eq!(vm.height, 8);
        assert_eq!(vm.pixels.len(), 8 * 8 * 4); // RGBA
    }

    #[test]
    fn test_decode_frame_vm_grayscale() {
        let mut s = make_state();
        s.palette_mode = PaletteMode::Grayscale;
        let vm = decode_frame_vm(&s, 0).unwrap();
        // Check that RGB channels are equal (grayscale)
        for i in (0..vm.pixels.len()).step_by(4) {
            assert_eq!(vm.pixels[i], vm.pixels[i+1]);
            assert_eq!(vm.pixels[i+1], vm.pixels[i+2]);
        }
    }

    #[test]
    fn test_build_block_info() {
        let s = make_state();
        let info = build_block_info(&s, 0).unwrap();
        assert_eq!(info.block_id, 0);
        assert_eq!(info.bx, 0);
        assert_eq!(info.by, 0);
        assert!(!info.palette_colors.is_empty());
        assert_eq!(info.intensity_curve.len(), 16); // r frames
    }

    #[test]
    fn test_build_status() {
        let mut s = make_state();
        s.current_frame = 5;
        let st = build_status(&s);
        assert_eq!(st.frame_str, "5 / 16");
        assert_eq!(st.lod_str, "N0");
        assert_eq!(st.resolution_str, "8×8");
    }

    #[test]
    fn test_heatmap_endpoints() {
        assert_eq!(heatmap_color(0.0), (0, 0, 255)); // blue
        assert_eq!(heatmap_color(1.0), (255, 0, 0));  // red
    }

    #[test]
    fn test_intensity_curve() {
        let s = make_state();
        let curve = build_intensity_curve(&s, 0);
        assert_eq!(curve.len(), 16);
        assert!(curve.iter().all(|&v| v >= 0.0 && v <= 1.0));
    }
}
