//! # PP-Player — Native video player for .ppv files
//! Usage: pp-player [file.ppv]
//! Ref: planDEV S17-S20, modSFD PLY, modMVC
#![forbid(unsafe_code)]

pub mod state;
pub mod intent;
pub mod view;
pub mod controller;
pub mod adapter;

use state::AppState;
use intent::Intent;
use view::{ViewRenderer, SoftwareRenderer, ViewUpdate};
use controller::RootController;

/// MVC main loop (modMVC §4.3 — 5 steps).
fn main_loop(
    state: &mut AppState,
    view: &mut dyn ViewRenderer,
    max_frames: Option<u64>,
) {
    let mut frame = 0u64;
    loop {
        // 1. Capture user intents (V → C)
        let intents = view.poll_intents();

        // 2. Dispatch each intent and collect updates (C → V)
        let mut all_updates: Vec<ViewUpdate> = Vec::new();
        for intent in intents {
            let updates = RootController::dispatch(state, intent);
            all_updates.extend(updates);
        }

        // 3. Advance playback if playing
        if state.playing && state.file_loaded {
            let max_t = state.total_frames().saturating_sub(1);
            if state.current_frame < max_t {
                state.current_frame += 1;
                if let Some(fvm) = adapter::decode_frame_vm(state, state.current_frame) {
                    all_updates.push(ViewUpdate::Frame(fvm));
                }
                all_updates.push(ViewUpdate::TimelineCursor(state.current_frame));
                all_updates.push(ViewUpdate::StatusBar(adapter::build_status(state)));
            } else {
                state.playing = false;
                all_updates.push(ViewUpdate::PlaybackState(false));
            }
        }

        // 4. Apply updates to the view (C → V)
        if !all_updates.is_empty() {
            view.apply_updates(&all_updates);
        }

        // 5. Render
        view.render();

        frame += 1;
        if view.should_quit() { break; }
        if let Some(max) = max_frames {
            if frame >= max { break; }
        }
    }
}

fn main() {
    println!("╔═══════════════════════════════════════════════╗");
    println!("║  PP-Player v0.1 — MVC Architecture           ║");
    println!("║  PP-CODEC FORGE v2.0                         ║");
    println!("╚═══════════════════════════════════════════════╝");
    println!();

    let args: Vec<String> = std::env::args().collect();

    let mut state = AppState::default();
    let mut view = SoftwareRenderer::new(640, 480);

    // If file argument provided, queue an OpenFile intent
    if args.len() > 1 {
        view.pending_intents.push(Intent::OpenFile(args[1].clone()));
    }

    println!("  MVC loop running (software renderer)...");
    println!("  Use --file <path.ppv> to open a file");
    println!();

    // Run for a limited number of frames in CLI mode
    main_loop(&mut state, &mut view, Some(100));

    if let Some(ref status) = view.last_status {
        println!("  Final status: {} | {} | LOD {} | {}",
            status.frame_str, status.resolution_str, status.lod_str, status.uri_str);
    }
    println!("  Rendered {} frames", view.frame_count);
}

#[cfg(test)]
mod tests {
    use super::*;
    use state::*;
    use intent::Intent;
    use view::SoftwareRenderer;

    fn make_test_ppv() -> Vec<u8> {
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p + t) % 10 == 0 { 1 } else { 0 }).collect()
        }).collect();
        let ppv = pp_codec::encoder::encode_video(&frames, 8, 8, 8, 4);
        ppv.serialize()
    }

    #[test]
    fn test_mvc_loop_empty() {
        let mut state = AppState::default();
        let mut view = SoftwareRenderer::new(8, 8);
        main_loop(&mut state, &mut view, Some(10));
        assert_eq!(view.frame_count, 10);
    }

    #[test]
    fn test_mvc_loop_with_intents() {
        let ppv_bytes = make_test_ppv();
        let mut state = AppState::default();
        state.file_loaded = true;
        state.file_path = Some("/test.ppv".into());
        state.header = Some(PpvHeader {
            width: 8, height: 8, frames: 16, block_size: 8,
            palette_size: 4, num_blocks: 1, blocks_x: 1, blocks_y: 1,
        });
        state.ppv_bytes = Some(ppv_bytes);

        let mut view = SoftwareRenderer::new(8, 8);

        // Queue intents
        view.pending_intents.push(Intent::Play);
        view.pending_intents.push(Intent::SetSpeed(2.0));
        view.pending_intents.push(Intent::Seek(5));

        main_loop(&mut state, &mut view, Some(20));

        // After 20 loop iterations with Play: should have advanced frames
        assert!(state.current_frame > 5);
        assert_eq!(state.playback_speed, 2.0);
        assert!(view.frame_count >= 20);
    }

    #[test]
    fn test_mvc_loop_playback_stops_at_end() {
        let ppv_bytes = make_test_ppv();
        let mut state = AppState::default();
        state.file_loaded = true;
        state.header = Some(PpvHeader {
            width: 8, height: 8, frames: 16, block_size: 8,
            palette_size: 4, num_blocks: 1, blocks_x: 1, blocks_y: 1,
        });
        state.ppv_bytes = Some(ppv_bytes);
        state.current_frame = 14;
        state.playing = true;

        let mut view = SoftwareRenderer::new(8, 8);
        main_loop(&mut state, &mut view, Some(5));

        // Should have stopped playing at frame 15
        assert_eq!(state.current_frame, 15);
        assert!(!state.playing);
    }
}
