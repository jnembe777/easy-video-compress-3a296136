//! # Intent — Typed user actions (V → C)
//! Ref: modMVC §3.2 — 22 Intent variants
#![forbid(unsafe_code)]

use crate::state::{PaletteMode, Rect, QueryExpr, EncodeParams, ExportFormat};

/// All possible user actions in the application.
/// Views emit Intents; the RootController dispatches them.
#[derive(Debug, Clone)]
pub enum Intent {
    // ── File ──
    OpenFile(String),                   // path to .ppv file
    OpenUri(String),                    // STV-URI string
    CloseFile,

    // ── Playback (SFD-PLY-001) ──
    Play,
    Pause,
    TogglePlay,
    Seek(u32),                          // frame index
    SetSpeed(f64),                      // 0.25, 0.5, 1.0, 2.0, 4.0, 8.0

    // ── Zoom (SFD-PLY-002, SFD-BRW-002) ──
    ZoomToRegion(Rect),
    SetZoomFactor(u32),                 // 1..16
    ResetZoom,

    // ── Palette (SFD-PLY-001) ──
    SetPaletteMode(PaletteMode),

    // ── Block selection (SFD-PLY-004) ──
    SelectBlock(usize),                 // block_id
    DeselectBlock,
    ToggleIntensityOverlay,

    // ── Query (SFD-PLY-005, SFD-BRW-004) ──
    ExecuteQuery(QueryExpr),
    ClearQueryResults,
    ExportResults(ExportFormat),

    // ── Encoding (SFD-PLY-006) ──
    StartEncode(EncodeParams),
    CancelEncode,

    // ── Navigation ──
    CopyCurrentUri,
    NavigateToUri(String),
}
