//! # ViewUpdate — Controller → View messages
//! Ref: modMVC §4.1 (18 variants), §4.2 (ViewRenderer trait)
#![forbid(unsafe_code)]

use crate::state::{ZoomState, EncodeSummary, BlockMatchRow, PaletteMode};
use crate::intent::Intent;

/// RGBA color.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl Color {
    pub fn rgb(r: u8, g: u8, b: u8) -> Self { Color { r, g, b, a: 255 } }
    pub fn black() -> Self { Color::rgb(0, 0, 0) }
}

/// Rectangular region in pixel coordinates.
#[derive(Debug, Clone, Copy)]
pub struct PixelRect {
    pub x: u32,
    pub y: u32,
    pub w: u32,
    pub h: u32,
}

// ═══════════════════════════════════════════════
// VIEW MODELS (adapted data ready for display)
// ═══════════════════════════════════════════════

/// ViewModel for the viewport (SFD-PLY-001, DA-01).
#[derive(Debug, Clone)]
pub struct FrameViewModel {
    pub pixels: Vec<u8>,               // RGBA, w*h*4 bytes
    pub width: u32,
    pub height: u32,
    pub frame_index: u32,
    pub updated_regions: Vec<PixelRect>, // dirty regions for incremental render
}

/// ViewModel for block info panel (SFD-PLY-004, DA-02).
#[derive(Debug, Clone)]
pub struct BlockInfoViewModel {
    pub block_id: usize,
    pub bx: u32,
    pub by: u32,
    pub n_total: u32,
    pub k_colors: u32,
    pub activity_ratio: f64,
    pub family_name: String,
    pub framework_name: String,
    pub palette_colors: Vec<Color>,
    pub intensity_curve: Vec<f64>,      // α̂(t) sampled over [0, r]
}

/// ViewModel for status bar (SFD-PLY-001 status, DA-07).
#[derive(Debug, Clone)]
pub struct StatusViewModel {
    pub frame_str: String,              // "120 / 1024"
    pub ratio_str: String,              // "109.2:1"
    pub lod_str: String,                // "N2"
    pub lod_level: u8,
    pub uri_str: String,                // "ppv://cam/feed.ppv#t=120"
    pub resolution_str: String,         // "1920×1080"
    pub palette_mode: PaletteMode,
    pub speed: f64,
}

/// ViewModel for query results (SFD-PLY-005, DA-04).
#[derive(Debug, Clone)]
pub struct QueryResultViewModel {
    pub matches: Vec<BlockMatchRow>,
    pub total_count: usize,
    pub exec_ms: f64,
    pub expression_text: String,
}

// ═══════════════════════════════════════════════
// VIEW UPDATES (C → V messages)
// ═══════════════════════════════════════════════

/// All possible updates the Controller can send to the View.
#[derive(Debug, Clone)]
pub enum ViewUpdate {
    // ── Viewport (SFD-PLY-001, SFD-BRW-001) ──
    Frame(FrameViewModel),
    BlockRegion(usize, Vec<u8>),         // partial update: block_id + RGBA data
    FullFrameRedraw,

    // ── Controls ──
    PlaybackState(bool),                 // true = playing
    SpeedLabel(f64),
    TimelineCursor(u32),
    StatusBar(StatusViewModel),

    // ── Panels ──
    ZoomPanel(ZoomState),
    BlockInfo(BlockInfoViewModel),
    IntensityOverlay(Vec<f64>),          // α̂(t) curve to overlay on viewport

    // ── Query ──
    QueryResults(QueryResultViewModel),
    HighlightBlocks(Vec<usize>),         // block_ids to highlight on viewport
    ClearHighlights,

    // ── Encoding ──
    EncodeProgress { percent: f32, ratio: f64, blocks_done: u32 },
    EncodeComplete(EncodeSummary),

    // ── Streaming ──
    ConnectionStatus(bool),

    // ── Utilities ──
    Notification(String),
    CopyToClipboard(String),
}

// ═══════════════════════════════════════════════
// VIEW RENDERER TRAIT
// ═══════════════════════════════════════════════

/// Interface that each rendering backend implements.
/// PP-Player: wgpu + egui. PP-Browser: WebGPU + Custom Elements. PP-Admin: React.
pub trait ViewRenderer {
    /// Apply a batch of updates from the Controller.
    fn apply_updates(&mut self, updates: &[ViewUpdate]);

    /// Render the current frame (called each display frame).
    fn render(&mut self);

    /// Poll user interactions and return Intents.
    fn poll_intents(&mut self) -> Vec<Intent>;

    /// Check if the application should quit.
    fn should_quit(&self) -> bool;
}

/// Software renderer for testing (no GPU dependency).
pub struct SoftwareRenderer {
    pub framebuffer: Vec<u8>,           // RGBA
    pub width: u32,
    pub height: u32,
    pub frame_count: u64,
    pub last_status: Option<StatusViewModel>,
    pub last_notification: Option<String>,
    pub highlighted_blocks: Vec<usize>,
    pub pending_intents: Vec<Intent>,
    pub quit: bool,
}

impl SoftwareRenderer {
    pub fn new(width: u32, height: u32) -> Self {
        let size = (width * height * 4) as usize;
        SoftwareRenderer {
            framebuffer: vec![0; size],
            width, height,
            frame_count: 0,
            last_status: None,
            last_notification: None,
            highlighted_blocks: Vec::new(),
            pending_intents: Vec::new(),
            quit: false,
        }
    }
}

impl ViewRenderer for SoftwareRenderer {
    fn apply_updates(&mut self, updates: &[ViewUpdate]) {
        for update in updates {
            match update {
                ViewUpdate::Frame(vm) => {
                    if vm.pixels.len() == self.framebuffer.len() {
                        self.framebuffer.copy_from_slice(&vm.pixels);
                    }
                }
                ViewUpdate::StatusBar(s) => {
                    self.last_status = Some(s.clone());
                }
                ViewUpdate::Notification(msg) => {
                    self.last_notification = Some(msg.clone());
                }
                ViewUpdate::HighlightBlocks(ids) => {
                    self.highlighted_blocks = ids.clone();
                }
                ViewUpdate::ClearHighlights => {
                    self.highlighted_blocks.clear();
                }
                ViewUpdate::CopyToClipboard(_s) => {
                    // In software renderer, just store it
                }
                _ => {}  // Other updates are visual-only
            }
        }
    }

    fn render(&mut self) {
        self.frame_count += 1;
    }

    fn poll_intents(&mut self) -> Vec<Intent> {
        std::mem::take(&mut self.pending_intents)
    }

    fn should_quit(&self) -> bool {
        self.quit
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_software_renderer_frame() {
        let mut r = SoftwareRenderer::new(4, 4);
        let pixels = vec![255u8; 64]; // 4x4 RGBA = 64 bytes
        let vm = FrameViewModel {
            pixels: pixels.clone(),
            width: 4, height: 4, frame_index: 0,
            updated_regions: vec![],
        };
        r.apply_updates(&[ViewUpdate::Frame(vm)]);
        assert_eq!(r.framebuffer, pixels);
    }

    #[test]
    fn test_software_renderer_status() {
        let mut r = SoftwareRenderer::new(4, 4);
        let s = StatusViewModel {
            frame_str: "42/128".into(), ratio_str: "109:1".into(),
            lod_str: "N0".into(), lod_level: 0,
            uri_str: "ppv://cam/f.ppv#t=42".into(),
            resolution_str: "1920×1080".into(),
            palette_mode: PaletteMode::Original,
            speed: 1.0,
        };
        r.apply_updates(&[ViewUpdate::StatusBar(s)]);
        assert!(r.last_status.is_some());
        assert_eq!(r.last_status.as_ref().unwrap().frame_str, "42/128");
    }

    #[test]
    fn test_software_renderer_intents() {
        let mut r = SoftwareRenderer::new(4, 4);
        r.pending_intents.push(Intent::Play);
        r.pending_intents.push(Intent::Seek(42));
        let intents = r.poll_intents();
        assert_eq!(intents.len(), 2);
        assert!(r.poll_intents().is_empty()); // drained
    }
}
