//! # PPSP Client — connection state machine for the browser
//! Ref: PPSP 1.0 §3.2, modMOT T13-T14
#![forbid(unsafe_code)]

use pp_codec::ppsp::*;

/// Client connection state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClientState {
    Disconnected,
    Connecting,     // OPEN sent, awaiting HEADER
    Open,           // HEADER received, ready for SEEK/QUERY
    Error,
}

/// Outgoing message queued for WebSocket send.
#[derive(Debug, Clone)]
pub struct OutgoingMessage {
    pub data: Vec<u8>,          // serialized PPSP message
    pub msg_type: MsgType,
}

/// Incoming parsed response.
#[derive(Debug, Clone)]
pub enum ServerResponse {
    Header {
        session_id: u64,
        width: u32,height: u32,frames: u32,
        block_size: u32,palette_size: u32,num_blocks: u32,
    },
    Data { block_id: u32, lod: u8, frame_start: u32, frame_end: u32, data: Vec<u8> },
    Result { request_id: u64, total_count: u32, matches: Vec<BlockMatch> },
    Error { code: u16, message: String },
    CloseAck { message: String },
}

/// PPSP Client — manages connection state and message queue.
#[derive(Debug)]
pub struct PpspClient {
    pub state: ClientState,
    pub session_id: Option<u64>,
    pub uri: String,
    pub access: AccessLevel,
    outbox: Vec<OutgoingMessage>,
    pub seeks_sent: u32,
    pub queries_sent: u32,
    pub data_received: u64,
}

impl PpspClient {
    pub fn new() -> Self {
        PpspClient {
            state: ClientState::Disconnected,
            session_id: None,
            uri: String::new(),
            access: AccessLevel::Read,
            outbox: Vec::new(),
            seeks_sent: 0,
            queries_sent: 0,
            data_received: 0,
        }
    }

    /// Initiate connection: queue OPEN message.
    pub fn connect(&mut self, uri: &str, access: AccessLevel) {
        self.uri = uri.to_string();
        self.access = access;
        self.state = ClientState::Connecting;

        let msg = PpspMessage::Open(OpenMsg {
            uri: uri.to_string(),
            access,
        });
        self.outbox.push(OutgoingMessage {
            data: msg.serialize(),
            msg_type: MsgType::Open,
        });
    }

    /// Send a SEEK message (update viewport).
    pub fn seek(&mut self, fragment: &str) -> bool {
        let sid = match self.session_id {
            Some(id) if self.state == ClientState::Open => id,
            _ => return false,
        };
        let msg = PpspMessage::Seek(SeekMsg {
            session_id: sid,
            fragment: fragment.to_string(),
        });
        self.outbox.push(OutgoingMessage {
            data: msg.serialize(),
            msg_type: MsgType::Seek,
        });
        self.seeks_sent += 1;
        true
    }

    /// Send a QUERY message.
    pub fn query(&mut self, select: SelectType, expression: &str) -> bool {
        let sid = match self.session_id {
            Some(id) if self.state == ClientState::Open => id,
            _ => return false,
        };
        let msg = PpspMessage::Query(QueryMsg {
            session_id: sid,
            select,
            expression: expression.to_string(),
        });
        self.outbox.push(OutgoingMessage {
            data: msg.serialize(),
            msg_type: MsgType::Query,
        });
        self.queries_sent += 1;
        true
    }

    /// Send CLOSE message.
    pub fn close(&mut self) -> bool {
        let sid = match self.session_id {
            Some(id) => id,
            None => return false,
        };
        let msg = PpspMessage::Close(CloseMsg { session_id: sid });
        self.outbox.push(OutgoingMessage {
            data: msg.serialize(),
            msg_type: MsgType::Close,
        });
        true
    }

    /// Process an incoming server message. Returns parsed response.
    pub fn receive(&mut self, data: &[u8]) -> Option<ServerResponse> {
        let msg = PpspMessage::deserialize(data)?;

        match msg {
            PpspMessage::Header(h) => {
                self.session_id = Some(h.session_id);
                self.state = ClientState::Open;
                Some(ServerResponse::Header {
                    session_id: h.session_id,
                    width: h.width, height: h.height, frames: h.frames,
                    block_size: h.block_size, palette_size: h.palette_size,
                    num_blocks: h.num_blocks,
                })
            }
            PpspMessage::Data(d) => {
                self.data_received += d.data.len() as u64;
                Some(ServerResponse::Data {
                    block_id: d.block_id, lod: d.lod,
                    frame_start: d.frame_start, frame_end: d.frame_end,
                    data: d.data,
                })
            }
            PpspMessage::Result(r) => {
                Some(ServerResponse::Result {
                    request_id: r.request_id,
                    total_count: r.total_count,
                    matches: r.matches,
                })
            }
            PpspMessage::Error(e) => {
                if e.code == 200 {
                    // Close acknowledgment
                    self.state = ClientState::Disconnected;
                    self.session_id = None;
                    Some(ServerResponse::CloseAck { message: e.message })
                } else {
                    if self.state == ClientState::Connecting {
                        self.state = ClientState::Error;
                    }
                    Some(ServerResponse::Error { code: e.code, message: e.message })
                }
            }
            _ => None,
        }
    }

    /// Drain outgoing message queue.
    pub fn drain_outbox(&mut self) -> Vec<OutgoingMessage> {
        std::mem::take(&mut self.outbox)
    }

    /// Is the client in a usable state?
    pub fn is_connected(&self) -> bool {
        self.state == ClientState::Open
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_initial_state() {
        let c = PpspClient::new();
        assert_eq!(c.state, ClientState::Disconnected);
        assert!(c.session_id.is_none());
    }

    #[test]
    fn test_connect_queues_open() {
        let mut c = PpspClient::new();
        c.connect("ppv://cam/feed.ppv", AccessLevel::Query);
        assert_eq!(c.state, ClientState::Connecting);

        let msgs = c.drain_outbox();
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].msg_type, MsgType::Open);

        // Verify the message is valid PPSP
        let parsed = PpspMessage::deserialize(&msgs[0].data).unwrap();
        assert!(matches!(parsed, PpspMessage::Open(_)));
    }

    #[test]
    fn test_receive_header() {
        let mut c = PpspClient::new();
        c.connect("ppv://cam/f.ppv", AccessLevel::Read);

        let header = PpspMessage::Header(HeaderMsg {
            session_id: 42, width: 640, height: 480, frames: 128,
            block_size: 16, palette_size: 8, num_blocks: 1200,
        });
        let resp = c.receive(&header.serialize()).unwrap();

        assert_eq!(c.state, ClientState::Open);
        assert_eq!(c.session_id, Some(42));
        if let ServerResponse::Header { width, .. } = resp {
            assert_eq!(width, 640);
        } else { panic!("expected Header"); }
    }

    #[test]
    fn test_seek_requires_open() {
        let mut c = PpspClient::new();
        assert!(!c.seek("t=100")); // not connected

        c.connect("ppv://cam/f.ppv", AccessLevel::Read);
        assert!(!c.seek("t=100")); // connecting, not open

        // Simulate header received
        let header = PpspMessage::Header(HeaderMsg {
            session_id: 1, width: 640, height: 480, frames: 128,
            block_size: 16, palette_size: 8, num_blocks: 1200,
        });
        c.receive(&header.serialize());
        c.drain_outbox(); // drain OPEN

        assert!(c.seek("t=100")); // now it works
        let msgs = c.drain_outbox();
        assert_eq!(msgs.len(), 1);
        assert_eq!(msgs[0].msg_type, MsgType::Seek);
    }

    #[test]
    fn test_receive_data() {
        let mut c = PpspClient::new();
        c.state = ClientState::Open;
        c.session_id = Some(1);

        let data_msg = PpspMessage::Data(DataMsg {
            block_id: 5, lod: 2, frame_start: 0, frame_end: 127,
            data: vec![0xDE, 0xAD, 0xBE, 0xEF],
        });
        let resp = c.receive(&data_msg.serialize()).unwrap();

        if let ServerResponse::Data { block_id, lod, data, .. } = resp {
            assert_eq!(block_id, 5);
            assert_eq!(lod, 2);
            assert_eq!(data.len(), 4);
        } else { panic!("expected Data"); }
        assert_eq!(c.data_received, 4);
    }

    #[test]
    fn test_query() {
        let mut c = PpspClient::new();
        c.state = ClientState::Open;
        c.session_id = Some(1);

        assert!(c.query(SelectType::Blocks, "activity > 0.1"));
        let msgs = c.drain_outbox();
        assert_eq!(msgs[0].msg_type, MsgType::Query);
        assert_eq!(c.queries_sent, 1);
    }

    #[test]
    fn test_close_and_ack() {
        let mut c = PpspClient::new();
        c.state = ClientState::Open;
        c.session_id = Some(42);

        assert!(c.close());
        let msgs = c.drain_outbox();
        assert_eq!(msgs[0].msg_type, MsgType::Close);

        // Receive close ACK
        let ack = PpspMessage::Error(ErrorMsg { code: 200, message: "closed".into() });
        let resp = c.receive(&ack.serialize()).unwrap();
        assert!(matches!(resp, ServerResponse::CloseAck { .. }));
        assert_eq!(c.state, ClientState::Disconnected);
        assert!(c.session_id.is_none());
    }

    #[test]
    fn test_error_during_connect() {
        let mut c = PpspClient::new();
        c.connect("ppv://cam/missing.ppv", AccessLevel::Read);

        let err = PpspMessage::Error(ErrorMsg { code: 404, message: "not found".into() });
        let resp = c.receive(&err.serialize()).unwrap();
        assert!(matches!(resp, ServerResponse::Error { code: 404, .. }));
        assert_eq!(c.state, ClientState::Error);
    }

    #[test]
    fn test_full_session_lifecycle() {
        let mut c = PpspClient::new();

        // 1. Connect
        c.connect("ppv://cam/feed.ppv#t=0:64", AccessLevel::Query);
        assert_eq!(c.state, ClientState::Connecting);
        let msgs = c.drain_outbox();
        assert_eq!(msgs.len(), 1);

        // 2. Receive header
        let hdr = PpspMessage::Header(HeaderMsg {
            session_id: 99, width: 320, height: 240, frames: 64,
            block_size: 16, palette_size: 8, num_blocks: 300,
        });
        c.receive(&hdr.serialize());
        assert_eq!(c.state, ClientState::Open);

        // 3. Seek
        assert!(c.seek("t=0:32&lod=N1"));
        assert_eq!(c.seeks_sent, 1);

        // 4. Receive data blocks
        for i in 0..5 {
            let d = PpspMessage::Data(DataMsg {
                block_id: i, lod: 1, frame_start: 0, frame_end: 31,
                data: vec![i as u8; 100],
            });
            c.receive(&d.serialize());
        }
        assert_eq!(c.data_received, 500);

        // 5. Query
        assert!(c.query(SelectType::Blocks, "activity > 0.5"));
        assert_eq!(c.queries_sent, 1);

        // 6. Close
        c.close();
        let ack = PpspMessage::Error(ErrorMsg { code: 200, message: "done".into() });
        c.receive(&ack.serialize());
        assert_eq!(c.state, ClientState::Disconnected);
    }
}
