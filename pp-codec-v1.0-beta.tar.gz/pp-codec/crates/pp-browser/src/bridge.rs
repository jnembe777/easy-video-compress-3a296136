//! # WASM Bridge — Rust ↔ JavaScript interop layer
//!
//! In production, these functions are exported via wasm-bindgen.
//! In test context, they run as pure Rust with JSON serialization.
//!
//! The bridge pattern (modMVC §6.2):
//! 1. JS dispatches CustomEvent('ppintent', {detail: intent_json})
//! 2. WASM handle_intent(json) → calls RootController → returns ViewUpdate JSON
//! 3. JS applyUpdates(json) → updates DOM / WebGPU
//!
//! Ref: modMVC §6.2 (PP-Browser wasm-bindgen liaison)
#![forbid(unsafe_code)]

use pp_codec::encoder::{decode_video, PpvFile};
use pp_codec::decoder::PpvDecoder;
use pp_codec::stv_uri::{StvUri, resolve};
use serde::{Serialize, Deserialize};

/// Intent from JavaScript (simplified JSON protocol).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum JsIntent {
    #[serde(rename = "open")]
    Open { uri: String },
    #[serde(rename = "seek")]
    Seek { frame: u32 },
    #[serde(rename = "zoom")]
    Zoom { factor: u32, region: [f64; 4] },
    #[serde(rename = "reset_zoom")]
    ResetZoom,
    #[serde(rename = "query")]
    Query { select: String, expression: String },
    #[serde(rename = "info")]
    Info,
    #[serde(rename = "resolve_uri")]
    ResolveUri { uri: String },
}

/// Response to JavaScript.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum JsResponse {
    #[serde(rename = "header")]
    Header {
        width: u32, height: u32, frames: u32,
        block_size: u32, palette_size: u32, num_blocks: u32,
    },
    #[serde(rename = "frame")]
    Frame {
        frame_index: u32,
        width: u32, height: u32,
        pixel_count: usize,
        // In WASM, pixels would be a SharedArrayBuffer reference.
        // In test mode, we just report the count.
    },
    #[serde(rename = "extraction_plan")]
    ExtractionPlan {
        block_ids: Vec<usize>,
        lod: u8,
        frame_start: u32,
        frame_end: u32,
        num_blocks: usize,
    },
    #[serde(rename = "query_result")]
    QueryResult {
        count: u32,
        blocks: Vec<QueryBlock>,
    },
    #[serde(rename = "error")]
    Error { message: String },
    #[serde(rename = "status")]
    Status { message: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueryBlock {
    pub block_id: usize,
    pub bx: u32,
    pub by: u32,
    pub activity: f64,
}

/// WASM-side state holding the loaded .ppv file.
pub struct WasmState {
    pub ppv_bytes: Option<Vec<u8>>,
    pub width: u32,
    pub height: u32,
    pub frames: u32,
    pub block_size: u32,
    pub palette_size: u32,
    pub num_blocks: u32,
}

impl WasmState {
    pub fn new() -> Self {
        WasmState {
            ppv_bytes: None,
            width: 0, height: 0, frames: 0,
            block_size: 0, palette_size: 0, num_blocks: 0,
        }
    }

    /// Load a .ppv file from bytes (called after fetch or PPSP HEADER+DATA).
    pub fn load(&mut self, data: Vec<u8>) -> Result<JsResponse, String> {
        let ppv = PpvFile::deserialize(&data)
            .ok_or_else(|| "invalid .ppv file".to_string())?;
        let bs = ppv.block_size;
        let bx = (ppv.width + bs - 1) / bs;
        let by = (ppv.height + bs - 1) / bs;
        self.width = ppv.width;
        self.height = ppv.height;
        self.frames = ppv.frames;
        self.block_size = bs;
        self.palette_size = ppv.palette_size;
        self.num_blocks = bx * by;
        self.ppv_bytes = Some(data);
        Ok(JsResponse::Header {
            width: self.width, height: self.height, frames: self.frames,
            block_size: self.block_size, palette_size: self.palette_size,
            num_blocks: self.num_blocks,
        })
    }

    /// Handle an intent from JavaScript. Returns JSON-serializable response.
    pub fn handle_intent(&self, intent: &JsIntent) -> JsResponse {
        match intent {
            JsIntent::Open { uri } => {
                // In WASM: would initiate PPSP connection.
                // Here: parse URI and return status.
                match StvUri::parse(uri) {
                    Ok(parsed) => JsResponse::Status {
                        message: format!("connecting to {}{}",
                            parsed.authority, parsed.path),
                    },
                    Err(e) => JsResponse::Error { message: format!("{}", e) },
                }
            }
            JsIntent::Seek { frame } => {
                let bytes = match &self.ppv_bytes {
                    Some(b) => b,
                    None => return JsResponse::Error { message: "no file loaded".into() },
                };
                let decoder = match PpvDecoder::from_bytes(bytes) {
                    Some(d) => d,
                    None => return JsResponse::Error { message: "decoder error".into() },
                };
                match decoder.decode_frame(*frame) {
                    Some(frame_data) => JsResponse::Frame {
                        frame_index: *frame,
                        width: self.width,
                        height: self.height,
                        pixel_count: frame_data.len(),
                    },
                    None => JsResponse::Error {
                        message: format!("frame {} out of range", frame),
                    },
                }
            }
            JsIntent::Zoom { factor, region } => {
                let lod = if *factor <= 1 { 0 } else {
                    (*factor as f64).log2().ceil() as u8
                };
                JsResponse::Status {
                    message: format!("zoom ×{} lod=N{} region=[{:.2},{:.2},{:.2},{:.2}]",
                        factor, lod, region[0], region[1], region[2], region[3]),
                }
            }
            JsIntent::ResetZoom => {
                JsResponse::Status { message: "zoom reset to ×1".into() }
            }
            JsIntent::Info => {
                if self.ppv_bytes.is_none() {
                    return JsResponse::Error { message: "no file loaded".into() };
                }
                JsResponse::Header {
                    width: self.width, height: self.height, frames: self.frames,
                    block_size: self.block_size, palette_size: self.palette_size,
                    num_blocks: self.num_blocks,
                }
            }
            JsIntent::ResolveUri { uri } => {
                match StvUri::parse(uri) {
                    Ok(parsed) => {
                        let plan = resolve(&parsed.fragment,
                            self.width, self.height, self.frames, self.block_size);
                        JsResponse::ExtractionPlan {
                            block_ids: plan.block_ids.clone(),
                            lod: plan.lod,
                            frame_start: plan.frame_range.0,
                            frame_end: plan.frame_range.1,
                            num_blocks: plan.block_ids.len(),
                        }
                    }
                    Err(e) => JsResponse::Error { message: format!("{}", e) },
                }
            }
            JsIntent::Query { select: _, expression } => {
                let bytes = match &self.ppv_bytes {
                    Some(b) => b,
                    None => return JsResponse::Error { message: "no file loaded".into() },
                };
                let ppv = match PpvFile::deserialize(bytes) {
                    Some(p) => p,
                    None => return JsResponse::Error { message: "decode error".into() },
                };
                let avg: f64 = ppv.block_bits.iter().sum::<usize>() as f64
                    / ppv.block_bits.len().max(1) as f64;
                let bx_count = (self.width + self.block_size - 1) / self.block_size;
                let threshold = extract_act_threshold(expression).unwrap_or(0.0);

                let blocks: Vec<QueryBlock> = ppv.block_bits.iter().enumerate()
                    .filter_map(|(i, &bits)| {
                        let act = bits as f64 / avg.max(1.0);
                        if act >= threshold {
                            Some(QueryBlock {
                                block_id: i,
                                bx: i as u32 % bx_count,
                                by: i as u32 / bx_count,
                                activity: act,
                            })
                        } else { None }
                    })
                    .collect();

                JsResponse::QueryResult {
                    count: blocks.len() as u32,
                    blocks,
                }
            }
        }
    }

    /// Handle intent from JSON string. Returns JSON string response.
    /// This is the actual function that wasm-bindgen would export.
    pub fn handle_intent_json(&self, json: &str) -> String {
        match serde_json::from_str::<JsIntent>(json) {
            Ok(intent) => {
                let resp = self.handle_intent(&intent);
                serde_json::to_string(&resp).unwrap_or_else(|e| {
                    format!(r#"{{"type":"error","message":"{}"}}"#, e)
                })
            }
            Err(e) => {
                format!(r#"{{"type":"error","message":"invalid intent: {}"}}"#, e)
            }
        }
    }
}

fn extract_act_threshold(expr: &str) -> Option<f64> {
    let lower = expr.to_lowercase();
    if let Some(pos) = lower.find("activity") {
        let after = &lower[pos + 8..];
        let after = after.trim_start_matches(|c: char| c == ' ' || c == '>' || c == '=');
        let num: String = after.chars().take_while(|c| c.is_ascii_digit() || *c == '.').collect();
        num.parse().ok()
    } else { None }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pp_codec::encoder::encode_video;

    fn make_state() -> WasmState {
        let frames: Vec<Vec<u32>> = (0..16).map(|t| {
            (0..64).map(|p| if (p+t)%10==0 {1} else {0}).collect()
        }).collect();
        let ppv = encode_video(&frames, 8, 8, 8, 4);
        let bytes = ppv.serialize();
        let mut ws = WasmState::new();
        ws.load(bytes).unwrap();
        ws
    }

    #[test]
    fn test_load() {
        let ws = make_state();
        assert_eq!(ws.width, 8);
        assert_eq!(ws.height, 8);
        assert_eq!(ws.frames, 16);
    }

    #[test]
    fn test_seek() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::Seek { frame: 5 });
        if let JsResponse::Frame { frame_index, pixel_count, .. } = resp {
            assert_eq!(frame_index, 5);
            assert_eq!(pixel_count, 64); // 8×8
        } else { panic!("expected Frame, got {:?}", resp); }
    }

    #[test]
    fn test_info() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::Info);
        assert!(matches!(resp, JsResponse::Header { width: 8, .. }));
    }

    #[test]
    fn test_resolve_uri() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::ResolveUri {
            uri: "ppv://cam/feed.ppv#t=5:10&lod=N2".into(),
        });
        if let JsResponse::ExtractionPlan { frame_start, frame_end, lod, .. } = resp {
            assert_eq!(frame_start, 5);
            assert_eq!(frame_end, 10);
            assert_eq!(lod, 2);
        } else { panic!("expected ExtractionPlan"); }
    }

    #[test]
    fn test_query() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::Query {
            select: "blocks".into(),
            expression: "activity > 0.5".into(),
        });
        if let JsResponse::QueryResult { count, .. } = resp {
            assert!(count >= 0);
        } else { panic!("expected QueryResult"); }
    }

    #[test]
    fn test_json_roundtrip() {
        let ws = make_state();

        // Seek via JSON
        let json = r#"{"type":"seek","frame":3}"#;
        let resp_json = ws.handle_intent_json(json);
        assert!(resp_json.contains("frame"));
        assert!(resp_json.contains("pixel_count"));

        // Info via JSON
        let resp = ws.handle_intent_json(r#"{"type":"info"}"#);
        assert!(resp.contains("\"width\":8"));

        // Invalid JSON
        let resp = ws.handle_intent_json("not json");
        assert!(resp.contains("error"));
    }

    #[test]
    fn test_open_uri() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::Open {
            uri: "ppv://cam.local/feed.ppv".into(),
        });
        if let JsResponse::Status { message } = resp {
            assert!(message.contains("cam.local"));
        } else { panic!("expected Status"); }
    }

    #[test]
    fn test_zoom_lod() {
        let ws = make_state();
        let resp = ws.handle_intent(&JsIntent::Zoom {
            factor: 4,
            region: [0.0, 0.0, 0.25, 0.25],
        });
        if let JsResponse::Status { message } = resp {
            assert!(message.contains("×4"));
            assert!(message.contains("N2")); // ceil(log2(4)) = 2
        } else { panic!("expected Status"); }
    }

    #[test]
    fn test_error_no_file() {
        let ws = WasmState::new();
        let resp = ws.handle_intent(&JsIntent::Seek { frame: 0 });
        assert!(matches!(resp, JsResponse::Error { .. }));
    }
}
