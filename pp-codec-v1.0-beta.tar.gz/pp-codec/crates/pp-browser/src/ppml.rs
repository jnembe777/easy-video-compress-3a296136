//! # PPML 1.0 Engine — Custom Element registry and lifecycle
//!
//! Pure-Rust implementation of the 8 PPML primitives.
//! In WASM context, each element maps to a Custom Element via wasm-bindgen.
//! In test context, the engine runs standalone.
//!
//! Ref: specS PPML 1.0 §1.3.1-1.3.8
//!
//! ## The 8 PPML primitives
//! 1. `<pp-stream>`   — root viewport (SFD-BRW-001)
//! 2. `<pp-zoom>`     — zoom region (SFD-BRW-002)
//! 3. `<pp-pyramid>`  — progressive loading strategy (SFD-BRW-003)
//! 4. `<pp-query>`    — compressed-domain query (SFD-BRW-004)
//! 5. `<pp-palette>`  — palette override
//! 6. `<pp-event>`    — event listener for activity spikes
//! 7. `<pp-intensity>`— intensity overlay configuration
//! 8. `<pp-cube>`     — 3D spatio-temporal cube view

#![forbid(unsafe_code)]

use std::collections::HashMap;

/// PPML element tag names.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PpmlTag {
    PpStream,
    PpZoom,
    PpPyramid,
    PpQuery,
    PpPalette,
    PpEvent,
    PpIntensity,
    PpCube,
}

impl PpmlTag {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "pp-stream" => Some(Self::PpStream),
            "pp-zoom" => Some(Self::PpZoom),
            "pp-pyramid" => Some(Self::PpPyramid),
            "pp-query" => Some(Self::PpQuery),
            "pp-palette" => Some(Self::PpPalette),
            "pp-event" => Some(Self::PpEvent),
            "pp-intensity" => Some(Self::PpIntensity),
            "pp-cube" => Some(Self::PpCube),
            _ => None,
        }
    }

    pub fn tag_name(&self) -> &'static str {
        match self {
            Self::PpStream => "pp-stream",
            Self::PpZoom => "pp-zoom",
            Self::PpPyramid => "pp-pyramid",
            Self::PpQuery => "pp-query",
            Self::PpPalette => "pp-palette",
            Self::PpEvent => "pp-event",
            Self::PpIntensity => "pp-intensity",
            Self::PpCube => "pp-cube",
        }
    }
}

/// Lifecycle phase of a PPML element.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Lifecycle {
    Created,
    Connected,      // connectedCallback
    Disconnected,   // disconnectedCallback
    AttributeChanged,
}

/// A PPML element instance with its attributes.
#[derive(Debug, Clone)]
pub struct PpmlElement {
    pub id: u64,
    pub tag: PpmlTag,
    pub attrs: HashMap<String, String>,
    pub lifecycle: Lifecycle,
    pub children: Vec<u64>,     // child element IDs
    pub parent: Option<u64>,
}

impl PpmlElement {
    pub fn new(id: u64, tag: PpmlTag) -> Self {
        PpmlElement {
            id, tag,
            attrs: HashMap::new(),
            lifecycle: Lifecycle::Created,
            children: Vec::new(),
            parent: None,
        }
    }

    pub fn set_attr(&mut self, key: &str, value: &str) {
        self.attrs.insert(key.to_string(), value.to_string());
    }

    pub fn get_attr(&self, key: &str) -> Option<&str> {
        self.attrs.get(key).map(|s| s.as_str())
    }

    pub fn get_attr_f64(&self, key: &str) -> Option<f64> {
        self.get_attr(key)?.parse().ok()
    }

    pub fn get_attr_u32(&self, key: &str) -> Option<u32> {
        self.get_attr(key)?.parse().ok()
    }

    pub fn get_attr_bool(&self, key: &str) -> bool {
        self.attrs.contains_key(key)
    }
}

/// Events dispatched by PPML elements to JavaScript.
#[derive(Debug, Clone)]
pub enum PpmlEvent {
    /// <pp-stream> loaded its first frame (N₀)
    StreamLoaded { element_id: u64, width: u32, height: u32, frames: u32 },
    /// LOD level changed on a block
    LodChange { element_id: u64, block_id: u32, new_lod: u8 },
    /// Activity spike detected
    ActivitySpike { element_id: u64, block_id: u32, activity: f64 },
    /// Query completed
    QueryResult { element_id: u64, count: u32, exec_ms: f64 },
    /// Error occurred
    Error { element_id: u64, code: u16, message: String },
}

impl PpmlEvent {
    /// Event name for CustomEvent dispatch in JavaScript.
    pub fn event_name(&self) -> &'static str {
        match self {
            PpmlEvent::StreamLoaded { .. } => "ppstreamloaded",
            PpmlEvent::LodChange { .. } => "ppstreamlodchange",
            PpmlEvent::ActivitySpike { .. } => "ppstreamactivity",
            PpmlEvent::QueryResult { .. } => "ppqueryresult",
            PpmlEvent::Error { .. } => "ppstreamerror",
        }
    }

    /// Serialize event detail to JSON for CustomEvent.
    pub fn to_json(&self) -> String {
        match self {
            PpmlEvent::StreamLoaded { element_id, width, height, frames } =>
                format!(r#"{{"elementId":{},"width":{},"height":{},"frames":{}}}"#,
                    element_id, width, height, frames),
            PpmlEvent::LodChange { element_id, block_id, new_lod } =>
                format!(r#"{{"elementId":{},"blockId":{},"lod":{}}}"#,
                    element_id, block_id, new_lod),
            PpmlEvent::ActivitySpike { element_id, block_id, activity } =>
                format!(r#"{{"elementId":{},"blockId":{},"activity":{:.4}}}"#,
                    element_id, block_id, activity),
            PpmlEvent::QueryResult { element_id, count, exec_ms } =>
                format!(r#"{{"elementId":{},"count":{},"execMs":{:.2}}}"#,
                    element_id, count, exec_ms),
            PpmlEvent::Error { element_id, code, message } =>
                format!(r#"{{"elementId":{},"code":{},"message":"{}"}}"#,
                    element_id, code, message.replace('"', "\\\"")),
        }
    }
}

/// The PPML Element Registry — manages all active PPML elements.
#[derive(Debug, Default)]
pub struct PpmlRegistry {
    elements: HashMap<u64, PpmlElement>,
    next_id: u64,
    pending_events: Vec<PpmlEvent>,
}

impl PpmlRegistry {
    pub fn new() -> Self {
        Self { elements: HashMap::new(), next_id: 1, pending_events: Vec::new() }
    }

    /// Create and register a new PPML element.
    pub fn create(&mut self, tag: PpmlTag) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        self.elements.insert(id, PpmlElement::new(id, tag));
        id
    }

    /// Simulate connectedCallback.
    pub fn connect(&mut self, id: u64) {
        if let Some(el) = self.elements.get_mut(&id) {
            el.lifecycle = Lifecycle::Connected;
        }
    }

    /// Simulate disconnectedCallback.
    pub fn disconnect(&mut self, id: u64) {
        if let Some(el) = self.elements.get_mut(&id) {
            el.lifecycle = Lifecycle::Disconnected;
        }
    }

    /// Set attribute on an element.
    pub fn set_attribute(&mut self, id: u64, key: &str, value: &str) {
        if let Some(el) = self.elements.get_mut(&id) {
            el.set_attr(key, value);
            el.lifecycle = Lifecycle::AttributeChanged;
        }
    }

    /// Add a child element to a parent.
    pub fn add_child(&mut self, parent_id: u64, child_id: u64) {
        if let Some(child) = self.elements.get_mut(&child_id) {
            child.parent = Some(parent_id);
        }
        if let Some(parent) = self.elements.get_mut(&parent_id) {
            parent.children.push(child_id);
        }
    }

    /// Get element by ID.
    pub fn get(&self, id: u64) -> Option<&PpmlElement> {
        self.elements.get(&id)
    }

    /// Get mutable element.
    pub fn get_mut(&mut self, id: u64) -> Option<&mut PpmlElement> {
        self.elements.get_mut(&id)
    }

    /// Queue an event for dispatch.
    pub fn emit_event(&mut self, event: PpmlEvent) {
        self.pending_events.push(event);
    }

    /// Drain pending events.
    pub fn drain_events(&mut self) -> Vec<PpmlEvent> {
        std::mem::take(&mut self.pending_events)
    }

    /// Count elements by tag.
    pub fn count_by_tag(&self, tag: PpmlTag) -> usize {
        self.elements.values().filter(|e| e.tag == tag).count()
    }

    /// Count total elements.
    pub fn count(&self) -> usize {
        self.elements.len()
    }

    /// Find children of a given type under a parent.
    pub fn find_children(&self, parent_id: u64, tag: PpmlTag) -> Vec<u64> {
        if let Some(parent) = self.elements.get(&parent_id) {
            parent.children.iter()
                .filter(|&&cid| self.elements.get(&cid).map_or(false, |e| e.tag == tag))
                .copied()
                .collect()
        } else {
            vec![]
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tag_parse() {
        assert_eq!(PpmlTag::from_str("pp-stream"), Some(PpmlTag::PpStream));
        assert_eq!(PpmlTag::from_str("pp-zoom"), Some(PpmlTag::PpZoom));
        assert_eq!(PpmlTag::from_str("PP-QUERY"), Some(PpmlTag::PpQuery));
        assert_eq!(PpmlTag::from_str("div"), None);
    }

    #[test]
    fn test_element_attrs() {
        let mut el = PpmlElement::new(1, PpmlTag::PpStream);
        el.set_attr("src", "ppv://cam/feed.ppv");
        el.set_attr("width", "1920");
        el.set_attr("autoplay", "");

        assert_eq!(el.get_attr("src"), Some("ppv://cam/feed.ppv"));
        assert_eq!(el.get_attr_u32("width"), Some(1920));
        assert!(el.get_attr_bool("autoplay"));
        assert!(!el.get_attr_bool("loop"));
    }

    #[test]
    fn test_registry_lifecycle() {
        let mut reg = PpmlRegistry::new();
        let id = reg.create(PpmlTag::PpStream);
        assert_eq!(reg.get(id).unwrap().lifecycle, Lifecycle::Created);

        reg.connect(id);
        assert_eq!(reg.get(id).unwrap().lifecycle, Lifecycle::Connected);

        reg.set_attribute(id, "src", "ppv://x/y");
        assert_eq!(reg.get(id).unwrap().lifecycle, Lifecycle::AttributeChanged);
        assert_eq!(reg.get(id).unwrap().get_attr("src"), Some("ppv://x/y"));

        reg.disconnect(id);
        assert_eq!(reg.get(id).unwrap().lifecycle, Lifecycle::Disconnected);
    }

    #[test]
    fn test_parent_child() {
        let mut reg = PpmlRegistry::new();
        let stream_id = reg.create(PpmlTag::PpStream);
        let zoom_id = reg.create(PpmlTag::PpZoom);
        let pyramid_id = reg.create(PpmlTag::PpPyramid);
        let query_id = reg.create(PpmlTag::PpQuery);

        reg.add_child(stream_id, zoom_id);
        reg.add_child(stream_id, pyramid_id);
        reg.add_child(stream_id, query_id);

        assert_eq!(reg.get(zoom_id).unwrap().parent, Some(stream_id));
        assert_eq!(reg.find_children(stream_id, PpmlTag::PpZoom), vec![zoom_id]);
        assert_eq!(reg.find_children(stream_id, PpmlTag::PpPyramid), vec![pyramid_id]);
        assert_eq!(reg.get(stream_id).unwrap().children.len(), 3);
    }

    #[test]
    fn test_events() {
        let mut reg = PpmlRegistry::new();
        reg.emit_event(PpmlEvent::StreamLoaded {
            element_id: 1, width: 1920, height: 1080, frames: 128,
        });
        reg.emit_event(PpmlEvent::ActivitySpike {
            element_id: 1, block_id: 42, activity: 0.85,
        });

        let events = reg.drain_events();
        assert_eq!(events.len(), 2);
        assert_eq!(events[0].event_name(), "ppstreamloaded");
        assert_eq!(events[1].event_name(), "ppstreamactivity");

        // JSON serialization
        assert!(events[0].to_json().contains("1920"));
        assert!(events[1].to_json().contains("0.85"));

        // Events drained
        assert!(reg.drain_events().is_empty());
    }

    #[test]
    fn test_count_by_tag() {
        let mut reg = PpmlRegistry::new();
        reg.create(PpmlTag::PpStream);
        reg.create(PpmlTag::PpZoom);
        reg.create(PpmlTag::PpZoom);
        reg.create(PpmlTag::PpQuery);

        assert_eq!(reg.count_by_tag(PpmlTag::PpStream), 1);
        assert_eq!(reg.count_by_tag(PpmlTag::PpZoom), 2);
        assert_eq!(reg.count(), 4);
    }
}
