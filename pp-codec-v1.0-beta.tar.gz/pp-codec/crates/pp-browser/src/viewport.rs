//! # Viewport Manager — block visibility, LOD, cache, progressive loading
//! Ref: SFD-BRW-001 (pp-stream), SFD-BRW-002 (pp-zoom), SFD-BRW-003 (pp-pyramid)
#![forbid(unsafe_code)]

use std::collections::{HashMap, HashSet};

/// Progressive loading strategy (SFD-BRW-003 pp-pyramid).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoadStrategy {
    Eager,              // Load all LODs immediately
    Lazy,               // Only load on zoom
    BandwidthAdaptive,  // Measure bandwidth, load in background
}

impl Default for LoadStrategy {
    fn default() -> Self { Self::BandwidthAdaptive }
}

impl LoadStrategy {
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "eager" => Self::Eager,
            "lazy" => Self::Lazy,
            "bandwidth-adaptive" | "adaptive" => Self::BandwidthAdaptive,
            _ => Self::BandwidthAdaptive,
        }
    }
}

/// Priority mode for block loading.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoadPriority {
    ViewportFirst,  // Visible blocks first
    Sequential,     // Top-left to bottom-right
}

impl LoadPriority {
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "sequential" => Self::Sequential,
            _ => Self::ViewportFirst,
        }
    }
}

/// A block's cache state.
#[derive(Debug, Clone)]
pub struct BlockCache {
    pub block_id: usize,
    pub max_lod: u8,            // highest LOD level cached
    pub data_by_lod: HashMap<u8, Vec<u8>>,  // LOD → compressed block data
    pub decoded_pixels: Option<Vec<u8>>,     // RGBA pixels at current LOD
}

impl BlockCache {
    pub fn new(block_id: usize) -> Self {
        BlockCache {
            block_id,
            max_lod: 0,
            data_by_lod: HashMap::new(),
            decoded_pixels: None,
        }
    }

    pub fn has_lod(&self, lod: u8) -> bool {
        self.data_by_lod.contains_key(&lod)
    }

    pub fn store_lod(&mut self, lod: u8, data: Vec<u8>) {
        if lod > self.max_lod { self.max_lod = lod; }
        self.data_by_lod.insert(lod, data);
    }

    pub fn memory_bytes(&self) -> usize {
        self.data_by_lod.values().map(|d| d.len()).sum::<usize>()
            + self.decoded_pixels.as_ref().map_or(0, |p| p.len())
    }
}

/// Block request queued for the PPSP client.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct BlockRequest {
    pub block_id: usize,
    pub lod: u8,
    pub priority: u32,      // lower = higher priority
}

/// Viewport state: what the user currently sees.
#[derive(Debug, Clone)]
pub struct BrowserViewport {
    // Image dimensions
    pub width: u32,
    pub height: u32,
    pub block_size: u32,
    pub blocks_x: u32,
    pub blocks_y: u32,
    pub total_blocks: usize,

    // Current view
    pub zoom_factor: u32,           // 1..16
    pub zoom_region: [f64; 4],      // [x, y, w, h] normalized [0,1]
    pub current_frame: u32,
    pub total_frames: u32,

    // LOD
    pub target_lod: u8,             // computed from zoom_factor
    pub max_lod: u8,                // from pp-pyramid max-lod attribute

    // Strategy
    pub strategy: LoadStrategy,
    pub priority: LoadPriority,

    // Cache
    pub cache: HashMap<usize, BlockCache>,
    pub pending_requests: Vec<BlockRequest>,

    // Metrics
    pub blocks_loaded: u64,
    pub bytes_received: u64,
    pub cache_hits: u64,
    pub cache_misses: u64,
}

impl BrowserViewport {
    pub fn new(width: u32, height: u32, block_size: u32, total_frames: u32) -> Self {
        let blocks_x = (width + block_size - 1) / block_size;
        let blocks_y = (height + block_size - 1) / block_size;
        BrowserViewport {
            width, height, block_size, blocks_x, blocks_y,
            total_blocks: (blocks_x * blocks_y) as usize,
            zoom_factor: 1, zoom_region: [0.0, 0.0, 1.0, 1.0],
            current_frame: 0, total_frames,
            target_lod: 0, max_lod: 4,
            strategy: LoadStrategy::default(),
            priority: LoadPriority::ViewportFirst,
            cache: HashMap::new(),
            pending_requests: Vec::new(),
            blocks_loaded: 0, bytes_received: 0,
            cache_hits: 0, cache_misses: 0,
        }
    }

    /// Compute which blocks are visible in the current viewport.
    pub fn visible_blocks(&self) -> Vec<usize> {
        let [rx, ry, rw, rh] = self.zoom_region;
        let x0 = ((rx * self.width as f64) as u32) / self.block_size;
        let y0 = ((ry * self.height as f64) as u32) / self.block_size;
        let x1 = (((rx + rw) * self.width as f64).ceil() as u32 + self.block_size - 1) / self.block_size;
        let y1 = (((ry + rh) * self.height as f64).ceil() as u32 + self.block_size - 1) / self.block_size;

        let mut ids = Vec::new();
        for by in y0..y1.min(self.blocks_y) {
            for bx in x0..x1.min(self.blocks_x) {
                ids.push((by * self.blocks_x + bx) as usize);
            }
        }
        ids
    }

    /// Set zoom and recompute target LOD.
    pub fn set_zoom(&mut self, factor: u32, region: [f64; 4]) {
        self.zoom_factor = factor.clamp(1, 16);
        self.zoom_region = region;
        self.target_lod = if factor <= 1 { 0 }
            else { (factor as f64).log2().ceil() as u8 };
        self.target_lod = self.target_lod.min(self.max_lod);
    }

    /// Reset zoom to full view.
    pub fn reset_zoom(&mut self) {
        self.zoom_factor = 1;
        self.zoom_region = [0.0, 0.0, 1.0, 1.0];
        self.target_lod = 0;
    }

    /// Compute block requests: visible blocks at target LOD that aren't cached.
    pub fn compute_requests(&mut self) -> Vec<BlockRequest> {
        let visible = self.visible_blocks();
        let target = self.target_lod;
        let mut requests = Vec::new();

        for (priority, &block_id) in visible.iter().enumerate() {
            if let Some(cached) = self.cache.get(&block_id) {
                if cached.has_lod(target) {
                    self.cache_hits += 1;
                    continue;
                }
            }
            self.cache_misses += 1;
            requests.push(BlockRequest {
                block_id,
                lod: target,
                priority: priority as u32,
            });
        }

        // Also request background LODs if strategy is eager
        if self.strategy == LoadStrategy::Eager {
            for block_id in 0..self.total_blocks {
                for lod in 0..=self.max_lod {
                    if !self.cache.get(&block_id).map_or(false, |c| c.has_lod(lod)) {
                        requests.push(BlockRequest {
                            block_id, lod,
                            priority: 1000 + block_id as u32, // low priority
                        });
                    }
                }
            }
        }

        // Sort by priority
        requests.sort_by_key(|r| r.priority);
        self.pending_requests = requests.clone();
        requests
    }

    /// Receive block data from PPSP (called when DATA message arrives).
    pub fn receive_block(&mut self, block_id: usize, lod: u8, data: Vec<u8>) {
        let bytes = data.len() as u64;
        let entry = self.cache.entry(block_id).or_insert_with(|| BlockCache::new(block_id));
        entry.store_lod(lod, data);
        self.blocks_loaded += 1;
        self.bytes_received += bytes;

        // Remove from pending
        self.pending_requests.retain(|r| !(r.block_id == block_id && r.lod == lod));
    }

    /// Check if all visible blocks at target LOD are cached.
    pub fn is_view_complete(&self) -> bool {
        let visible = self.visible_blocks();
        visible.iter().all(|&bid| {
            self.cache.get(&bid).map_or(false, |c| c.has_lod(self.target_lod))
        })
    }

    /// Total cache memory usage in bytes.
    pub fn cache_memory(&self) -> usize {
        self.cache.values().map(|c| c.memory_bytes()).sum()
    }

    /// Cache hit ratio.
    pub fn hit_ratio(&self) -> f64 {
        let total = self.cache_hits + self.cache_misses;
        if total == 0 { 0.0 } else { self.cache_hits as f64 / total as f64 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_visible_blocks_full() {
        let vp = BrowserViewport::new(32, 32, 16, 64);
        // Default zoom = full view
        let vis = vp.visible_blocks();
        assert_eq!(vis.len(), 4); // 2x2 blocks
        assert_eq!(vis, vec![0, 1, 2, 3]);
    }

    #[test]
    fn test_visible_blocks_zoomed() {
        let mut vp = BrowserViewport::new(64, 64, 16, 64);
        // Zoom to top-left quarter
        vp.set_zoom(2, [0.0, 0.0, 0.5, 0.5]);
        let vis = vp.visible_blocks();
        // 64/16 = 4 blocks per axis, top-left quarter = blocks (0,0) (1,0) (0,1) (1,1)
        assert_eq!(vis.len(), 4);
        assert!(vis.contains(&0));
        assert!(vis.contains(&1));
    }

    #[test]
    fn test_lod_from_zoom() {
        let mut vp = BrowserViewport::new(64, 64, 16, 64);
        vp.set_zoom(1, [0.0, 0.0, 1.0, 1.0]);
        assert_eq!(vp.target_lod, 0);

        vp.set_zoom(4, [0.0, 0.0, 0.25, 0.25]);
        assert_eq!(vp.target_lod, 2); // ceil(log2(4))

        vp.set_zoom(8, [0.0, 0.0, 0.125, 0.125]);
        assert_eq!(vp.target_lod, 3);
    }

    #[test]
    fn test_cache_and_requests() {
        let mut vp = BrowserViewport::new(32, 32, 16, 64);
        let reqs = vp.compute_requests();
        assert_eq!(reqs.len(), 4); // 4 visible blocks, none cached

        // Receive 2 blocks
        vp.receive_block(0, 0, vec![1, 2, 3]);
        vp.receive_block(1, 0, vec![4, 5, 6]);

        let reqs = vp.compute_requests();
        assert_eq!(reqs.len(), 2); // only blocks 2, 3 still needed
        assert!(!vp.is_view_complete());

        // Receive remaining
        vp.receive_block(2, 0, vec![7]);
        vp.receive_block(3, 0, vec![8]);
        assert!(vp.is_view_complete());
    }

    #[test]
    fn test_cache_lod_upgrade() {
        let mut vp = BrowserViewport::new(32, 32, 16, 64);
        vp.receive_block(0, 0, vec![1, 2, 3]);
        assert!(vp.cache.get(&0).unwrap().has_lod(0));
        assert!(!vp.cache.get(&0).unwrap().has_lod(2));

        // Zoom in — need LOD 2
        vp.set_zoom(4, [0.0, 0.0, 0.5, 0.5]);
        let reqs = vp.compute_requests();
        // Block 0 has LOD 0 but needs LOD 2 → in requests
        assert!(reqs.iter().any(|r| r.block_id == 0 && r.lod == 2));
    }

    #[test]
    fn test_metrics() {
        let mut vp = BrowserViewport::new(32, 32, 16, 64);
        vp.receive_block(0, 0, vec![1; 100]);
        vp.receive_block(1, 0, vec![2; 200]);

        assert_eq!(vp.blocks_loaded, 2);
        assert_eq!(vp.bytes_received, 300);
        assert_eq!(vp.cache_memory(), 300);
    }

    #[test]
    fn test_eager_strategy() {
        let mut vp = BrowserViewport::new(32, 32, 16, 64);
        vp.strategy = LoadStrategy::Eager;
        vp.max_lod = 2;
        let reqs = vp.compute_requests();
        // Eager: all blocks × all LODs = 4 blocks × 3 LODs = 12
        assert!(reqs.len() >= 12);
    }

    #[test]
    fn test_reset_zoom() {
        let mut vp = BrowserViewport::new(64, 64, 16, 64);
        vp.set_zoom(8, [0.2, 0.2, 0.1, 0.1]);
        assert!(vp.target_lod > 0);

        vp.reset_zoom();
        assert_eq!(vp.zoom_factor, 1);
        assert_eq!(vp.target_lod, 0);
        assert_eq!(vp.zoom_region, [0.0, 0.0, 1.0, 1.0]);
    }

    #[test]
    fn test_hit_ratio() {
        let mut vp = BrowserViewport::new(32, 32, 16, 64);
        vp.receive_block(0, 0, vec![1]);
        vp.receive_block(1, 0, vec![2]);

        // First compute: 2 hits (cached) + 2 misses
        let _ = vp.compute_requests();
        assert!(vp.hit_ratio() > 0.0 && vp.hit_ratio() < 1.0);
    }
}
