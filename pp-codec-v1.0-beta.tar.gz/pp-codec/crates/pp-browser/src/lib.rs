//! # PP-Browser — WASM decoder + PPML Custom Elements engine
//! Ref: planDEV S21-S24, specS PPML 1.0, SFD-BRW-001..004
#![forbid(unsafe_code)]

pub mod ppml;
pub mod viewport;
pub mod client;
pub mod bridge;
