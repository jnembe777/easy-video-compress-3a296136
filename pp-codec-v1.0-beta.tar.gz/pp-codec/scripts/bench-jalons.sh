#!/usr/bin/env bash
# PP-CODEC Performance Benchmarks — Jalons J4, J9, J13
# Run: ./scripts/bench-jalons.sh
cd "$(dirname "$0")/.." || exit 1

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║   PP-CODEC — Jalon Performance Benchmarks               ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# ── J13: STV-URI Resolution < 70ms ──
echo "── J13: STV-URI Resolution ──"
python3 -c "
import time, pp_codec_python as pp

# Warm up
for _ in range(100):
    pp.resolve_uri('ppv://cam/f.ppv#t=100:200&b=5,3&lod=N2', 1920, 1080, 1024, 16)

# Measure
N = 10000
start = time.perf_counter()
for i in range(N):
    pp.resolve_uri(f'ppv://cam/f.ppv#t={i}:{i+100}&b={i%10},{i%8}&lod=N{i%4}',
                   1920, 1080, 1024, 16)
elapsed = (time.perf_counter() - start) * 1000  # ms
per_call = elapsed / N

print(f'  {N} resolutions in {elapsed:.0f} ms')
print(f'  Per call: {per_call:.3f} ms')
if per_call < 0.07:
    print(f'  ✅ J13 ATTEINT: {per_call:.3f} ms < 70 ms (target)')
else:
    print(f'  ⚠️  J13: {per_call:.3f} ms')
" 2>/dev/null || echo "  ⚠️  Python SDK not installed, skipping J13"

echo ""

# ── J13b: STV-URI Parse+Compose Roundtrip ──
echo "── J13b: STV-URI Parse Performance ──"
python3 -c "
import time, pp_codec_python as pp

uris = [
    'ppv://cam.local/feed.ppv#t=100:200&b=5,3&lod=N3&act=0.1&fam=bspline',
    'ppl://live/stream#t=-30',
    'ppv+https://cdn.example.com/video.ppv#t=0:1000&color=#FF0000&tag=vehicle',
]

N = 10000
start = time.perf_counter()
for i in range(N):
    pp.parse_uri(uris[i % len(uris)])
elapsed = (time.perf_counter() - start) * 1000
per_call = elapsed / N
print(f'  {N} parses in {elapsed:.0f} ms ({per_call:.4f} ms/call)')
" 2>/dev/null || echo "  ⚠️  Skipped"

echo ""

# ── Encode/Decode Throughput (via Python SDK) ──
echo "── Encode/Decode Throughput ──"
python3 -c "
import time, pp_codec_python as pp

# Generate test video: 64x48, 64 frames, palette 8, ~5% activity
W, H, R, M = 64, 48, 64, 8
frames = []
for t in range(R):
    frame = [0] * (W * H)
    for p in range(W * H):
        if ((p * 2654435761) ^ (t * 2246822519)) % 100 < 5:
            frame[p] = ((p * 37 + t * 71) % M)
    frames.append(frame)

pixels = W * H * R

# Encode
N_enc = 20
start = time.perf_counter()
for _ in range(N_enc):
    ppv = pp.encode(frames, width=W, height=H, block_size=16, palette_size=M)
enc_s = (time.perf_counter() - start) / N_enc
enc_mpxs = pixels / enc_s / 1e6

# Decode
N_dec = 50
start = time.perf_counter()
for _ in range(N_dec):
    pp.decode(ppv)
dec_s = (time.perf_counter() - start) / N_dec
dec_mpxs = pixels / dec_s / 1e6

print(f'  Encode: {enc_mpxs:.1f} MPx/s ({1/(enc_s):.0f} calls/s)')
print(f'  Decode: {dec_mpxs:.1f} MPx/s ({1/(dec_s):.0f} calls/s)')
print(f'  J4 target: 62 MPx/s (1080p@30fps)')
if enc_mpxs > 62:
    print(f'  ✅ J4 ATTEINT via Python SDK')
else:
    print(f'  ⚠️  J4: {enc_mpxs:.1f} / 62 MPx/s ({enc_mpxs/62*100:.0f}%)')
" 2>/dev/null || echo "  ⚠️  Skipped"

echo ""

# ── Compression Ratio Summary ──
echo "── Compression Ratios (via cargo run --release) ──"
if command -v cargo &>/dev/null; then
    cargo run --release 2>/dev/null | grep -E "surv|medical|satellite|worst" | head -5
else
    echo "  ⚠️  cargo not available"
fi

echo ""
echo "Done."
