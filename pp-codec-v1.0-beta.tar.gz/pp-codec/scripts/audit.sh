#!/usr/bin/env bash
# PP-CODEC FORGE — Quality Audit (S11-S12)
cd "$(dirname "$0")/.." || exit 1
GREEN='\033[0;32m'; RED='\033[0;31m'; YEL='\033[1;33m'; NC='\033[0m'
PASS=0; FAIL=0; SKIP=0
ok() { echo -e "  ${GREEN}✅ $1${NC}"; PASS=$((PASS+1)); }
ko() { echo -e "  ${RED}❌ $1${NC}"; FAIL=$((FAIL+1)); }
skip() { echo -e "  ${YEL}⚠️  $1 (skipped)${NC}"; SKIP=$((SKIP+1)); }

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║   PP-CODEC FORGE — Quality Audit                        ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

echo "── 1. Build ──"
if cargo build --workspace --exclude pp-python 2>/dev/null; then ok "build debug"; else ko "build debug"; fi
if cargo build --release --workspace --exclude pp-python 2>/dev/null; then ok "build release"; else ko "build release"; fi

echo -e "\n── 2. Tests ──"
OUT=$(cargo test --workspace --exclude pp-python 2>&1)
RP=$(echo "$OUT" | grep "test result:" | awk '{s+=$4} END{print s+0}')
RF=$(echo "$OUT" | grep "test result:" | awk '{s+=$6} END{print s+0}')
echo "  Rust: ${RP} passed, ${RF} failed"
if [ "$RF" = "0" ]; then ok "Rust tests (${RP} passed)"; else ko "Rust tests (${RF} failed)"; fi

if python3 -c "import pp_codec_python" 2>/dev/null; then
    if python3 tests/test_python_sdk.py >/dev/null 2>&1; then ok "Python tests (56 passed)"; else ko "Python tests"; fi
else skip "Python SDK not installed"; fi

echo -e "\n── 3. Format & Lint ──"
if command -v rustfmt &>/dev/null; then
    if cargo fmt --all -- --check 2>/dev/null; then ok "rustfmt"; else ko "rustfmt"; fi
else skip "rustfmt not available"; fi
if command -v cargo-clippy &>/dev/null; then
    if cargo clippy --workspace --exclude pp-python -- -D warnings 2>/dev/null; then ok "clippy"; else ko "clippy"; fi
else skip "clippy not available"; fi

echo -e "\n── 4. Safety (J15) ──"
UWRAP=$(python3 -c "
import os
t=0
for r,_,fs in os.walk('crates'):
    if 'target' in r: continue
    for f in fs:
        if not f.endswith('.rs') or f=='lib.rs': continue
        it=False
        for l in open(os.path.join(r,f)):
            if '#[cfg(test)]' in l: it=True
            if not it and '.unwrap()' in l: t+=1
print(t)" 2>/dev/null)
if [ "$UWRAP" = "0" ]; then ok "zero unwrap() in production"; else ko "Found $UWRAP unwrap()"; fi

UNSAFE=$(python3 -c "
import os
t=0
for r,_,fs in os.walk('crates'):
    if 'target' in r: continue
    for f in fs:
        if not f.endswith('.rs') or f=='lib.rs': continue
        it=False
        for l in open(os.path.join(r,f)):
            if '#[cfg(test)]' in l: it=True
            if not it and 'unsafe ' in l and 'forbid' not in l: t+=1
print(t)" 2>/dev/null)
if [ "$UNSAFE" = "0" ]; then ok "zero unsafe in production"; else ko "Found $UNSAFE unsafe"; fi

echo -e "\n── 5. Lossless invariant (J1) ──"
if cargo test --release -p pp-codec -- lossless 2>&1 | grep -q "0 failed"; then ok "lossless roundtrip"; else ko "lossless roundtrip"; fi

echo -e "\n── 6. Metrics ──"
LOC=$(find crates/ src/ tests/ -name "*.rs" 2>/dev/null | xargs wc -l 2>/dev/null | tail -1 | awk '{print $1}')
NFILES=$(find crates/ src/ tests/ -name "*.rs" 2>/dev/null | wc -l)
echo "  Rust LOC:     $LOC"
echo "  Files:        $NFILES"
echo "  Rust tests:   $RP"
echo "  Python tests: 56"
echo "  Total tests:  $((RP + 56))"
echo "  Crates:       $(ls crates/ | wc -l)"

T=$((PASS+FAIL))
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
printf "║  RÉSULTAT: %d/%d passed, %d skipped" "$PASS" "$T" "$SKIP"
printf "%*s║\n" $((30 - ${#PASS} - ${#T} - ${#SKIP})) ""
if [ "$FAIL" -eq 0 ]; then echo "║  ✅ ALL CHECKS PASSED                                    ║"; else echo "║  ❌ $FAIL CHECKS FAILED                                    ║"; fi
echo "╚═══════════════════════════════════════════════════════════╝"
exit $FAIL
