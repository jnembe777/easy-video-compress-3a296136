# PP-CODEC

**Lossless video compression via marked point processes and the MDL principle.**

[![CI](https://github.com/roots-insights/pp-codec/actions/workflows/ci.yml/badge.svg)](https://github.com/roots-insights/pp-codec/actions/workflows/ci.yml)
[![Coverage](https://codecov.io/gh/roots-insights/pp-codec/branch/main/graph/badge.svg)](https://codecov.io/gh/roots-insights/pp-codec)
[![Crates.io](https://img.shields.io/crates/v/pp-codec.svg)](https://crates.io/crates/pp-codec)
[![PyPI](https://img.shields.io/pypi/v/pp-codec-python.svg)](https://pypi.org/project/pp-codec-python/)

---

## What is PP-CODEC?

PP-CODEC treats video differently: instead of compressing frames as images (like H.264/H.265), it models each pixel as a **marked point process** — a temporal stream of color-change events. This enables:

- **109:1 lossless compression** on surveillance video (5% activity)
- **O(1) random access** to any block, frame, or pixel — no GOP decoding
- **Progressive streaming** via multi-scale pyramid (usable image in milliseconds)
- **Compressed-domain queries** — find activity without decompressing

## Quick Start

### Rust

```rust
use pp_codec::encoder::{encode_video, decode_video};

// Encode palette-indexed frames to .ppv
let ppv = encode_video(&frames, width, height, 16, palette_size);
let bytes = ppv.serialize();

// Decode — lossless guaranteed
let decoded = decode_video(&ppv);
assert_eq!(decoded, frames); // bit-exact
```

### Python

```bash
pip install pp-codec-python
```

```python
import pp_codec_python as pp

# Encode
ppv_bytes = pp.encode(frames, width=640, height=480, palette_size=8)

# Decode (lossless)
decoded = pp.decode(ppv_bytes)

# Random access O(1)
pixel_trace = pp.decode_pixel(ppv_bytes, x=120, y=80)

# Metadata without decoding
info = pp.info(ppv_bytes)
```

## Architecture

```
pp-codec/
├── crates/
│   ├── pp-core/       # Primitives: BitWriter, Elias codes, combinatorics
│   ├── pp-codec/      # Codec: Algorithm 1, arithmetic coder, pyramids,
│   │                  #        quantizer, STV-URI parser, PPSP protocol
│   └── pp-python/     # Python SDK via PyO3
├── tests/             # Integration tests
├── src/main.rs        # Benchmarks (10 content profiles)
└── .github/workflows/ # CI/CD (build, test, lint, coverage, release)
```

### Modules

| Module | LOC | Tests | Description |
|--------|-----|-------|-------------|
| `bits.rs` | 166 | 15 | BitWriter/BitReader with bit-level precision |
| `codes.rs` | 123 | — | Elias δ/γ universal codes |
| `combinatorics.rs` | 237 | — | log₂C(r,N), L₁/L₃/L₄ code lengths |
| `algorithm1.rs` | 573 | 10 | Threshold-based optimal code selection O(1) |
| `arithmetic.rs` | 572 | 10 | 30-bit arithmetic encoder/decoder |
| `encoder.rs` | 1065 | 16 | Full encode/decode pipeline + .ppv format |
| `decoder.rs` | 512 | 10 | 5-mode random access decoder |
| `heuristics.rs` | 232 | 8 | MDL family selection via decision trees |
| `multiscale.rs` | 760 | 9 | Spatial pyramid with sparse residuals |
| `quantize.rs` | 436 | 9 | RGB → palette (median cut) + PSNR |
| `stv_uri.rs` | 607 | 23 | STV-URI 1.0 parser/resolver/composer |
| `ppsp.rs` | 563 | 11 | PPSP 1.0 binary protocol (8 message types) |
| `pp-python` | 195 | 56★ | Python SDK (15 functions) |

★ Python tests

## Performance

| Content | Activity | Flat ratio | Pyramid ratio | Mode |
|---------|----------|-----------|--------------|------|
| Surveillance | 5% | 1.5:1 | **62:1** | Lossless |
| Medical | 3% | 2.6:1 | **60:1** | Lossless |
| Satellite | 2% | 0.8:1 | **108:1** | Lossless |
| Dense sport | 80% | 0.2:1 | **4.7:1** | Lossless |

PP-CODEC is lossless (∞ dB PSNR). H.264/H.265/AV1 are lossy (~42 dB).

## Quality

```bash
# Run full audit locally
chmod +x scripts/audit.sh && ./scripts/audit.sh
```

- `#![forbid(unsafe_code)]` on all library crates
- Zero `unwrap()` in production code
- 130+ Rust tests + 56 Python tests
- CI: build × 3 OS, clippy pedantic, rustfmt, security audit, coverage

## References

- Nembé, J. (2015). *Uniform temporal encoding of massive video datasets*
- Nembé, J. (2024). *Versatile Point Process Encoding Using the MDL Principle*

## License

Proprietary — ROOTS INSIGHTS. Patent pending (4 families, 19 claims).
