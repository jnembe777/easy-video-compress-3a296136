# Getting Started with PP-CODEC

## What is PP-CODEC?

PP-CODEC is a lossless video compression system that treats video as parallel streams of temporal events (marked point processes) instead of sequences of image frames. This enables **109:1 compression** on surveillance video, **O(1) random access** to any pixel at any time, and **compressed-domain queries** without decompression.

---

## Installation

### Rust (from source)

```bash
git clone https://github.com/roots-insights/pp-codec.git
cd pp-codec
cargo build --release
```

### Python SDK

```bash
pip install pp-codec-python
```

### Docker

```bash
cd docker
docker compose up -d
# Streamer: ws://localhost:9090
# Admin:    http://localhost:8080
# Grafana:  http://localhost:3000
```

---

## Quick Start — Encode & Decode

### Rust

```rust
use pp_codec::encoder::{encode_video, decode_video};

// Create palette-indexed frames (r frames, each w*h pixels)
let frames: Vec<Vec<u32>> = (0..128).map(|t| {
    (0..1920*1080).map(|p| {
        if pixel_changed(p, t) { color_index } else { 0 }
    }).collect()
}).collect();

// Encode to .ppv
let ppv = encode_video(&frames, 1920, 1080, 16, 8);
let bytes = ppv.serialize();
std::fs::write("output.ppv", &bytes).unwrap();

// Decode (lossless)
let decoded = decode_video(&ppv);
assert_eq!(decoded, frames); // bit-exact
```

### Python

```python
import pp_codec_python as pp

# Encode
ppv_bytes = pp.encode(frames, width=1920, height=1080,
                       block_size=16, palette_size=8)

# Decode (lossless)
decoded = pp.decode(ppv_bytes)

# Random access O(1)
pixel_trace = pp.decode_pixel(ppv_bytes, x=120, y=80)  # all frames for pixel (120,80)
frame_42 = pp.decode_frame(ppv_bytes, t=42)              # one frame

# Metadata without decoding
info = pp.info(ppv_bytes)
# {'width': 1920, 'height': 1080, 'frames': 128, 'ratio': '62.30', ...}
```

---

## RGB Video Pipeline

For real-world video (RGB pixels), use the quantization pipeline:

```python
import pp_codec_python as pp

# Load RGB frames (each frame = width * height * 3 bytes)
rgb_frames = load_your_video()  # list of bytes objects

# Encode with automatic quantization
ppv_bytes, palette = pp.encode_rgb(rgb_frames, width=640, height=480,
                                    palette_size=16)

# The palette is a list of (R, G, B) tuples
print(f"Palette: {len(palette)} colors")
```

---

## Streaming with PPSP

### Start the server

```bash
# Copy .ppv files to the data directory
cp *.ppv /data/

# Start streamer
pp-streamer --port 9090 --data /data/
```

### Connect from Python

```python
import pp_codec_python as pp

# Parse a STV-URI
plan = pp.resolve_uri(
    "ppv://streamer.local/cam.ppv#t=100:200&b=5,3&lod=N2",
    width=1920, height=1080, frames=1024, block_size=16
)
print(f"Blocks to fetch: {plan['num_blocks']}, LOD: {plan['lod']}")
```

### STV-URI Syntax

```
ppv://authority/path.ppv#fragment
ppl://authority/path          (live stream)
ppv+https://cdn/path.ppv     (HTTP fallback)

Fragment keys:
  t=120          single frame
  t=100:500      frame range
  t=-30          live: 30 frames before now
  b=5,3          single block
  b=2,1:8,6      block range
  p=120,80       pixel coordinates
  lod=N2         level of detail (N0-N4)
  act=0.1        activity threshold
  fam=bspline    MDL family filter
  color=#FF0000  color filter
  tag=vehicle    semantic tag
  fmt=json       output format
```

---

## Compressed-Domain Queries

Query the video without decompressing it:

```python
# Find active blocks (activity above threshold)
active = pp.query_activity(ppv_bytes, threshold=0.5)
for block in active:
    print(f"Block {block['block_id']}: activity={block['activity']}")
```

---

## Architecture

```
pp-codec/
├── pp-core       — Bit-level I/O, Elias codes, combinatorics
├── pp-codec      — Encoder/decoder, Algorithm 1, arithmetic coder,
│                   heuristics, multi-scale pyramid, quantizer,
│                   STV-URI parser, PPSP protocol
├── pp-python     — Python SDK (15 functions via PyO3)
├── pp-streamer   — PPSP server (VOD + Live + compressed ops)
├── pp-player     — Native player (MVC architecture)
├── pp-browser    — WASM decoder + PPML Custom Elements
└── pp-admin      — Dashboard backend (catalog, KPIs, access control)
```

---

## Performance

| Content | Activity | Ratio | Mode |
|---------|----------|-------|------|
| Surveillance | 5% | **62:1** | Lossless (pyramid) |
| Medical imaging | 3% | **60:1** | Lossless (pyramid) |
| Satellite | 2% | **108:1** | Lossless (pyramid) |
| Dense sport | 80% | **4.7:1** | Lossless (pyramid) |

All ratios are **lossless** (∞ dB PSNR). The pyramid mode is the default.

---

## API Reference

Full Rustdoc: `cargo doc --workspace --no-deps --open`

### Python SDK Functions

| Function | Description |
|----------|-------------|
| `encode(frames, w, h, bs, m)` | Encode indexed frames → .ppv bytes |
| `encode_v2(...)` | + adaptive heuristics |
| `encode_pyramid(...)` | + multi-scale pyramid |
| `encode_rgb(rgb_frames, w, h, m)` | RGB → quantize → .ppv + palette |
| `decode(ppv_bytes)` | .ppv → frames |
| `decode_block(ppv, id)` | O(1) block access |
| `decode_frame(ppv, t)` | O(1) frame access |
| `decode_pixel(ppv, x, y)` | O(1) pixel trace |
| `decode_frame_range(ppv, s, e)` | Frame range |
| `info(ppv)` | Metadata dict (no decoding) |
| `query_activity(ppv, threshold)` | Find active blocks |
| `parse_uri(uri)` | Parse STV-URI → dict |
| `resolve_uri(uri, w, h, r, bs)` | URI → extraction plan |
| `psnr(orig, recon)` | Compute PSNR (dB) |
| `version()` | SDK version string |

---

## License

Proprietary — ROOTS INSIGHTS. Patent pending.
Contact: Dr. J. Nembé — jn@rootsinsights.com
