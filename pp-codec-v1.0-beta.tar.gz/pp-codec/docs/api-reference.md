# PP-CODEC API Reference

## pp-core

### `bits::BitWriter`
```rust
BitWriter::with_capacity(bytes: usize) -> BitWriter
BitWriter::write_bits(&mut self, value: u64, bits: u32)
BitWriter::write_bit(&mut self, bit: bool)
BitWriter::bit_len(&self) -> usize
BitWriter::finish(self) -> Vec<u8>
```

### `bits::BitReader`
```rust
BitReader::with_bit_len(data: &[u8], bit_len: usize) -> BitReader
BitReader::read_bits(&mut self, bits: u32) -> u64
BitReader::read_bit(&mut self) -> bool
BitReader::remaining(&self) -> usize
```

### `codes`
```rust
write_delta(w: &mut BitWriter, n: u64)     // Elias δ universal code
read_delta(r: &mut BitReader) -> u64
write_fixed(w: &mut BitWriter, v: u64, bits: u32)  // fixed-width
read_fixed(r: &mut BitReader, bits: u32) -> u64
```

### `combinatorics`
```rust
log2_binom(r: u64, n: u64) -> f64         // log₂ C(r, N) — overflow-safe
l1_cost(r: u64, n: u64, m: u64) -> f64    // L₁ code length
l3_cost(r: u64, n: u64, m: u64) -> f64    // L₃ code length
l4_cost(r: u64, n: u64, m: u64) -> f64    // L₄ code length
```

---

## pp-codec

### `encoder`
```rust
// Pixel-level
encode_pixel_trace(trace: &[u32], m: u32) -> EncodedBlock
decode_pixel_trace(encoded: &EncodedBlock) -> Vec<u32>

// Block-level
encode_block(frames: &[Vec<u32>], w: u32, x0: u32, y0: u32, bs: u32, m: u32)
    -> Vec<EncodedBlock>

// Video-level
encode_video(frames: &[Vec<u32>], w: u32, h: u32, bs: u32, m: u32) -> PpvFile
encode_video_v2(frames: &[Vec<u32>], w: u32, h: u32, bs: u32, m: u32)
    -> (PpvFile, VideoStats)    // with heuristic family selection
decode_video(ppv: &PpvFile) -> Vec<Vec<u32>>

// Container
PpvFile::serialize(&self) -> Vec<u8>
PpvFile::deserialize(data: &[u8]) -> Option<PpvFile>
```

### `decoder::PpvDecoder`
```rust
PpvDecoder::from_bytes(data: &[u8]) -> Option<PpvDecoder>
PpvDecoder::decode_all(&self) -> DecodedVideo
PpvDecoder::decode_frame(&self, t: u32) -> Option<Vec<u32>>        // O(1)
PpvDecoder::decode_block(&self, bx: u32, by: u32) -> Option<Vec<Vec<u32>>>  // O(1)
PpvDecoder::decode_pixel(&self, x: u32, y: u32) -> Option<Vec<u32>>  // O(1)
PpvDecoder::decode_frame_range(&self, t_start: u32, t_end: u32) -> Vec<Vec<u32>>
PpvDecoder::blocks_x(&self) -> u32
PpvDecoder::blocks_y(&self) -> u32
PpvDecoder::block_size(&self) -> u32
```

### `quantize`
```rust
quantize_rgb(rgb_frames: &[Vec<u8>], w: u32, h: u32, target_m: usize)
    -> (Palette, Vec<Vec<u32>>)
dequantize_rgb(indexed: &[Vec<u32>], palette: &Palette, w: u32, h: u32)
    -> Vec<Vec<u8>>
compute_psnr(original: &[Vec<u8>], reconstructed: &[Vec<u8>]) -> f64
median_cut(unique_colors: &[Rgb], target_m: usize) -> Palette
Palette::nearest(&self, color: &Rgb) -> u32
```

### `stv_uri`
```rust
StvUri::parse(input: &str) -> Result<StvUri, StvParseError>
StvUri::to_string(&self) -> String
StvUri::with_fragment(&self, additional: &StvFragment) -> StvUri
resolve(frag: &StvFragment, w: u32, h: u32, frames: u32, bs: u32) -> ExtractionPlan

// ExtractionPlan fields: block_ids, lod, frame_range, filters
```

### `ppsp`
```rust
PpspMessage::serialize(&self) -> Vec<u8>
PpspMessage::deserialize(data: &[u8]) -> Option<PpspMessage>
PpspMessage::msg_type(&self) -> MsgType

// Message types: Open, Header, Seek, Data, Query, Result, Close, Error
```

### `multiscale`
```rust
encode_video_pyramid(frames: &[Vec<u32>], w: u32, h: u32, bs: u32, m: u32)
    -> (Vec<u8>, PyramidStats)
decode_video_pyramid(data: &[u8]) -> Option<Vec<Vec<u32>>>
```

---

## pp-python (Python SDK)

```python
# Encoding
pp.encode(frames, width, height, block_size=16, palette_size=8) -> bytes
pp.encode_v2(frames, width, height, block_size=16, palette_size=8) -> bytes
pp.encode_pyramid(frames, width, height, block_size=16, palette_size=8) -> bytes
pp.encode_rgb(rgb_frames, width, height, palette_size=16) -> (bytes, list)

# Decoding
pp.decode(ppv_bytes) -> list[list[int]]
pp.decode_block(ppv_bytes, block_id) -> list[list[int]]
pp.decode_frame(ppv_bytes, t) -> list[int]
pp.decode_pixel(ppv_bytes, x, y) -> list[int]
pp.decode_frame_range(ppv_bytes, start, end) -> list[list[int]]

# Info & Query
pp.info(ppv_bytes) -> dict
pp.query_activity(ppv_bytes, threshold) -> list[dict]

# STV-URI
pp.parse_uri(uri) -> dict
pp.resolve_uri(uri, width, height, frames, block_size) -> dict

# Utilities
pp.psnr(original, reconstructed) -> float
pp.version() -> str
```

---

## pp-player (MVC)

### Intents (22 variants)
```rust
Intent::OpenFile(String) | OpenUri(String) | CloseFile
Intent::Play | Pause | TogglePlay | Seek(u32) | SetSpeed(f64)
Intent::ZoomToRegion(Rect) | SetZoomFactor(u32) | ResetZoom
Intent::SetPaletteMode(PaletteMode)
Intent::SelectBlock(usize) | DeselectBlock | ToggleIntensityOverlay
Intent::ExecuteQuery(QueryExpr) | ClearQueryResults | ExportResults(ExportFormat)
Intent::StartEncode(EncodeParams) | CancelEncode
Intent::CopyCurrentUri | NavigateToUri(String)
```

### ViewUpdates (18 variants)
```rust
ViewUpdate::Frame(FrameViewModel) | BlockRegion(usize, Vec<u8>) | FullFrameRedraw
ViewUpdate::PlaybackState(bool) | SpeedLabel(f64) | TimelineCursor(u32)
ViewUpdate::StatusBar(StatusViewModel) | ZoomPanel(ZoomState)
ViewUpdate::BlockInfo(BlockInfoViewModel) | IntensityOverlay(Vec<f64>)
ViewUpdate::QueryResults(QueryResultViewModel) | HighlightBlocks(Vec<usize>)
ViewUpdate::ClearHighlights
ViewUpdate::EncodeProgress{..} | EncodeComplete(EncodeSummary)
ViewUpdate::ConnectionStatus(bool) | Notification(String) | CopyToClipboard(String)
```

---

## pp-browser (WASM)

### PPML Custom Elements
```html
<pp-stream src="ppv://cam/feed.ppv" width="1920" height="1080" autoplay />
<pp-zoom region="0.3,0.2,0.4,0.3" factor="8" smooth />
<pp-pyramid strategy="bandwidth-adaptive" max-lod="N4" />
<pp-query select="blocks" where="activity > 0.1" on-result="handler" />
<pp-palette mode="heatmap" />
<pp-event threshold="0.5" />
<pp-intensity block="5,3" />
<pp-cube />
```

### WASM Bridge (JSON)
```javascript
// Send intent
const response = wasmModule.handle_intent_json(JSON.stringify({
    type: "seek", frame: 42
}));

// Response types: header, frame, extraction_plan, query_result, error, status
```
