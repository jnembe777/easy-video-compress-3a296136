-- PP-CODEC PostgreSQL Schema
-- Ref: modMPD (MCD-MPD-MCT-v1, §2.2)

-- ═══ Schema: pp_catalog ═══
CREATE SCHEMA IF NOT EXISTS pp_catalog;

CREATE TABLE pp_catalog.ppv_files (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    path            VARCHAR(512) NOT NULL UNIQUE,
    width           INTEGER NOT NULL,
    height          INTEGER NOT NULL,
    frames          INTEGER NOT NULL,
    block_size      INTEGER NOT NULL DEFAULT 16,
    palette_size    INTEGER NOT NULL DEFAULT 8,
    num_blocks      INTEGER NOT NULL,
    blocks_x        INTEGER NOT NULL,
    blocks_y        INTEGER NOT NULL,
    file_bytes      BIGINT NOT NULL,
    total_bits      BIGINT NOT NULL,
    ratio           DOUBLE PRECISION,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE pp_catalog.block_index (
    id              BIGSERIAL PRIMARY KEY,
    file_id         UUID NOT NULL REFERENCES pp_catalog.ppv_files(id) ON DELETE CASCADE,
    block_id        INTEGER NOT NULL,
    bx              INTEGER NOT NULL,
    by_             INTEGER NOT NULL,
    bits            INTEGER NOT NULL,
    family          SMALLINT NOT NULL DEFAULT 2, -- 0=const,1=hist,2=bspline,3=trigo,4=daub
    n_events        INTEGER NOT NULL DEFAULT 0,
    activity_ratio  DOUBLE PRECISION,
    UNIQUE(file_id, block_id)
);

CREATE INDEX idx_block_activity ON pp_catalog.block_index(file_id, activity_ratio);
CREATE INDEX idx_block_family ON pp_catalog.block_index(file_id, family);

-- ═══ Schema: pp_streaming ═══
CREATE SCHEMA IF NOT EXISTS pp_streaming;

CREATE TABLE pp_streaming.sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id      BIGINT NOT NULL UNIQUE,
    file_id         UUID REFERENCES pp_catalog.ppv_files(id),
    client_ip       INET,
    access_level    VARCHAR(10) NOT NULL DEFAULT 'read',
    is_live         BOOLEAN NOT NULL DEFAULT FALSE,
    viewport_json   JSONB,
    opened_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    blocks_sent     BIGINT NOT NULL DEFAULT 0,
    bytes_sent      BIGINT NOT NULL DEFAULT 0,
    seeks_count     INTEGER NOT NULL DEFAULT 0,
    queries_count   INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_sessions_active ON pp_streaming.sessions(closed_at) WHERE closed_at IS NULL;

CREATE TABLE pp_streaming.tx_metrics (
    id              BIGSERIAL PRIMARY KEY,
    session_id      UUID NOT NULL REFERENCES pp_streaming.sessions(id) ON DELETE CASCADE,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    blocks_sent     INTEGER NOT NULL,
    bytes_sent      BIGINT NOT NULL,
    latency_ms      DOUBLE PRECISION
);

CREATE TABLE pp_streaming.query_log (
    id              BIGSERIAL PRIMARY KEY,
    session_id      UUID NOT NULL REFERENCES pp_streaming.sessions(id) ON DELETE CASCADE,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    select_type     VARCHAR(20) NOT NULL,
    expression      TEXT NOT NULL,
    result_count    INTEGER NOT NULL,
    exec_ms         DOUBLE PRECISION NOT NULL
);

CREATE TABLE pp_streaming.access_rules (
    id              SERIAL PRIMARY KEY,
    client_pattern  VARCHAR(256) NOT NULL,
    file_pattern    VARCHAR(512) NOT NULL DEFAULT '*',
    access_level    VARCHAR(10) NOT NULL DEFAULT 'read',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (access_level IN ('read', 'query', 'write'))
);

-- Default rule: localhost has full access
INSERT INTO pp_streaming.access_rules (client_pattern, file_pattern, access_level)
VALUES ('127.0.0.1', '*', 'write');
